// engine-bare.js — B-tier bare compaction engine (0 LLM in the compact window).
//
// Subclasses the ABSTRACT seam `CompactionEngine`
// (@deepseek-ai/dsh-compaction), NOT basic's concrete
// `BasicCompactionEngine`. This removes the basic-inheritance chain: the
// engine owns its trigger policy, retention math, automatic listeners, manual
// path, region transaction, and the 0-LLM `summarize` hook — while REUSING the
// pure-seam helpers from the package root (CompactionId, ManualCompactionError,
// compactCheckpointSource, toolPairingBalanced*) and the vendored
// region/config helpers (engine-region.js).
//
// 0 LLM ruling (owner): the `summarize` hook goes through the supercompress
// ledger + deterministic fallback. When the ledger is OFF (the default:
// DASHSC_LEDGER_SUMMARIZER unset), B-tier does NOT fall back to a host LLM
// summarizer (that was basic's `summarizeWithLlm`, the only behavior change in
// B-tier). Instead the OFF branch also composes the deterministic fallback:
//   - ledger ON  + ledger served the region  -> unmarked SummaryResult
//     (provider 'supercompress', model 'ledger').
//   - ledger ON  + ledger miss + fallback can shrink -> unmarked SummaryResult
//     (provider 'supercompress', model 'ledger-fallback').
//   - ledger OFF -> deterministic fallback (0 LLM, no host LLM).
//   - fallback cannot shrink -> throw CompactionRefused (the host's region
//     transaction rolls back; the next trigger retries). No LLM, ever.
//
// The static `Config` load-validation is SELF-WRITTEN (not basic's
// schemastery `z.object` schema) but borrows basic's `resolveConfig`
// fail-fast validation face (engine-region.js), so a web row that loads
// against basic also loads here; the field names stay byte-compatible with
// the current web row config (auto / thresholdRatio / headroomTokens /
// retainRatio / retainTokens / summarizationProvider / summarizationModel /
// maxTokens / compactionRetries / maxOverflowRetries / modelPolicies).

import { CompactionEngine, ManualCompactionError } from "@deepseek-ai/dsh-compaction";
import { LlmError, CONTEXT_WINDOW_EXCEEDED_CODE } from "@deepseek-ai/dsh-llm";
import { assertNever } from "@deepseek-ai/dsh-util-values";
import { safeLlm, safeTokenMeter, isLegacyInject } from "./llm-guard.js";
// Host compaction-row config contract: the host's Cordis loader validates a
// compaction package's `static Config` through the schemastery (zod) schema
// (isSchemastery guard: schema?.["~standard"].vendor === "schemastery"). The
// host's own dsh-compaction-basic uses `import z from "@deepseek-ai/schemastery"`
// + `static Config = z.object({...})`. Align the bare engine to the SAME
// schemastery face so the host accepts supercompress's row config and the
// engine actually activates (ad9d81b's self-written `~standard`/`keys` object
// was NOT the host's expected face — it left the host reporting
// "invalid config:" and the engine never activated).
import z from "@deepseek-ai/schemastery";
import {
  resolveConfig,
  resolveTargetPolicy,
  resolveCompactSpec,
  TargetPressureConfigError,
  selectCompactableRange,
  assertNoActiveCompaction,
  compactSurfaceRegion,
  frameSummary,
} from "./engine-region.js";
import {
  summarizeFromLedger,
  composeDeterministicFallback,
  CompactionRefused,
  LedgerSummarizeMiss,
} from "./summarize-ledger.js";

function noopLog() {
  return { debug() {}, warn() {} };
}

/** Resolve the exact provider/model durably routed for the latest request. */
function routedTarget(session) {
  const config = session.requestHeader()?.config;
  if (config === undefined || config.provider.length === 0 || config.model.length === 0) return undefined;
  return { provider: config.provider, model: config.model };
}

/** Output tokens the routed request reserves (same window as the prompt). */
function reservedCompletionTokens(header, defaultMaxTokens) {
  return header.config.maxTokens ?? defaultMaxTokens ?? 0;
}

/** Resolve the conversation target used to pick an optional policy override. */
function conversationTarget(agent) {
  const routed = routedTarget(agent.session);
  if (routed !== undefined) return routed;
  if (
    agent.options.provider === undefined ||
    agent.options.provider.length === 0 ||
    agent.options.model === undefined ||
    agent.options.model.length === 0
  )
    return undefined;
  return { provider: agent.options.provider, model: agent.options.model };
}

/**
 * The B-tier bare engine: the supercompress gate's trigger policy + 0-LLM
 * summarizer on top of the abstract seam. The caller (engine.js) wraps it
 * with `withSupercompressGate` to add the P0 gate + ledger +
 * compactIfNeeded override; this class owns everything else.
 */
/**
 * resolveFallbackDigest — the pure coverage-gap digest-leg resolution
 * (RENDER_FIX_PROPOSAL §2.2; the fallback's bounded digest leg):
 *   - ladder ON: the form-ladder face — totalCap = min(the owner's knob,
 *     the region-scaled 0.5× floor); the 848×uncovered deduction is REMOVED
 *     (R4: the uncovered verbatim leg carries its own cap, the digest pool
 *     stands on its own); the stats header line rides above the paged body.
 *   - ladder OFF (the default): the legacy sessionDigest face with the legacy
 *     budget formula (max(2048, 0.5×region − 848×uncovered)) — byte-stable
 *     until the owner flips the knob.
 * A daemon miss returns "" (the composition proceeds verbatim-only — the
 * fail-open floor, never blocks the compact).
 * @returns {Promise<{digest:string, face:string, budget:number}>}
 */
export async function resolveFallbackDigest({ client, ladder, totalChars, uncoveredCount, sessionId }) {
  if (ladder?.on && typeof client.sessionDigestLadder === "function") {
    const totalCap = Math.min(ladder.totalCap ?? 16384, Math.max(2048, Math.floor(totalChars * 0.5)));
    try {
      const sd = await client.sessionDigestLadder(sessionId, {
        p0CapBytes: ladder.p0Cap ?? 8192,
        indexPoolBytes: ladder.indexPool ?? 4096,
        l3CapBytes: ladder.l3Cap ?? 512,
        totalCapBytes: totalCap,
      });
      return { digest: [sd?.header, sd?.text].filter(Boolean).join("\n").trim(), face: "ladder", budget: totalCap };
    } catch {
      return { digest: "", face: "ladder-miss", budget: totalCap };
    }
  }
  const budget = Math.max(2048, Math.floor(totalChars * 0.5) - uncoveredCount * 848);
  try {
    const sd = await client.sessionDigest(sessionId, budget);
    return { digest: String(sd?.text ?? "").trim(), face: "legacy", budget };
  } catch {
    return { digest: "", face: "legacy-miss", budget };
  }
}

export class SupercompressCompactionEngine extends CompactionEngine {
  // GENERATION SPLIT (the dist esbuild --define __SC_LEGACY switch): the rc.1
  // host generation has no `llm` / `tokenMeter` DI tokens, so the RC1HOST
  // build declares only `["sessions"]` (resolvable on rc.1) — the engine's
  // meter/LLM faces take their deterministic floor there. The FULL build
  // (rc.5+) keeps the full triple.
  static inject = isLegacyInject ? ["sessions"] : ["llm", "tokenMeter", "sessions"];

  // schemastery (zod) `static Config` face — aligned to the host's own
  // dsh-compaction-basic (`import z from "@deepseek-ai/schemastery"; static
  // Config = z.object({...})`). This is the host's expected config contract:
  // the host's Cordis loader's isSchemastery guard
  // (`schema?.["~standard"].vendor === "schemastery"`) recognizes the
  // schemastery face and validates the row config against it.
  //
  // 11-field schema (identical to basic's top-level key set, so existing web
  // rows load unchanged). The constructor still runs the vendored
  // resolveConfig(config) for the fail-fast key + type + retention checks
  // (engine-region.js) — the schemastery schema only gates the host's
  // load-time row-config validation; supercompress behavior is byte-identical
  // beyond activation.
  static Config = (() => {
    // Volatile knob faces (activation fix + web-knob exposure 2026-11-24):
    // the host's ctx.settings derives the compaction row's editable knobs from
    // the plugin's static Config schema — but ONLY for fields whose
    // `meta.volatile` is true (volatileForm: `if (schema.meta.volatile) return
    // plainSchema(schema)`; the host's own dsh-agent-default-model /
    // dsh-agent-loop mark their knobs exactly this way:
    // z.string().volatile() / z.number().step(1).min(1).default(10).volatile()).
    // basic's knobs are host-internal (not plugin-schemaderived), so basic
    // needs no volatile marks; supercompress's 11-field z.object IS the
    // schemaderived knob surface, so the 4 hot-tunable fields (auto,
    // thresholdRatio, headroomTokens, retainRatio) carry .volatile() + a
    // .default() so the host's settings form can render + live-tune them
    // (writing back to the compaction row config) instead of needing a
    // cordis.patch.yml edit. The other 7 fields stay non-volatile (rarely
    // tuned; they ride the row config / constructor defaults).
    // DEPRECATED FIELDS (refactor 2026-11-24): `summarizationProvider` /
    // `summarizationModel` are removed from the schemastery knob surface —
    // the B-tier `summarize` hook goes through the supercompress ledger +
    // deterministic fallback (provider 'supercompress', model 'ledger' /
    // 'ledger-fallback') and NEVER falls back to a host LLM summarizer
    // (that was basic's `summarizeWithLlm`, the only B-tier behavior change).
    // These two fields are a basic-inheritance leftover: B-tier does not call
    // `ctx.llm` for summarization, so the fields are NOT consumed by engine
    // logic. They are kept in the row-config layer (resolveConfig's
    // validateSummarizationPair still accepts them if a row sets them, for
    // backward compatibility — removing the schema entries does NOT throw on
    // a row that still carries them, because the constructor's
    // resolveConfig(config) runs against the raw row config, not the schema;
    // the schema only gates the host's load-time volatile-form rendering).
    // Web knob surface: only the 4 hot-tunable fields (auto, thresholdRatio,
    // headroomTokens, retainRatio) are .volatile(); the other 7 (incl. the
    // two deprecated summarization fields, now dropped from the schema) ride
    // the row config / constructor defaults.
    const thresholdRatioSchema = z.number().default(0.8).volatile();
    const headroomTokensSchema = z.number().step(1).min(0).default(65536).volatile();
    const retainRatioSchema = z.number().default(0.16).volatile();
    const retainTokensSchema = z.number().step(1).min(0);
    const maxTokensSchema = z.number().step(1).min(1);
    const compactionRetriesSchema = z.number().step(1).min(0);
    const maxOverflowRetriesSchema = z.number().step(1).min(0);
    // Live user-paste trim-at-production face (the 40% band's user pass,
    // moved to every step boundary). Row-config surface, NON-volatile:
    // toggling it is a restart-grade behavior change (the engine reads
    // `this.config` resolved at construction; volatile write-backs would not
    // be re-read mid-session). Defaults = the preclean.js USER_* constants
    // (8192/4096/1024 — keep in sync); unset = byte-identical to the
    // pre-live behavior. `liveUserTrim` default false = OFF (the 40% band's
    // user pass stays the only user-trim path).
    const liveUserTrimSchema = z.boolean().default(false);
    const userPasteThresholdCharsSchema = z.number().step(1).min(1).default(8192);
    const userPasteHeadCharsSchema = z.number().step(1).min(0).default(4096);
    const userPasteTailCharsSchema = z.number().step(1).min(0).default(1024);
    // The modelPolicy (exact provider/model override) NESTED inside
    // `modelPolicies: z.array(modelPolicy)` reuses the 3 ratio/token knobs,
    // but schemastery's volatile protocol requires volatile fields to sit at a
    // FIXED object path (no enclosing volatile field / array). A volatile
    // field nested under `modelPolicies.*` (the array) violates that ("volatile
    // fields require a fixed object path without an enclosing volatile
    // field"), which made the host's cordis resolveConfig throw
    // `invalid config:` and took the whole settings card down. So the NESTED
    // copies are NON-volatile twins (same shape/defaults, no .volatile()); the
    // top-level 4 knobs stay volatile (they are the live-tuned card surface).
    const nestedThresholdRatioSchema = z.number().default(0.8);
    const nestedHeadroomTokensSchema = z.number().step(1).min(0).default(65536);
    const nestedRetainRatioSchema = z.number().default(0.16);
    const modelPolicy = z.object({
      provider: z.string().required(),
      model: z.string().required(),
      thresholdRatio: nestedThresholdRatioSchema,
      headroomTokens: nestedHeadroomTokensSchema,
      retainRatio: nestedRetainRatioSchema,
      retainTokens: retainTokensSchema,
      maxTokens: maxTokensSchema,
      compactionRetries: compactionRetriesSchema,
      maxOverflowRetries: maxOverflowRetriesSchema,
    });
    return z.object({
      thresholdRatio: thresholdRatioSchema,
      headroomTokens: headroomTokensSchema,
      retainRatio: retainRatioSchema,
      retainTokens: retainTokensSchema,
      maxTokens: maxTokensSchema,
      compactionRetries: compactionRetriesSchema,
      maxOverflowRetries: maxOverflowRetriesSchema,
      modelPolicies: z.array(modelPolicy),
      auto: z.boolean().default(true).volatile(),
      liveUserTrim: liveUserTrimSchema,
      userPasteThresholdChars: userPasteThresholdCharsSchema,
      userPasteHeadChars: userPasteHeadCharsSchema,
      userPasteTailChars: userPasteTailCharsSchema,
    });
  })();

  constructor(ctx, config = {}) {
    // CompactionEngine's Service base registers the `compaction` DI service via
    // super(ctx, "compaction"); the bare engine passes ctx only (basic's
    // subclass adds nothing to the constructor beyond resolveConfig).
    super(ctx);
    this.config = resolveConfig(config);
    this.warnedPressureConfigTargets = new Set();
    this.overflowRetries = new WeakMap();
    this.overflowAgents = new WeakMap();
    if (this.config.auto) this._registerAutomaticCompaction();
  }

  // ── automatic listeners (basic's _registerAutomaticCompaction, verbatim) ──
  _registerAutomaticCompaction() {
    const { ctx } = this;
    const logResult = (result, trigger) => {
      ctx.logger.info(
        `compaction (${trigger}): shadowed ${result.shadowedSeqs.length} surface nodes (seqs ${result.shadowedRange.start}-${result.shadowedRange.end}, ~${result.shadowedTokenCount} tokens)`,
      );
    };
    ctx.on("agent/pre-step", async ({ agent, signal }, next) => {
      if (!signal.aborted) {
        try {
          const result = await this.compactIfNeeded(agent, "pressure", signal);
          if (result !== null) logResult(result, "step pressure");
        } catch (error) {
          if (error instanceof TargetPressureConfigError) {
            if (this.warnedPressureConfigTargets.has(error.targetKey)) return next();
            this.warnedPressureConfigTargets.add(error.targetKey);
          }
          const message = error instanceof Error ? error.message : String(error);
          ctx.logger.warn(`step compaction failed: ${message}; continuing the turn`);
        }
      }
      return next();
    });
    ctx.on("agent/status", ({ agent, status }) => {
      if (status === "idle") this.overflowRetries.delete(agent);
    });
    ctx.on(
      "agent/request",
      async ({ agent, signal }, next) => {
        const config = await next();
        const previous = agent.session.requestHeader();
        if (
          signal.aborted ||
          previous === undefined ||
          config.provider === "" ||
          config.model === "" ||
          (previous.config.provider === config.provider && previous.config.model === config.model)
        )
          return config;
        try {
          const header = { ...previous, config };
          const result = await this.compactPressure(agent, header, signal, true);
          if (result !== null) logResult(result, "model switch");
        } catch (error) {
          signal.throwIfAborted();
          const message = error instanceof Error ? error.message : String(error);
          throw new LlmError(
            `Cannot switch to ${config.provider}/${config.model}: context compaction failed: ${message}. The previous request model is preserved; retry or select a model with a larger context window.`,
            "MODEL_SWITCH_COMPACTION_FAILED",
            { cause: error },
          );
        }
        return config;
      },
      { prepend: true },
    );
    ctx.on("session/event", (session, event) => {
      if (event.type !== "assistant/message") return;
      const agent = this.overflowAgents.get(session);
      if (agent !== undefined) this.overflowRetries.delete(agent);
    });
    ctx.on("agent/request-error", async ({ agent, failure, signal }, next) => {
      if (failure.code !== CONTEXT_WINDOW_EXCEEDED_CODE || signal.aborted) return next();
      this.overflowAgents.set(agent.session, agent);
      const target = routedTarget(agent.session);
      if (target === undefined) return next();
      const policy = resolveTargetPolicy(this.config, target);
      const retries = this.overflowRetries.get(agent) ?? 0;
      if (retries >= policy.maxOverflowRetries) return next();
      const generation = agent.session.surface.replaceGeneration;
      let result;
      try {
        result = await this.compactIfNeeded(agent, "context-overflow", signal);
      } catch (recoveryError) {
        const message = recoveryError instanceof Error ? recoveryError.message : String(recoveryError);
        if (!signal.aborted && agent.session.surface.replaceGeneration > generation) {
          ctx.logger.warn(
            `context-overflow compaction failed after durable surface progress: ${message}; retrying from the replacement surface`,
          );
          this.overflowRetries.set(agent, retries + 1);
          return { kind: "retry" };
        }
        ctx.logger.warn(
          `context-overflow compaction failed: ${message}; ${signal.aborted ? "cancellation prevents retry" : "preserving the original request error"}`,
        );
        return next();
      }
      if (signal.aborted || agent.session.surface.replaceGeneration <= generation) return next();
      if (result !== null) logResult(result, "context overflow recovery");
      this.overflowRetries.set(agent, retries + 1);
      return { kind: "retry" };
    });
  }

  // ── 0-LLM summarize hook (the sole customization point) ────────────────────
  // B-tier does NOT call basic's summarizeWithLlm (0 LLM). This bare method is
  // the ledger + deterministic-fallback core. `withSupercompressGate` wraps it:
  // it runs the P0 write-before-compress gate + the live `useLedgerSummarizer`
  // resolution and THEN calls `super.summarize(...)` (this method),
  // passing the resolved ledger face + data-plane client through `agent`
  // (agent._scGate) and the audit hook (agent._scAudit) when the gate is
  // mounted. When run WITHOUT the gate (the bare test harness), both are absent
  // and this method defaults to ledger-OFF -> the deterministic fallback.
  async summarize(input, agent, signal) {
    const gate = agent?._scGate;
    const audit = agent?._scAudit?.bind(agent);
    const client = gate?.client ?? this._ledgerClient;
    const ladder = gate?.ladder ?? { on: false };
    const ledger = gate
      ? { on: gate.ledgerOn === true, source: gate.ledgerSource ?? "gate-mounted" }
      : { on: false, source: "bare B-tier (gate not mounted; ledger summarizer face unset)" };

    audit?.(agent, "enter", JSON.stringify({ ledgerOn: ledger.on, source: ledger.source }));

    if (ledger.on) {
      try {
        const res = await summarizeFromLedger({ client, input, agent, signal, ladder });
        this.ctx?.logger?.debug?.(
          "supercompress engine: ledger-backed checkpoint composed (0 LLM calls in the compact window)",
        );
        audit?.(agent, "ledger", "composed");
        return res;
      } catch (err) {
        if (!(err instanceof LedgerSummarizeMiss)) {
          this.ctx?.logger?.warn?.(
            `supercompress: compact refused (P1): unexpected ledger summarizer error: ${err?.message ?? err}`,
          );
          audit?.(agent, "compact-refused", `unexpected: ${err?.message ?? err}`);
          throw new CompactionRefused(`unexpected ledger summarizer error: ${err?.message ?? err}`, { cause: err });
        }
        if (err.reason === "no-shrink") {
          this.ctx?.logger?.warn?.(`supercompress: compact refused (P1): ${err.message}`);
          audit?.(agent, "compact-refused", `no-shrink: ${err.message}`);
          throw new CompactionRefused(`deterministic fallback cannot shrink the region: ${err.message}`);
        }
        const fb = await this._composeFallback({ input, agent, signal, miss: err, client, ladder });
        signal?.throwIfAborted?.();
        const blocks = [{ type: "text", text: fb.composed }];
        audit?.(agent, "ledger-fallback", err.reason);
        return { summary: blocks, provider: "supercompress", model: "ledger-fallback", rawOutput: blocks };
      }
    }

    // Ledger OFF (default): B-tier behavior change — the host LLM summarizer is
    // NOT invoked. Compose the deterministic fallback (0 LLM) instead; when even
    // it cannot shrink, refuse the compact (the host's region transaction rolls
    // back, the session continues un-compacted, the next trigger retries).
    this.ctx?.logger?.warn?.(
      `supercompress engine: ledger summarizer OFF via ${ledger.source} — composing the deterministic fallback (0 LLM; no host LLM summarizer)`,
    );
    audit?.(agent, "llm-skipped", `OFF via ${ledger.source}`);
    const fb = await this._composeFallback({ input, agent, signal, miss: null, client, ladder });
    signal?.throwIfAborted?.();
    const blocks = [{ type: "text", text: fb.composed }];
    audit?.(agent, "ledger-off-fallback", "OFF");
    return { summary: blocks, provider: "supercompress", model: "ledger-fallback", rawOutput: blocks };
  }

  /**
   * Compose the deterministic fallback for a ledger miss (or the ledger-OFF
   * path). Returns `{ composed, shrink, shadowChars }` and throws
   * `CompactionRefused` when the composition cannot shrink the region.
   */
  async _composeFallback({ input, agent, signal, miss, client, ladder }) {
    let digest = "";
    let uncovered = null;
    if (miss) {
      uncovered = miss.reason === "coverage-gap" ? miss.uncovered : miss.allUncovered ?? null;
      if (miss.reason === "coverage-gap" && uncovered && client?.sessionDigest) {
        const totalChars = (input?.messages ?? []).reduce(
          (n, m) => n + (Array.isArray(m?.content) ? m.content.length * 64 : String(m?.content ?? "").length),
          0,
        );
        // The pure digest-leg resolution (ladder ON = the form-ladder face
        // without the 848×uncovered deduction; OFF = the legacy formula
        // byte-stable) — extracted for the unit tests' direct pinning.
        const leg = await resolveFallbackDigest({ client, ladder, totalChars, uncoveredCount: uncovered.length, sessionId: String(agent?.session?.id ?? agent?.session?.header?.id ?? "") });
        digest = leg.digest;
        if (leg.face === "ladder-miss") this.ctx?.logger?.warn?.("supercompress: ladder digest face missed (daemon down); proceeding verbatim-only");
      }
    }
    // R4: the ladder-ON composition caps the uncovered leg (8192B, the
    // "清凉" bound); the legacy composition (ladder OFF) stays unbounded
    // (byte-stable default behavior).
    const fb = composeDeterministicFallback({ input, uncovered, digest, ...(ladder?.on ? { uncoveredCapBytes: 8192 } : {}) });
    if (!fb.composed || !fb.shrink) {
      this.ctx?.logger?.warn?.(
        `supercompress: compact refused (P1): deterministic fallback no-shrink (${fb.composed?.length ?? 0} >= ${fb.shadowChars} chars)`,
      );
      agent?._scAudit?.(agent, "compact-refused", `P2 no-shrink (${fb.composed?.length ?? 0} >= ${fb.shadowChars})`);
      throw new CompactionRefused(
        `deterministic fallback did not shrink the region (${fb.composed?.length ?? 0} >= ${fb.shadowChars} chars); compact declined`,
      );
    }
    this.ctx?.logger?.warn?.(`supercompress deterministic fallback composed (${fb.composed.length} chars, 0 LLM)`);
    return fb;
  }

  // ── trigger policy (basic's compactIfNeeded / compactPressure) ──────────────
  async compactIfNeeded(agent, trigger, signal) {
    const header = agent.session.requestHeader();
    if (header === undefined || routedTarget(agent.session) === undefined) return null;
    switch (trigger) {
      case "pressure":
        return this.compactPressure(agent, header, signal, false);
      case "context-overflow": {
        this.ctx.get("toolResultPruner")?.pruneSession(agent.session);
        // rc.1 floor: no tokenMeter DI token -> cannot measure -> no overflow
        // compaction (the deterministic floor, never a crash).
        const meter = safeTokenMeter(this.ctx);
        if (meter === undefined) return null;
        const measurement = meter.measure(agent.session);
        const range = selectCompactableRange(agent.session, measurement, 0);
        if (range === null) return null;
        return this.compactRegion(range.start, range.end, agent, signal);
      }
      /* v8 ignore next -- closed-union exhaustiveness guard */
      default:
        assertNever(trigger, "compaction trigger");
    }
  }

  async compactPressure(agent, header, signal, requireBelowThreshold) {
    const target = header.config;
    const policy = resolveTargetPolicy(this.config, target);
    const meter = safeTokenMeter(this.ctx);
    const llm = safeLlm(this.ctx);
    // rc.1 floor: no tokenMeter / no llm DI tokens -> cannot measure the
    // pressure or resolve the model -> no automatic pressure compaction
    // (the deterministic floor, never a crash).
    if (meter === undefined || llm === undefined) return null;
    let measurement = meter.measure(agent.session, header);
    const prune = this.ctx.get("toolResultPruner");
    const info = await llm.resolveModelInfo(target.provider, target.model, signal);
    assertNoActiveCompaction(agent.session, "automatic pressure compaction");
    const targetKey = `${target.provider}/${target.model}`;
    if (info.context === undefined)
      throw new TargetPressureConfigError(
        targetKey,
        `supercompress: no context capacity for ${targetKey}; configure contextWindow on that adapter model`,
      );
    const spec = resolveCompactSpec(policy, info.context.contextWindow, reservedCompletionTokens(header, info.defaultMaxTokens));
    if (measurement.totalTokens < spec.thresholdTokens) return null;
    if (prune !== undefined) {
      prune.pruneSession(agent.session);
      measurement = meter.measure(agent.session, header);
    }
    if (measurement.totalTokens < spec.thresholdTokens) return null;
    let result = null;
    for (let attempt = 0; attempt <= spec.compactionRetries; attempt += 1) {
      // The C-tier gate's per-band checkpoint protection (agent._scProtect:
      // "all" = the 50% band — shadow only the new tail since the last
      // checkpoint; "first" = the 70% band — protect only the p1 anchor).
      // Unset on the host-native / overflow / manual paths -> the baseline
      // firstIdx rule (byte-stable).
      const range = selectCompactableRange(agent.session, measurement, spec.retainTokens, agent?._scProtect);
      if (range === null) {
        if (result === null && !requireBelowThreshold) return null;
        throw new Error(
          `no safe compaction range can reduce context below threshold (${measurement.totalTokens} estimated tokens >= threshold ${spec.thresholdTokens})`,
        );
      }
      result = await this.compactRegion(range.start, range.end, agent, signal);
      measurement = meter.measure(agent.session, header);
      if (measurement.totalTokens < spec.thresholdTokens) return result;
    }
    throw new Error(
      `compaction still above threshold after ${spec.compactionRetries + 1} compaction attempts (${measurement.totalTokens} estimated tokens >= threshold ${spec.thresholdTokens})`,
    );
  }

  // ── region transaction (basic's compactRegion, verbatim) ───────────────────
  async compactRegion(start, end, agent, signal) {
    return compactSurfaceRegion(this.regionDependencies(), agent.session, start, end, agent, {
      owner: "current-turn",
      stability: "whole-surface",
    }, signal);
  }

  // ── manual path (basic's compactNow, verbatim) ──────────────────────────────
  compactNow(agent, signal, sourceCommandId) {
    signal.throwIfAborted();
    try {
      return agent.runMaintenance(async (agentSignal) => {
        const operationSignal = AbortSignal.any([agentSignal, signal]);
        try {
          operationSignal.throwIfAborted();
          const meter = safeTokenMeter(this.ctx);
          if (meter === undefined) return null; // rc.1 floor: no meter -> no manual compaction
          const range = selectCompactableRange(agent.session, meter.measure(agent.session), 0);
          if (range === null) return null;
          return await compactSurfaceRegion(this.regionDependencies(), agent.session, range.start, range.end, agent, {
            owner: null,
            stability: "selected-span",
            ...(sourceCommandId === undefined ? {} : { sourceCommandId }),
            flush: async () => {
              await this.ctx.sessions.flush(agent.session);
            },
          }, operationSignal);
        } catch (error) {
          if (agentSignal.aborted && operationSignal.reason === agentSignal.reason)
            throw new ManualCompactionError("cancelled", "manual compaction was cancelled", { cause: error });
          operationSignal.throwIfAborted();
          throw error;
        }
      });
    } catch (error) {
      throw new ManualCompactionError(
        "busy",
        "manual compaction requires an idle agent with no waking queued work",
        { cause: error },
      );
    }
  }

  // ── region dependencies (basic's regionDependencies, verbatim) ──────────────
  regionDependencies() {
    return {
      meter: safeTokenMeter(this.ctx),
      summarize: (input, owner, abort) => this.summarize(input, owner, abort),
      recover: (error, agent, sourceEventSeqs, signal) =>
        this.ctx.waterfall(
          "compaction/summary-error",
          { session: agent.session, sourceEventSeqs, error, ...(signal === undefined ? {} : { signal }) },
          () => false,
        ),
    };
  }
}

export { frameSummary };
