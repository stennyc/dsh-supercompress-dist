// predigest.js — the unified 40% pre-digest face (the 4-band redesign, step 3).

// Consolidates the two separate LLM pre-digest faces the owner retired — the
// 55-band head80-stub upgrade (enable55Band) and the model-segment tiering
// burst (enableTiering) — into ONE batched face driven by the 40% band:

//   - ONE LLM call per band firing (a batch of not-yet-digested segments in
//     one prompt — O(1) calls + a bounded input, NOT the per-segment O(N)
//     burst that dominated the 2026-11-23 compact windows). The batch rides
//     the warm prefix (aux ≡ the host main-model endpoint; the segment text
//     is the main session's own content).
//   - Writes digests to the ledger (the data-plane BYPASS — zero host prefix
//     cost; provider tokens are consumed, a separate layer). 宁漏勿错: a miss
//     keeps the P1 pre-tag / the head80 stub (no data drop, no block).
//   - IDEMPOTENT via a per-session marker (a Map<sid, prefixLen>): model
//     segments are append-only in log order, so 'the first M are digested' is
//     a stable prefix. Re-firing the 40% band with no NEW segments is a
//     no-op (no LLM); only the suffix beyond the marker is digested.
//   - BOUNDED: a per-batch input-token cap + a per-call timeout + a total
//     budget (residual ② 'earliest abort wins'), so the 40% compact window
//     can never be held open by a degraded endpoint.
//   - fail-open everywhere: any miss degrades (keep the floor), never blocks
//     the band.

// Zero deps beyond node stdlib + the host LLM seam (the repo rule).
import { resolveHostDir, resolveHostSessionBySessionId } from "./host-session.js";
import { safeLlm } from "./llm-guard.js";
import { oneShotText, routeFromAgent, textUserMessage } from "./llm-one-shot.js";

// The per-session idempotency marker: Map<sessionId, { prefixLen }>. The
// prefix is the count of log-ordered model segments already digested in THIS
// engine instance's lifetime. A fresh instance (resume) re-arms at 0 — the
// re-digest is bounded (the batch cap + the ingest content-hash dedup keep it
// cheap + no duplicate ledger rows). Exported for test isolation / the
// bundle's dispose reset (mirrors the liveUserTrim marker's test face).
export const preDigestMarkerBySession = new Map();
export function clearPreDigestMarkers() {
  preDigestMarkerBySession.clear();
}

// One batched digest instruction: N numbered segments in, a strict JSON
// array out (one element per segment). The LLM tiers + digests each segment
// in a SINGLE call (the '一次成批' face).
export const BATCH_DIGEST_INSTRUCTION =
  "For each numbered conversation segment below, produce a strict JSON array (no code fence, no extra text).\n" +
  "One element per segment, in order, with fields: i (the segment number), tier (P0 | P1 | P2), " +
  "key_fact (<=60 chars: the single most important fact/decision), summary (<=200 chars: a 2-4 sentence digest).\n" +
  "Tier: P0 = a durable decision/fact, P1 = useful context, P2 = transient. " +
  "If a segment is too short to judge, use P1. --- segments ---\n";

/**
 * Parse the batched LLM reply into a POSITION-ALIGNED array of
 * { tier, keyFact, summary, digested } (length = expectedCount; a missing /
 * malformed element degrades to the P1 floor with digested=false so the
 * caller retries it next firing).
 * @param {string} text the raw LLM reply
 * @param {number} expectedCount the batch size
 * @returns {Array<{tier:string,keyFact:string,summary:string,digested:boolean}>}
 */
export function parseBatchDigestResponse(text, expectedCount) {
  const out = [];
  for (let i = 0; i < expectedCount; i += 1) out.push({ tier: "P1", keyFact: "", summary: "", digested: false });
  if (!text) return out;
  let arr = null;
  try {
    const s = String(text).trim().replace(/^\s*```[a-zA-Z]*\n?/, "");
    const a = s.indexOf("[");
    const z = s.lastIndexOf("]");
    if (a !== -1 && z > a) arr = JSON.parse(s.slice(a, z + 1));
  } catch {
    arr = null;
  }
  if (!Array.isArray(arr)) return out;
  for (const el of arr) {
    const i = Number(el && el.i);
    if (!Number.isInteger(i) || i < 1 || i > expectedCount) continue;
    const e = out[i - 1];
    e.tier = ["P0", "P1", "P2"].includes(el && el.tier) ? el.tier : "P1";
    e.keyFact = String((el && (el.key_fact != null ? el.key_fact : el.keyFact)) || "").slice(0, 80);
    e.summary = String((el && el.summary) || "").slice(0, 400);
    e.digested = Boolean(e.keyFact || e.summary);
  }
  return out;
}

/**
 * Resolve THIS session's own host model segments (log order, deduped) via the
 * host-session.js source scheme (the own-file cwd leg + the session-id walk
 * fallback). Self-contained so predigest does not couple to tiering.js
 * internals. Returns [] on any miss (the caller fails open).
 * @returns {Promise<Array<{text:string,session?:string}>>}
 */
async function resolveModelSegments(client, agent, dshRoot, session) {
  const cwd = (agent && agent.session && agent.session.header && agent.session.header.cwd) || "";
  let ownFile = "";
  if (cwd && session) {
    const dir = resolveHostDir({ dshRoot, cwd });
    if (dir) {
      const { join: joinP } = await import("node:path");
      ownFile = joinP(dir, session, "session.v4.jsonl.zstd");
    }
  }
  if (!ownFile && session) ownFile = resolveHostSessionBySessionId({ dshRoot, sessionId: session });
  if (ownFile) {
    try {
      const { existsSync } = await import("node:fs");
      if (existsSync(ownFile)) {
        const res = await client.hostModelSegments(ownFile);
        return (res && res.segments) || [];
      }
    } catch {
      /* fall through to the dir-wide read */
    }
  }
  if (cwd) {
    try {
      const dir = resolveHostDir({ dshRoot, cwd });
      if (dir) {
        const res = await client.hostModelSegmentsDir(dir);
        return (res && res.segments) || [];
      }
    } catch {
      /* fail-open */
    }
  }
  return [];
}

/**
 * Drive the unified 40% pre-digest face for one band firing.
 * @param {object} o
 * @param {object} o.client data-plane client (hostModelSegments / ingest /
 *   digest / tag). `hostModelSegmentsDir` for the cwd-wide fallback.
 * @param {object} o.ctx the service ctx (`.llm`, `.logger`).
 * @param {object} o.agent the host Agent (`.session.id`, `.session.header.cwd`).
 * @param {object} [o.cfg] config: `enable40PreDigest` (false = off), `dshRoot`,
 *   `predigestBatchMax` (default 8), `predigestMaxInputTokens` (default
 *   16000), `llmTimeoutMs` (per-call, 0 = none), `llmBudgetMs` (total, 0 =
 *   none), `audit(fn)` (the ledger audit-trail sink).
 * @returns {Promise<{digested:number, batch:number, advanced?:number, reason?:string}>}
 */
export async function run40PreDigest({ client, ctx, agent, cfg = {} }) {
  const log = (ctx && ctx.logger) || { debug() {}, warn() {} };
  const audit = typeof cfg.audit === "function" ? cfg.audit : null;
  if (cfg.enable40PreDigest === false) return { digested: 0, batch: 0, reason: "off" };
  const session = (agent && agent.session && (agent.session.id || (agent.session.header && agent.session.header.id))) || "";
  if (!session) return { digested: 0, batch: 0, reason: "no-session" };
  const dshRoot = cfg.dshRoot || (process.env.HOME || "/root") + "/.dsh";
  const route = routeFromAgent(agent);
  if (!route || !safeLlm(ctx)) {
    return { digested: 0, batch: 0, reason: "no-llm" };
  }
  const segs = await resolveModelSegments(client, agent, dshRoot, session);
  if (segs.length === 0) return { digested: 0, batch: 0, reason: "no-segments" };
  const marker = preDigestMarkerBySession.get(session) || { prefixLen: 0 };
  const pending = segs.slice(marker.prefixLen);
  if (pending.length === 0) {
    marker.prefixLen = segs.length;
    preDigestMarkerBySession.set(session, marker);
    return { digested: 0, batch: 0, reason: "up-to-date" };
  }
  // The batch bounds (residual ②: earliest abort wins).
  const batchMax = Number.isFinite(cfg.predigestBatchMax) && cfg.predigestBatchMax > 0 ? cfg.predigestBatchMax : 8;
  const inputCap = Number.isFinite(cfg.predigestMaxInputTokens) && cfg.predigestMaxInputTokens > 0 ? cfg.predigestMaxInputTokens : 16000;
  const llmTimeoutMs = Number.isFinite(cfg.llmTimeoutMs) ? cfg.llmTimeoutMs : 0;
  const llmBudgetMs = Number.isFinite(cfg.llmBudgetMs) ? cfg.llmBudgetMs : 0;
  const batch = pending.slice(0, batchMax);
  const perSegCap = Math.max(512, Math.floor(inputCap / batch.length));
  const budgetCtrl = llmBudgetMs > 0 ? new AbortController() : null;
  if (budgetCtrl) {
    const t = setTimeout(() => budgetCtrl.abort(), llmBudgetMs);
    t.unref ? t.unref() : 0; // the compact must not be kept alive by the budget timer
  }
  const body = batch
    .map((s, i) => "[" + (i + 1) + "]\n" + String(s && s.text ? s.text : "").trim().slice(0, perSegCap))
    .join("\n");
  let entries = parseBatchDigestResponse("", batch.length);
  try {
    const sigs = [];
    if (llmTimeoutMs > 0) sigs.push(AbortSignal.timeout(llmTimeoutMs));
    if (budgetCtrl) sigs.push(budgetCtrl.signal);
    const callSignal = sigs.length === 1 ? sigs[0] : sigs.length > 1 ? AbortSignal.any(sigs) : undefined;
    const text = await oneShotText(ctx, {
      route,
      messages: [textUserMessage(BATCH_DIGEST_INSTRUCTION + body)],
      purpose: "digest",
      maxTokens: Math.min(4096, 400 + 120 * batch.length),
      ...(callSignal ? { signal: callSignal } : {}),
    });
    entries = parseBatchDigestResponse(text, batch.length);
  } catch (err) {
    log.warn?.("supercompress 40% pre-digest LLM degraded (the floor holds): " + String((err && err.message) || err));
    audit ? audit("predigest-llm-miss", String((err && err.message) || err)) : 0;
    entries = parseBatchDigestResponse("", batch.length); // all floors (retry next firing)
  }
  // Write-back (content-hash dedup-safe; 宁漏勿错 floor).
  let digested = 0;
  let writes = 0; // the ledger write count (drives the F2 flush below)
  for (let i = 0; i < entries.length; i += 1) {
    const e = entries[i];
    const seg = batch[i];
    if (!seg) continue;
    try {
      const got = await client.ingest(String(seg.text || ""), {
        tier: e.tier || "P1", // the P1 pre-tag floor (the batch tier refines it)
        prov: "model",
        kind: "segment",
        session: (seg.session || session),
      });
      const handle = got && got.segment_id;
      if (!handle) continue;
      writes++; // the ingest itself is a durable ledger row
      const digestText = [e.keyFact, e.summary].filter(Boolean).join("\n").trim();
      if (digestText) {
        await client.digest(handle, digestText, "pre40");
        writes++;
      }
      if (e.tier) {
        await client.tag(handle, e.tier);
        writes++;
      }
      if (e.digested) digested++;
    } catch (err) {
      log.warn?.("supercompress 40% pre-digest write degraded: " + String((err && err.message) || err));
    }
  }
  // F2 durability (the 2026-11-24 00:06 chronic-gap chain, mirroring the
  // tiering face): the batch's writes ride the Go daemon's in-memory flush
  // batch — a compact-window scd death mid-window would lose the whole
  // batch, so flush after the writes (fail-open: a flush miss degrades
  // durability only, never the band).
  if (writes > 0 && typeof client.flush === "function") {
    try {
      await client.flush();
    } catch {
      /* fail-open */
    }
  }
  // Advance the marker over the CONTIGUOUS leading successes only (a mid-
  // batch miss is retried next firing, still bounded by the cap/budget).
  let advanced = 0;
  for (let i = 0; i < entries.length; i += 1) {
    if (!(entries[i] && entries[i].digested)) break;
    advanced = i + 1;
  }
  marker.prefixLen = Math.min(segs.length, marker.prefixLen + advanced);
  preDigestMarkerBySession.set(session, marker);
  return { digested, batch: batch.length, advanced };
}