// engine-core.js — the supercompress engine override core (dependency-free,
// testable without the dsh install).
//
// withSupercompressGate(Base, opts) returns a SUBCLASS of `Base` (the host's
// compaction engine, dsh-compaction-basic's BasicCompactionEngine in
// production) whose `summarize()` override runs the supercompress P0
// write-before-compress gate BEFORE delegating to the official LLM
// summarizer + shadow commit.
//
// Why this is the mountable "P5 engine replacement": the host has no
// plugin-visible engine registry — the composition loader instantiates the
// engine row's module itself (a class plugin: `new plugin(ctx, rowConfig)`).
// And `CompactionEngine` registers itself as the `compaction` DI service via
// the Service base (`super(ctx, 'compaction')`). So a composition row whose
// `name` points at shell/engine.js (this subclass, default export) mounts it
// exactly where the host's BasicCompactionEngine row used to be:
//   - `auto: true` in the row config -> the engine's own pressure /
//     model-switch / overflow-recovery pre-step listeners register (they are
//     gated on `auto` inside the inherited constructor) -> the host's
//     context window is ACTUALLY managed again;
//   - the inherited `summarize()` replay/shadow durable-mutation strategy is
//     untouched; only the sole customization hook (`summarize()`) is wrapped
//     with the P0 gate-then-delegate below.
//
// Gate semantics (write-before-compress, fail-open):
//   1. `client.distill(cap, endpointDegraded, enable55Band)` — the Go data
//      plane persists P0 user turns + anchors into the jsonl store BEFORE the
//      host's `super.summarize()` shadows the surface region. The P0
//      originals are already durable on disk (reversible via the jsonl
//      store), so the shadow commit is safe.
//   2. R3 endpoint-degraded flag: after 3 consecutive gate failures the next
//      distill carries `endpoint_degraded: true` so the data plane releases
//      the P0 pending escape-hatch (head80 placeholder) instead of holding
//      the window over-store. A success resets the streak.
//   3. Optional 55-band LLM digest upgrade: when `enable55Band` is set,
//      evicted P1/P2 segments still on the head80 stub are upgraded to real
//      digests through the host `ctx.llm` (aux ≡ main-model endpoint, zero
//      new provider; the one-shot call reuses the host's warm prefix cache
//      shape). A miss keeps the head80 placeholder (R3 兜底, never blocks).
//
// A gate miss NEVER blocks the host's own compaction (the durable, correct
// path): every data-plane failure logs and falls through to
// `super.summarize()`.

import { parseDigestResponse } from "./tagger.js";
import { safeLlm } from "./llm-guard.js";
import { oneShotText, routeFromAgent, textUserMessage } from "./llm-one-shot.js";
import { run40PreDigest } from "./predigest.js"; // the unified 40% pre-digest face (step 3)
// tierModelSegments (./tiering.js) was the pre-consolidation O(N) burst face;
// the unified face supersedes it on the MOUNTED path (tiering.js remains for
// the unwired compaction.js path + its own tests).
import { selectCompactableRange, assertNoActiveCompaction } from "./engine-region.js";
import { backfillHandoff, readFilememShard } from "./handoff-gen.js";
import { compressPage, backfillCompressedPage } from "./page-llm.js";
import { runPreclean, precleanUserMessages } from "./preclean.js";
import { getSharedBandThresholds } from "./ipc.js";
// The ledger + deterministic-fallback summarization core now lives in the bare
// B-tier engine (engine-bare.js); the gate wrapper only runs the P0 write-
// before-compress gate + tiering + 55-band and delegates the summary source to
// `super.summarize`. No direct import of the ledger helpers is needed here.

// Same strict-JSON digest contract as the reference AuxProvider's
// COMPRESSION_TASK call; the balanced-JSON extractor tolerates code-fenced
// or prose-wrapped replies.
const DIGEST_INSTRUCTION =
  "Compress the conversation segment below into strict JSON (no code fence, no extra text):\n" +
  '{"key_fact": "<=60 chars: the single most important fact/decision", ' +
  '"summary": "<=200 chars: 2-4 sentence digest"}\n' +
  "--- segment ---\n";

// ── C tier: the "打扫房间" five-band waterline thresholds (contract v4) ──────
// The 4 thresholds are volatile knobs (row config > shared getter > env
// default 90/70/50/40). The switch in compactIfNeeded() runs HIGH-TO-LOW
// (90 -> 70 -> 50 -> 40 -> pass-through); context-overflow ALWAYS goes to the
// host super (never skipped — the fail-safe backstop, red line 5).
const C_BAND_DEFAULTS = { t90: 90, t70: 70, t50: 50, t40: 40 };

function noopLog() {
  return { debug() {}, warn() {} };
}

/**
 * Build the supercompress subclass of `Base`.
 * @param {Function} Base the host compaction engine class (must inherit
 *   CompactionEngine: `summarize(input, agent, signal)` + Service-base `ctx`).
 * @param {object} opts
 * @param {object} opts.client data-plane client (DaemonClient or a fake
 *   exposing `distill(cap, degraded, band55)` / `digest(id, text, ref)`).
 * @param {number} [opts.capacityTokens] distill window capacity (default 1000).
 *   Fallback capacity ONLY: the live resolution prefers `host contextWindow ×
 *   capacityRatio` (A2) and the env `DASHSC_CAPACITY` absolute override.
 * @param {number} [opts.capacityRatio] the data-plane ledger capacity as a
 *   fraction of the HOST context window (A2): the live default when neither
 *   the env `DASHSC_CAPACITY` nor a host contextWindow signal is available it
 *   is the `capacityTokens` fallback (default 0.5).
 * @param {boolean} [opts.enable55Band] upgrade evicted head80 stubs to LLM
 *   digests (default false).
 * @param {Function} [opts.resolveSharedCapacityRatio] live getter for the
 *   bundle's `capacityRatio` knob (A2, `.volatile()`; the mounted engine row
 *   re-reads it on every distill).
 * @returns {Function} a class; `new Engine(ctx, rowConfig)` behaves exactly
 *   like the base (static `Config` / `inject` are inherited through the
 *   prototype chain) plus the gate-then-delegate `summarize()`.
 */
export function withSupercompressGate(
  Base,
  { client, capacityTokens = 1000, capacityRatio, enable55Band = false, t90, t70, t50, t40, resolveSharedEnableTiering, resolveSharedUseLedgerSummarizer, resolveSharedCapacityRatio, resolveSharedBandThresholds, resolveSharedLiveUserTrim, resolveSharedBandGates, resolveSharedRenderLadder } = {},
) {
  if (!client || typeof client.distill !== "function") {
    throw new Error("withSupercompressGate: opts.client with distill() is required");
  }
  class SupercompressCompactionEngine extends Base {
    constructor(ctx, config = {}) {
      super(ctx, config);
      // The data-plane gate state lives on the engine instance (one engine
      // per fiber, so the fail-streak is scoped to this activation).
      this._sc = {
        client,
        capacityTokens,
        enable55Band,
        rowConfig: config,
        resolveSharedEnableTiering,
        resolveSharedUseLedgerSummarizer,
        resolveSharedCapacityRatio,
        resolveSharedBandThresholds,
        resolveSharedLiveUserTrim,
        resolveSharedBandGates,
        resolveSharedRenderLadder,
        // C tier: the 4 band threshold module defaults (the env DASHSC_T90..
        // T40, read at module evaluation; the row config + the bundle's
        // shared getter override, live on every compactIfNeeded call).
        envBandThresholds: {
          t90: typeof t90 === "number" && t90 > 0 && t90 <= 100 ? t90 : C_BAND_DEFAULTS.t90,
          t70: typeof t70 === "number" && t70 > 0 && t70 <= 100 ? t70 : C_BAND_DEFAULTS.t70,
          t50: typeof t50 === "number" && t50 > 0 && t50 <= 100 ? t50 : C_BAND_DEFAULTS.t50,
          t40: typeof t40 === "number" && t40 > 0 && t40 <= 100 ? t40 : C_BAND_DEFAULTS.t40,
        },
        envCapacityRatio:
          typeof capacityRatio === "number" && capacityRatio > 0 && capacityRatio <= 1
            ? capacityRatio
            : undefined,
        consecFails: 0,
        streakSince: 0, // G2: seconds when the current fail-streak started
        // Live user-paste trim-at-production face: the surface tail seq last
        // scanned by the live pass, PER-SESSION (one engine instance services
        // many sessions; a shared marker would make session A's tail look
        // like a rewind for session B -> repeated full rescans). A missing
        // entry = the session has not been visited yet (the lazy first visit
        // sets the marker to the then-current tail: strict 随产 semantics,
        // pre-existing nodes are NOT chased — the 40% band's user pass is
        // their fallback, quiet sessions stay pure append-only).
        liveUserTrimSeqBySession: new Map(),
      };
      // The live user-paste trim listener (registered alongside the base's
      // pressure listeners; the 40% band's user pass stays the fallback when
      // the face is off — current behavior, byte-identical). A ctx without
      // event subscription (the minimal test fakes) simply never gets the
      // live face — the 40% band remains the only user-trim path there.
      if (this.config?.auto !== false && typeof this.ctx?.on === "function") this._registerLiveUserTrim();
      // Construction marker: proves the composition row instantiated THIS
      // subclass in the running host (no "constructed" line after a restart
      // -> the row module never activated, whatever the journal says).
      this._auditLedgerBranch(undefined, "constructed", "engine row instantiated");
    }

    /** A2: live resolution of the data-plane ledger capacity budget.
     *  Resolution order (highest first):
     *   1. the env `DASHSC_CAPACITY` absolute override (read LIVE: exported
     *      between two distills applies to the second without a restart);
     *   2. the HOST context window × the `capacityRatio` fraction — read LIVE
     *      through the O(1) `tokenMeter.contextPressure` projection (the
     *      host's contextWindow scales per deployment: e.g. the dsh web host
     *      is 512000 — a fixed 1000-token ledger budget kept the 90% line at
     *      900 tokens, over-pressured against a ~17k-token live ledger, and
     *      evicted P0 uselessly onto head80 placeholders). The fraction
     *      resolves row config > the bundle-published shared getter > the
     *      env-derived module default (the `capacityRatio` option, default
     *      0.5 = the data plane carries half the host window — the recall
     *      face re-injects digests of evicted segments, so half is ample
     *      headroom while keeping the ledger dense).
     *  Fail-open: no env / no host signal / a bad ratio -> the `capacityTokens`
     *  fallback (default 1000). The resolved cap is NEVER 0: a zero would
     *  zero the data plane's waterlines (all-band full eviction) — the
     *  dangerous state this resolution exists to prevent. */
    _resolveCapacityTokens(agent) {
      const env = process.env.DASHSC_CAPACITY;
      if (env !== undefined && env !== "") {
        const v = Number(env);
        if (Number.isFinite(v) && v > 0) return v;
      }
      const p = this.ctx?.get?.("tokenMeter")?.contextPressure?.(agent?.session);
      const window = p?.contextWindow;
      const ratio =
        this._sc.rowConfig?.capacityRatio ??
        this._sc.resolveSharedCapacityRatio?.() ??
        this._sc.envCapacityRatio;
      if (typeof window === "number" && window > 0 && typeof ratio === "number" && ratio > 0) {
        return Math.max(1, Math.floor(window * ratio));
      }
      const fallback = this._sc.capacityTokens;
      return typeof fallback === "number" && fallback > 0 ? fallback : 1000;
    }

    /** Live resolution of the capacityRatio fraction (A2; see the note in
     *  `_resolveCapacityTokens`). 0 / out-of-range normalizes to unset. */
    _resolveCapacityRatio() {
      const v =
        this._sc.rowConfig?.capacityRatio ??
        this._sc.resolveSharedCapacityRatio?.() ??
        this._sc.envCapacityRatio;
      return typeof v === "number" && v > 0 && v <= 1 ? v : undefined;
    }

    /**
     * Live resolution of the C-tier band thresholds (the "打扫房间" 5-band
     * waterline, contract v4). Resolution order (highest first, per key):
     *   1. the engine row's own config (`rowConfig.t90` / `t70` / `t50` / `t40`)
     *   2. the bundle-published shared getter (`getSharedBandThresholds()`,
     *      the `.volatile()` web card fields, re-read live on every call)
     *   3. the module-level defaults (90/70/50/40, the contract v4 defaults)
     * 0 / out-of-range (not in (0,100]) normalizes to the module default
     * (fail-open: a broken card value must never disable a band).
     * @returns {{t90:number,t70:number,t50:number,t40:number}}
     */
    _resolveBandThresholds() {
      const rc = this._sc.rowConfig ?? {};
      // The shared getter (the bundle's `.volatile()` card fields, live) —
      // resolved through the engine's `resolveSharedBandThresholds` face
      // (the same pattern as the capacity-ratio getter); a bare
      // module import (the unit harness) uses the module-level getter.
      const sharedRaw = this._sc.resolveSharedBandThresholds?.() ?? getSharedBandThresholds();
      const shared = {};
      for (const k of ["t90", "t70", "t50", "t40"]) {
        const v = sharedRaw?.[k];
        if (typeof v === "number" && v > 0 && v <= 100) shared[k] = v;
      }
      const env = this._sc.envBandThresholds ?? {};
      const pick = (key) => {
        const row = rc[key];
        if (typeof row === "number" && Number.isFinite(row) && row > 0 && row <= 100) return row;
        if (typeof shared[key] === "number") return shared[key];
        if (typeof env[key] === "number" && env[key] > 0 && env[key] <= 100) return env[key];
        return C_BAND_DEFAULTS[key];
      };
      return { t90: pick("t90"), t70: pick("t70"), t50: pick("t50"), t40: pick("t40") };
    }

    /** The O(1) pressure projection (the band trigger source). */
    _bandPressure(agent) {
      const p = this.ctx?.get?.("tokenMeter")?.contextPressure?.(agent?.session);
      return { used: p?.pressureTokens ?? 0, window: p?.contextWindow ?? 0 };
    }

    /**
     * The C-tier 5-band waterline switch (contract v4, "打扫房间") — the
     * ONLY trigger policy:
     *   - context-overflow ALWAYS -> the host super (the fail-safe backstop;
     *     NEVER skipped — red line 5).
     *   - pressure: one switch on used/window, HIGH-TO-LOW, the first band
     *     hit STOPS (no fall-through to lower bands in the same call):
     *       90% -> proactive handoff (0 LLM, the three-source page)
     *       70% -> protect-tail + self-packaged LLM page compress (THE ONLY
     *              LLM COMPACTION band; fail-open to the 50% face on a miss)
     *       50% -> distill (AllSegments fold-stub) + ledger 0-LLM summarize
     *              (checkpoint 0-LLM; the distill sub-step still calls
     *              ctx.llm for the 55-band / tiering PRE-DIGEST faces when
     *              enabled — see the 50% band doc)
     *       40% -> preclean (deterministic 0-LLM: tool-result middle +
     *              user long-paste middle trim)
     *       <40% -> pass-through (the host's native pressure compaction
     *              decides)
     * No meter (no O(1) pressure projection) -> the host decides
     * (fail-open). Every band handler is fail-open: a miss (no meter / no
     * range / a daemon down) falls through to the next lower band or the
     * host super — never a broken compact.
     * @param {object} agent host Agent
     * @param {"pressure"|"context-overflow"} trigger
     * @param {AbortSignal} [signal]
     */
    async compactIfNeeded(agent, trigger, signal) {
      if (trigger === "context-overflow") {
        // Red line 5: the host's overflow-recovery backstop is NEVER skipped
        // by the C-band switch (the 40% preclean may have cut the tool/user
        // middles, but a real overflow still gets the full host compact).
        return await super.compactIfNeeded(agent, trigger, signal);
      }
      const { used, window } = this._bandPressure(agent);
      if (!window) {
        // No O(1) pressure projection -> the host decides (fail-open).
        return await super.compactIfNeeded(agent, trigger, signal);
      }
      const { t90, t70, t50, t40 } = this._resolveBandThresholds();
      // Per-band GATES (the card refactor 2026-11-26): the bundle row's four
      // card switches (enableBand90/70/50/40, published live by the bundle's
      // setSharedBandGatesGetter). UNSET / no getter = the band stays ENABLED
      // (fail-open, module default); only an explicit false disables a band —
      // a disabled band is SKIPPED and the switch continues down to the next
      // enabled band (the high-to-low first-hit-stops contract is preserved
      // among the enabled bands).
      const gates = this._sc.resolveSharedBandGates?.() ?? null;
      const bandOn = (k) => gates?.[k] !== false;
      const frac = (used / window) * 100; // percentage (the band scale)
      if (frac >= t90 && bandOn("b90")) {
        const r = await this._bandHandoff(agent, signal); // 90%: 0-LLM handoff
        if (r) return r;
        // fail-open: the handoff miss falls to the 70% band (not the host).
      }
      if (frac >= t70 && bandOn("b70")) {
        const r = await this._bandPageLlm(agent, signal); // 70%: the ONLY LLM band
        if (r) return r;
        // fail-open: the LLM miss falls to the 50% band (deterministic).
      }
      if (frac >= t50 && bandOn("b50")) {
        const r = await this._bandDistillLedger(agent, signal); // 50%: 0-LLM
        if (r) return r;
      }
      if (frac >= t40 && bandOn("b40")) {
        const r = await this._bandPreclean(agent, signal); // 40%: 0-LLM
        if (r) return r;
      }
      // <40%: pass-through (no band hit -> the host's native pressure
      // compaction decides).
      return await super.compactIfNeeded(agent, trigger, signal);
    }

    // ── C-band 90%: the proactive handoff (0 LLM, the three-source page) ────
    /**
     * The 90% band: compose the handoff page from the three filemem sources
     * (the compact-ledger c#N blocks + the paged ledger digest = 台账段; the
     * per-session shard filemem rows = 台账行; the host zstd session events
     * = 宿主 session 段) and backfill it as ONE user/message surfaceOp
     * replace over the shadowed range — the host's frameSummary()
     * <compacted-summary> frame + compactCheckpointSource (the durable
     * checkpoint is byte-identical to a host compact; system node0 + the
     * pre-range prefix are NEVER rewritten). One live handoff per source
     * (replace, never append — re-handoff replaces the page, red line 4).
     * 0 LLM: the page is deterministic segment concatenation (llm_used=false,
     * auditable, the filemem fallback posture).
     * @returns {Promise<object|null>} the handoff result (null on a miss —
     *   the caller falls to the 70% band).
     */
    async _bandHandoff(agent, signal) {
      const log = this.ctx?.logger || noopLog();
      const session = agent?.session;
      if (!session?.surface?.nodes?.length) return null;
      try {
        const meter = this.ctx.get("tokenMeter");
        const measurement = meter?.measure?.(session);
        if (!measurement) return null; // no meter -> the host's trigger policy decides
        // The shadowed range: the first non-system node through the host's
        // retained tail boundary (the `retainTokens` protect-tail strategy —
        // the tail stays uncompressed for the next turn).
        const policy = this._sc.rowConfig?.modelPolicies?.[0];
        const retainTokens =
          policy?.retainTokens ??
          Math.floor(measurement.totalTokens * (policy?.retainRatio ?? 0.16));
        const range = selectCompactableRange(session, measurement, retainTokens);
        if (range === null) return null;
        // Red lines 1/2/7: the range starts at the first NON-system node
        // (system node0 is OUTSIDE the shadowed range — its bytes are never
        // rewritten; the host's next assemble re-prepends them verbatim).
        const nodes = session.surface.nodes;
        const startIdx = nodes.indexOf(range.start);
        const handoffStart =
          startIdx === 1 && session.eventAt(nodes[0])?.type === "system/message" ? nodes[1] : range.start;
        // ── source 1: the compact-ledger c#N blocks (P0/P1/P2 digests) ────
        let ledgerSegments = [];
        try {
          const text = await this._sc.client?.compactLedger?.("text", { text: "" });
          const t = String(text?.text ?? text ?? "").trim();
          if (t) ledgerSegments = t.split(/\n+/).map((s) => s.trim()).filter(Boolean);
        } catch {
          /* daemon down: the ledger segments degrade to [] (the page still composes) */
        }
        // ── source 2: the paged session ledger digest (P0 structural floor) ──
        let digestText = "";
        try {
          const sd = await this._sc.client?.sessionDigest?.(String(session.id ?? ""), 4096);
          digestText = String(sd?.text ?? "").trim();
        } catch {
          /* daemon down: the digest degrades to "" (the page still composes) */
        }
        // ── source 3a: the per-session filemem shard rows ([filemem/<type>]) ──
        const storeDir = this._sc.client?.storePath ? String(this._sc.client.storePath).replace(/\/[^/]+$/, "") : "";
        const filememRows = storeDir ? readFilememShard(storeDir, String(session.id ?? ""), 200) : [];
        // ── source 3b: the host zstd session events (the R2 source) ────────
        let hostEvents = [];
        try {
          const res = await this._sc.client?.hostUserSegments?.(
            `${storeDir || ""}/host-sessions/${session.id ?? ""}.jsonl`,
          );
          for (const seg of res?.segments ?? []) hostEvents.push(`[dsh/user] ${String(seg.text ?? "").trim()}`);
        } catch {
          /* host log miss: the R2 source degrades to [] (the ledger + rows are the floor) */
        }
        const shadowedSeqs = session.surface.nodes.slice(session.surface.nodes.indexOf(handoffStart), session.surface.nodes.indexOf(range.end) + 1);
        const page = backfillHandoff(
          session,
          handoffStart,
          range.end,
          String(session.id ?? ""),
          { ledgerSegments, digestText, filememRows, hostEvents },
          meter,
        );
        if (!page.ok) {
          log.warn?.(`supercompress 90% handoff: ${page.reason}; falling to the 70% band`);
          return null;
        }
        log.debug?.(
          `supercompress 90% band: handoff page backfilled (0 LLM, llm_used=false; ` +
            `ledger=${ledgerSegments.length} segs, digest=${digestText.length}c, filemem=${filememRows.length} rows, host=${hostEvents.length} evs)`,
        );
        this._auditLedgerBranch(agent, "c-band-90-handoff", "deterministic page (llm_used=false)");
        // The host's CompactionResult shape (the contract-alignment face: the
        // band's result carries the fixed shape the host's logResult + replay
        // faces consume — compactionId / startSeq / summarySeq / endSeq /
        // summary / shadowedRange / shadowedSeqs / shadowedTokenCount) + the
        // band identity. The self-call backfill emitted the full host lock /
        // event sequence: compaction/start -> compaction/summary -> user/message
        // replace -> compaction/end.
        return {
          trigger: "pressure",
          band: "90-handoff",
          compactionId: page.compactionId,
          startSeq: page.startSeq,
          summarySeq: page.summarySeq,
          endSeq: page.endSeq,
          summary: page.summary,
          shadowedRange: page.shadowedRange,
          shadowedSeqs: [...shadowedSeqs],
          shadowedTokenCount: page.shadowedTokenCount,
        };
      } catch (err) {
        log.warn?.(`supercompress 90% handoff degraded: ${err?.message ?? err}; falling to the 70% band`);
        return null;
      }
    }

    // ── C-band 70%: the ONLY LLM band (protect-tail + self-packaged page) ──
    /**
     * The 70% band: keep the host's retained tail (the `retainTokens`
     * protect-tail strategy, T1) and compress the FIRST N shadowed pages of
     * it through the self-packaged one-shot LLM call (the host's ctx.llm
     * runtime, the RIWAY30 gateway's main-model endpoint — zero new
     * provider). The prompt is [system(head)+被压段] (the host's warm-prefix
     * structure, red line 3 — the gateway's KV cache hits, no cold start).
     * The backfill is ONE user/message surfaceOp replace over [start,end]
     * (the host's frameSummary + compactCheckpointSource, red lines 1/2/7:
     * system node0 + the pre-range prefix are NEVER rewritten).
     * Fail-open: a miss (no route / empty reply / shrink failure) returns
     * null — the caller falls to the 50% band (deterministic, 0 LLM).
     * @returns {Promise<object|null>}
     */
    async _bandPageLlm(agent, signal) {
      const log = this.ctx?.logger || noopLog();
      const session = agent?.session;
      if (!session?.surface?.nodes?.length) return null;
      try {
        // THE 40% CLEANUP PRE-STEP (owner ruling 2026-11-25: 70% 前先打扫):
        // run the deterministic 40% cleanup (0 LLM, idempotent) BEFORE the
        // merge span is rendered — the raw bloat (untrimmed tool dumps /
        // long user pastes) must not be folded into the durable page-compress
        // checkpoint (the merged page is the next round's p-anchor; garbage
        // baked in would ride every future round). A single-node in-place
        // replace changes no seqs, so the range selection below is unchanged;
        // the spanText it renders is the slimmed one. A no-op when the 40%
        // band already cleaned (trimmed nodes are below threshold).
        const pre = await this._run40PrecleanPass(agent);
        const preCuts = pre.result.pruned + pre.result.trimmed;
        if (preCuts > 0) {
          const preChars = pre.result.charsRemoved + pre.result.userCharsRemoved;
          log.debug?.(
            `supercompress 70% band pre-step: the 40% cleanup cut ${preChars} chars ` +
              `(${pre.result.pruned} tool + ${pre.result.trimmed} user, 0 LLM) before the LLM merge`,
          );
          this._auditLedgerBranch(agent, "c-band-70-prescan", `cut ${preChars}c (${pre.result.pruned} tool + ${pre.result.trimmed} user, 0 LLM)`);
        }
        const meter = this.ctx.get("tokenMeter");
        const measurement = meter?.measure?.(session);
        if (!measurement) return null; // no meter -> the 50% band serves instead
        // The host's retained tail (the protect-tail strategy, T1): the
        // last `retainTokens` worth of surface stays uncompressed. The
        // resolution follows the row config's modelPolicies (the host's own
        // retainTokens / retainRatio — the B-tier engine's `config` face).
        const policy = this._sc.rowConfig?.modelPolicies?.[0];
        const retainTokens =
          policy?.retainTokens ??
          Math.floor(measurement.totalTokens * (policy?.retainRatio ?? 0.16));
        // Checkpoint protection "first" (the 4-band redesign): only the p1
        // anchor stays OUT of the span (start = after the FIRST compact
        // checkpoint); p2..pn stay in the span as the LLM-combine inputs.
        // No prior checkpoints on the surface -> the baseline range (the LLM
        // page becomes p1).
        const range = selectCompactableRange(session, measurement, retainTokens, "first");
        if (range === null) return null;
        // Red lines 1/2/7: the range starts at the first NON-system node
        // (system node0 is OUTSIDE the compressed span — its bytes are
        // reused verbatim as the LLM call's warm prefix, never rewritten).
        const nodes = session.surface.nodes;
        const llmStartIdx = nodes.indexOf(range.start);
        const llmStart =
          llmStartIdx === 1 && session.eventAt(nodes[0])?.type === "system/message" ? nodes[1] : range.start;
        // The shadowed span's rendered text (the compressed pages, head +
        // mid — the tail AFTER range.end stays intact for the next turn).
        const shadowed = session.surface.nodes.slice(session.surface.nodes.indexOf(llmStart), session.surface.nodes.indexOf(range.end) + 1);
        const spanText = shadowed
          .map((seq) => {
            const ev = session.eventAt(seq);
            const msg = session.deriveEventMessage(ev);
            if (!msg) return "";
            return Array.isArray(msg.content)
              ? msg.content.map((b) => (b?.type === "text" ? String(b.text ?? "") : "")).join(" ")
              : String(msg.content ?? "");
          })
          .filter(Boolean)
          .join("\n");
        if (!spanText.trim()) return null; // nothing to compress
        // The system head (node0, REUSED byte-for-byte — never rebuilt, red
        // lines 1/2/7): the host's own system message as assembled on the
        // surface (the warm-prefix system the LLM call's prompt carries).
        const headSeq = session.surface.nodes[0];
        const headEv = session.eventAt(headSeq);
        const systemText =
          headEv?.type === "system/message"
            ? (() => {
                const m = session.deriveEventMessage(headEv);
                return Array.isArray(m?.content)
                  ? m.content.map((b) => (b?.type === "text" ? String(b.text ?? "") : "")).join("")
                  : String(m?.content ?? "");
              })()
            : "";
        // 残留② (the 2026-11-23 compact-window LLM BOUND, carried to the 70%
        // band): the single one-shot page-compress call races the host's
        // compact signal + the per-call timeout + the total budget
        // (earliest abort wins — a degraded endpoint must never hold the
        // compact window open; a miss falls to the 50% band, 0 LLM).
        const sigs = [];
        if (signal && !signal.aborted) sigs.push(signal);
        const tMs = Number(this._sc.rowConfig?.tierLlmTimeoutMs);
        const bMs = Number(this._sc.rowConfig?.tierLlmBudgetMs);
        if (Number.isFinite(tMs) && tMs > 0) sigs.push(AbortSignal.timeout(tMs));
        if (Number.isFinite(bMs) && bMs > 0) {
          const bc = new AbortController();
          const t = setTimeout(() => bc.abort(), bMs);
          t.unref?.(); // the budget timer must not keep the process alive
          sigs.push(bc.signal);
        }
        const callSignal = sigs.length === 1 ? sigs[0] : sigs.length > 1 ? AbortSignal.any(sigs) : undefined;
        const r = await compressPage({
          ctx: this.ctx,
          systemText,
          spanText,
          agent,
          signal: callSignal,
          maxTokens: 512,
        });
        if (!r.ok) {
          log.debug?.(`supercompress 70% band: LLM page miss (${r.reason}); falling to the 50% band`);
          this._auditLedgerBranch(agent, "c-band-70-llm-miss", r.reason);
          return null; // fail-open: the 50% band (0 LLM) serves the compact
        }
        const backfill = backfillCompressedPage(session, llmStart, range.end, r.body, meter);
        if (!backfill.ok) return null;
        log.debug?.(
          `supercompress 70% band: LLM page compressed ${spanText.length}c -> ${r.body.length}c ` +
            `(the ONLY LLM band; the warm-prefix system head reused byte-for-byte)`,
        );
        this._auditLedgerBranch(agent, "c-band-70-llm", `compressed ${spanText.length}c -> ${r.body.length}c`);
        // The host's CompactionResult shape (the contract-alignment face: the
        // band's result carries the fixed shape the host's logResult + replay
        // faces consume — compactionId / startSeq / summarySeq / endSeq /
        // summary / shadowedRange / shadowedSeqs / shadowedTokenCount) + the
        // band identity. The self-call backfill emitted the full host lock /
        // event sequence: compaction/start -> compaction/summary -> user/message
        // replace -> compaction/end.
        return {
          trigger: "pressure",
          band: "70-llm",
          compactionId: backfill.compactionId,
          startSeq: backfill.startSeq,
          summarySeq: backfill.summarySeq,
          endSeq: backfill.endSeq,
          summary: backfill.summary,
          shadowedRange: backfill.shadowedRange,
          shadowedSeqs: [...shadowed],
          shadowedTokenCount: backfill.shadowedTokenCount,
        };
      } catch (err) {
        log.warn?.(`supercompress 70% band degraded: ${err?.message ?? err}; falling to the 50% band`);
        return null;
      }
    }

    // ── C-band 50%: distill (AllSegments fold-stub) + ledger 0-LLM ────────
    /**
     * The 50% band: run the P0 distill gate (the AllSegments fold-stub:
     * evicted P1/P2 segments become head80 placeholders, the data-plane
     * window compresses) + the ledger 0-LLM summarize face (the B-tier
     * `summarizeFromLedger` / deterministic-fallback core).
     *
     * LLM SCOPE (the old "the band NEVER calls the host LLM" line is STALE
     * — it predates the 55-band / tiering pre-digest faces): the CHECKPOINT
     * COMPOSITION is 0-LLM (summarize() reads the pre-digested ledger or
     * composes the deterministic fallback; no ctx.llm at compact time). But
     * the DISTILL sub-step (`_p0Gate`) DOES call the host ctx.llm for
     * PRE-DIGESTION when those faces are on: the 55-band upgrade
     * (`enable55Band`, evicted head80 stubs -> LLM digests; default OFF,
     * this deployment: ON) and the tiering ingest (`enableTiering`,
     * per-segment LLM digests, default ON, the llmCap/llmBudgetMs-bounded
     * burst). So the 0-LLM-at-compact-time is PAID FOR by a FOREGROUND,
     * IN-COMPACT-WINDOW LLM burst — it runs synchronously inside THIS
     * compact (there is NO background scheduler that pre-digests between
     * compacts; the digests are produced during the compact, written to the
     * ledger, and reused by LATER compacts / recall). It is bounded by
     * llmCap/llmBudgetMs precisely because an unbounded in-window burst
     * once held the compact open on a degraded endpoint (the 2026-11-23
     * "compact-window LLM BOUND" fix). The 70% band remains the only LLM
     * COMPACTION tier (its ctx.llm call IS the compact; the 55-band /
     * tiering calls are in-window ledger maintenance, not the compact).
     * Fail-open: a daemon miss runs the P0 gate with the degraded flag
     * (the head80 escape-hatch releases) and the ledger face composes the
     * deterministic fallback (no shrink -> the host compact is REFUSED,
     * the next trigger retries — the P1 refusal ruling).
     * @returns {Promise<object|null>}
     */
    async _bandDistillLedger(agent, signal) {
      const log = this.ctx?.logger || noopLog();
      try {
        // The P0 write-before-compress gate (the distill AllSegments
        // fold-stub: evicted P1/P2 -> head80 placeholders, the window
        // compresses WITHOUT an LLM call).
        await this._p0Gate(agent);
        log.debug?.("supercompress 50% band: distill gate ran (AllSegments fold-stub, 0 LLM)");
        this._auditLedgerBranch(agent, "c-band-50-distill", "distill + ledger (0 LLM)");
        // The actual host compact (the ledger 0-LLM summarize face is the
        // B-tier engine's `summarize()` — the 50% band DELEGATES to the
        // host's own compactIfNeeded, which runs the B-tier 0-LLM path).
        // Checkpoint protection "all": the B-tier range selector shadows only
        // the NEW tail (start = after the LAST compact checkpoint — every
        // prior bound page stays put, the incremental 装订; the 4-band
        // redesign). Scoped to this delegation (cleared in the finally) so
        // the 40% / overflow / host-native paths keep the baseline firstIdx
        // rule.
        if (agent && typeof agent === "object") agent._scProtect = "all";
        try {
          return await super.compactIfNeeded(agent, "pressure", signal);
        } finally {
          if (agent && typeof agent === "object") delete agent._scProtect;
        }
      } catch (err) {
        log.warn?.(`supercompress 50% band degraded: ${err?.message ?? err}`);
        return null;
      }
    }

    // ── C-band 40%: the deterministic preclean (0 LLM) ────────────────────
    /**
     * The 40% band: the deterministic 0-LLM preclean (裁中间, 不碰语义):
     *   1. tool-result middle trim (the host's ToolResultPruner face:
     *      head4096 + marker + tail1024, threshold8192 — the host defaults,
     *      the shadow-event + in-place-replace + old-node-retained log
     *      mechanism, replay-deterministic).
     *   2. user long-paste middle trim (a single user message over the
     *      threshold gets its middle cut to head+marker+tail; the user's
     *      instruction head + tail survive; host-generated checkpoints /
     *      recall tails / filemem lanes are PROTECTED — red line 6: 40%
     *      档 0 LLM, 只做确定性裁中间, 不碰语义).
     * The system node0 + the tools + the pre-range prefix bytes are NEVER
     * rewritten (each trim is a single-node surfaceOp replace, red lines
     * 1/2/7). Fail-open: a trim miss never blocks the host (the next
     * trigger retries; the overflow backstop is unchanged).
     * @returns {Promise<object|null>}
     */
    /**
     * The 40% band's DETERMINISTIC cleanup pass, extracted as a reusable
     * pre-step (the 4-band redesign): both deterministic passes (tool-result
     * middle trim + user long-paste middle trim) WITHOUT the pre-digest face
     * (the 70% band's pre-step must stay 0-LLM and must not spend the
     * pre-digest call). Idempotent — a trimmed node is head+marker+tail
     * (below the threshold) so a re-run is a no-op — and red-line safe
     * (every trim is a single-node in-place surfaceOp replace; the node seqs
     * are unchanged, so the band's range selection over the surface is
     * unaffected). The 70% band calls it before the LLM merge so the raw
     * bloat (tool dumps / long pastes) is slimmed OUT of the span BEFORE it
     * gets folded into the durable page-compress checkpoint (garbage baked
     * into the p-anchor would ride every future round).
     * @returns {Promise<{result: object}>} the runPreclean result
     */
    async _run40PrecleanPass(agent) {
      const session = agent?.session;
      if (!session?.surface?.nodes?.length) return { result: { pruned: 0, trimmed: 0, charsRemoved: 0, userCharsRemoved: 0 } };
      // The shadow-token estimator (the host pruner's shadow-price face):
      // the host's own token meter prices each shadowed node.
      const meter = this.ctx?.get("tokenMeter");
      const { setShadowTokenEstimator, runPreclean } = await import("./preclean.js");
      if (meter) {
        setShadowTokenEstimator(() => 0); // the host pruner prices via ctx; a plain-preclean has no ctx — 0 is safe (the shadow event still cites the node)
      }
      // The tool pass keeps the host pruner defaults ({}); the user pass
      // reads the shared user-paste knobs (the live face and this pass
      // trim with ONE semantic — the defaults are byte-identical to the
      // pre-live behavior when the row config leaves them unset).
      const result = runPreclean(session, {}, this._userPasteOpts());
      return { result };
    }

    async _bandPreclean(agent, signal) {
      const log = this.ctx?.logger || noopLog();
      const session = agent?.session;
      if (!session?.surface?.nodes?.length) return null;
      try {
        // The deterministic cleanup (shared pre-step; the 40% band adds the
        // pre-digest face below as its PRIMARY execution point).
        const { result } = await this._run40PrecleanPass(agent);
        // The unified 40% pre-digest face (the 4-band redesign step 3) — the
        // PRIMARY execution point: one batched LLM digest of the session's
        // not-yet-digested model segments into the ledger (idempotent via the
        // per-session marker; bounded by the tierLlm* residual-② bounds;
        // fail-open). It runs even when the deterministic preclean is a
        // no-op: the 40% band is the earliest pressure waterline ("打扫房间"),
        // and the digest is what READS AHEAD for the 50% band's 0-LLM bind
        // (the rich-digest page instead of a head80 stub).
        let pd = null;
        if (this._resolveEnable40PreDigest() !== false) {
          try {
            pd = await run40PreDigest({
              client: this._sc.client,
              ctx: this.ctx,
              agent,
              cfg: {
                enable40PreDigest: true,
                dshRoot: this._sc.rowConfig?.dshRoot,
                llmTimeoutMs: this._sc.rowConfig?.tierLlmTimeoutMs,
                llmBudgetMs: this._sc.rowConfig?.tierLlmBudgetMs,
                predigestBatchMax: this._sc.rowConfig?.predigestBatchMax,
                predigestMaxInputTokens: this._sc.rowConfig?.predigestMaxInputTokens,
                audit: (branch, reason) => this._auditLedgerBranch(agent, "c-band-40-predigest-" + branch, reason),
              },
            });
          } catch (err) {
            log.warn?.(`supercompress 40% band pre-digest degraded: ${err?.message ?? err}`);
          }
        }
        const pdDigested = pd?.digested ?? 0;
        if (result.pruned === 0 && result.trimmed === 0 && pdDigested === 0) {
          log.debug?.(
            "supercompress 40% band: no-op (nothing over threshold; pre-digest " +
              (pd?.reason ?? "face off") + ")",
          );
          return null; // nothing acted -> the host's normal trigger policy decides
        }
        log.debug?.(
          `supercompress 40% band: preclean cut ${result.charsRemoved + result.userCharsRemoved} chars ` +
            `(${result.pruned} tool results + ${result.trimmed} user messages; 0 LLM, deterministic middle-trim)` +
            (pdDigested > 0 ? `; pre-digest ${pdDigested} model segments (batched, 1 LLM call)` : `; pre-digest no-op (${pd?.reason ?? "off"})`),
        );
        this._auditLedgerBranch(
          agent,
          "c-band-40-preclean",
          `cut ${result.charsRemoved + result.userCharsRemoved} chars (0 LLM)` + (pdDigested > 0 ? `; pre-digest ${pdDigested}` : ""),
        );
        return {
          trigger: "pressure",
          band: "40-preclean",
          charsRemoved: result.charsRemoved + result.userCharsRemoved,
          preDigest: pdDigested,
        };
      } catch (err) {
        log.warn?.(`supercompress 40% preclean degraded: ${err?.message ?? err}`);
        return null;
      }
    }

    /**
     * The live user-paste trim-at-production listener (0 LLM, deterministic
     * middle-trim of user long-pastes at every step boundary — a long user
     * paste is cut BEFORE the model's next call, regardless of the watermark;
     * the 40% band's user pass stays the fallback when the face is off).
     *
     * Registered on `agent/pre-step` alongside the base's pressure listener.
     * Order-agnostic by construction: the trim is idempotent (a trimmed node
     * is head+marker+tail ~5150 chars < the threshold -> skipped), so the
     * live pass and the 40% band's user pass commute — whichever runs first
     * trims, the other finds nothing; no double shadow event ever.
     *
     * Red lines honored:
     *  - single-node surfaceOp replace + the shadow event appended AFTER the
     *    touched node (the host pruner's exact mechanism; the prefix-cache
     *    red lines 1/2/7: system node0 / tools / the pre-node prefix are
     *    never rewritten);
     *  - protected envelopes (checkpoints / recall tails / filemem lanes /
     *    system-reminders) byte-protected — the SAME semantic as the 40%
     *    band's user pass (one trim semantic, no divergence, red line 6);
     *  - busy guard: a compaction in flight -> the pass is skipped (fail-
     *    open; the next pre-step or the 40% band picks it up, never blocks).
     */
    _registerLiveUserTrim() {
      const { ctx } = this;
      ctx.on(
        "agent/pre-step",
        async ({ agent, signal }, next) => {
          if (!signal?.aborted) {
            try {
              await this._liveUserTrimPass(agent);
            } catch (err) {
              // Fail-open: the live face NEVER blocks the host step; the 40%
              // band (or the next pre-step) picks the trim up later.
              ctx.logger.warn?.(`live user-paste trim failed: ${err?.message ?? err}; continuing the turn`);
            }
          }
          return next();
        },
      );
    }

    /** One live trim pass: the user long-paste middle-trim over the surface
     *  nodes NEWER than the session's last pass (O(delta); rewind -> full
     *  rescan). The session's FIRST visit only arms the marker at the
     *  current tail (strict 随产: pre-existing nodes are never chased —
     *  the 40% band's user pass stays their fallback; quiet sessions stay
     *  pure append-only, zero cache invalidation). The face is off unless
     *  the row config enables it (`liveUserTrim: true` — default false =
     *  the 40% band's user pass is the only user-trim path, the pre-live
     *  behavior). */
    async _liveUserTrimPass(agent) {
      // The settings card's volatile toggle OVERRIDES the row config
      // (instant, no restart — re-read every tick); an unset card value
      // (undefined) lets the row config's `liveUserTrim` speak.
      const liveOn = this._sc.resolveSharedLiveUserTrim?.() ?? this.config?.liveUserTrim;
      if (liveOn !== true) return; // off (or unset row): the 40% band's user pass is the only path
      const session = agent?.session;
      const nodes = session?.surface?.nodes;
      if (!nodes?.length) return;
      // Busy guard: never mutate the surface under an in-flight compaction
      // (the overflow-recovery path compacts within the open step; an
      // unmatched start would make this pass race the region transaction).
      try {
        assertNoActiveCompaction(session, "live-user-trim");
      } catch {
        return; // defer: the 40% band or the next pre-step trims it
      }
      const st = this._sc;
      const tail = nodes[nodes.length - 1];
      const sid = String(session.id ?? "");
      let since = st.liveUserTrimSeqBySession.get(sid);
      if (since === undefined) {
        // LAZY FIRST VISIT (the strict 随产 semantics): the marker starts at
        // the CURRENT tail — nodes that predate this engine instance's first
        // view of the session (a restart / resume) are NOT chased. A deep
        // catch-up trim would be a one-shot recompute of the whole suffix
        // (the measured 22%-hit cold jump on resume); instead pre-existing
        // long pastes fall back to the 40% band's user pass (full scan at
        // >=40%), and quiet (<40%) sessions stay pure append-only — zero
        // cache invalidation. The delta starts at the NEXT pass.
        st.liveUserTrimSeqBySession.set(sid, tail);
        return;
      }
      // Rewound (or no new surface node since the last pass) -> rescan from
      // the head: a rewind can restore an UNTRIMMED original under an
      // already-scanned seq (the in-place replace's shadow event was
      // truncated), so the "everything <= marker is scanned" invariant no
      // longer holds. The rescan is idempotent (trimmed nodes skip), the
      // cost is one full-scan no-op — the 40% band pays the same.
      if (tail <= since) since = 0;
      const result = precleanUserMessages(session, { ...this._userPasteOpts(), sinceSeq: since });
      st.liveUserTrimSeqBySession.set(sid, tail);
      // Map hygiene: a forgotten marker is safe (its session re-enters the
      // lazy first-visit path = no chase, no rescan storm).
      if (st.liveUserTrimSeqBySession.size >= 1024) st.liveUserTrimSeqBySession.clear();
      if (result.trimmed > 0) {
        this.ctx?.logger?.debug?.(
          `supercompress live user-trim: trimmed ${result.trimmed} user message(s) ` +
            `(${result.charsRemoved} chars cut; 0 LLM, deterministic middle-trim at production)`,
        );
        this._auditLedgerBranch(
          agent,
          "live-user-trim",
          `trimmed ${result.trimmed} user nodes, removed ${result.charsRemoved} chars (0 LLM, at production)`,
        );
      }
    }

    /** The user long-paste trim knobs (shared by the live face AND the 40%
     *  band's user pass — one semantic, no divergence). Row config > the
     *  preclean.js USER_* defaults (8192/4096/1024). */
    _userPasteOpts() {
      const c = this.config ?? {};
      return {
        thresholdChars: c.userPasteThresholdChars ?? 8192,
        headChars: c.userPasteHeadChars ?? 4096,
        tailChars: c.userPasteTailChars ?? 1024,
      };
    }

    /**
     * The sole override: P0 write-before-compress gate FIRST, then the
     * summary source — ALWAYS 0-LLM for the CHECKPOINT (the B-tier
     * `summarize` never invokes the host ctx.llm summarizer): the
     * ledger-backed composition when the live `useLedgerSummarizer` knob is
     * on, and the deterministic fallback (0 LLM; a no-shrink REFUSAL, not
     * an LLM fallback) when the ledger is off or misses — the
     * unmarked-SummaryResult contract. NOTE this scopes to the checkpoint
     * only: the P0 distill sub-step (`_p0Gate`) still calls ctx.llm for
     * the 55-band / tiering PRE-DIGEST faces when they are on (see the 50%
     * band doc). The durable-mutation + checkpoint framing below
     * summarize() stays fixed.
     * @param {object} input host SummarizationInput
     * @param {object} agent host Agent (route source for the digest face)
     * @param {AbortSignal} [signal]
     */
    /** Durable, logger-INDEPENDENT audit trail: one JSONL line per compact
     *  into <storeDir>/ledger-audit.jsonl (the mounted engine's ctx.logger
     *  may be a no-op / absent, which left the 16:28 LLM-path compact with
     *  zero observable trail). The next acceptance pass reads this file. */
    _auditLedgerBranch(agent, branch, reason) {
      // Fire-and-forget (the module is ESM; no sync require of node:fs).
      void (async () => {
        try {
          const { appendFileSync } = await import("node:fs");
          _appendAuditLine(appendFileSync, this._sc, agent, branch, reason);
        } catch {
          /* audit is best-effort; never breaks the compact */
        }
      })();
    }

    async summarize(input, agent, signal) {
      // Enter marker FIRST (before any await): proves this override actually
      // ran for the compact — a compact with no "enter" line did NOT go
      // through the mounted engine (the host used its built-in service).
      const ledger = this._resolveUseLedgerSummarizer();
      this._auditLedgerBranch(agent, "enter", JSON.stringify({
        ledgerOn: ledger.on,
        source: ledger.source,
      }));
      await this._p0Gate(agent);
      // Hand the gate state (data-plane client + resolved ledger face) + the
      // audit hook to the bare engine's `super.summarize` through the `agent`
      // argument (the bare B-tier class owns the ledger + deterministic-fallback
      // core; the gate owns the P0 distill + tiering + 55-band + live knob).
      // When the bare class is driven WITHOUT the gate (the unit harness) these
      // fields are absent and its default is ledger-OFF -> the deterministic
      // fallback (0 LLM, no host LLM summarizer).
      agent && typeof agent === "object" && (agent._scGate = { client: this._sc.client, ledgerOn: ledger.on, ledgerSource: ledger.source, ladder: (this._sc.resolveSharedRenderLadder ?? (() => ({ on: false })))() }, agent._scAudit = this._auditLedgerBranch.bind(this));
      return await super.summarize(input, agent, signal);
    }

    /**
     * Live resolution of the ledger-summarizer on/off (env override, then the
     * bundle's volatile shared value; default OFF = the host LLM path).
     * @returns {{on: boolean, source: string}}
     */
    _resolveUseLedgerSummarizer() {
      const env = process.env.DASHSC_LEDGER_SUMMARIZER;
      if (env !== undefined && env !== "") return { on: env === "1", source: "env DASHSC_LEDGER_SUMMARIZER" };
      return { on: this._sc.resolveSharedUseLedgerSummarizer?.() ?? false, source: "the bundle's useLedgerSummarizer value (shared getter)" };
    }

    /** Persist the P0 face of the shadowed region; upgrade evicted stubs. Fail-open. */
    async _p0Gate(agent) {
      const { client, consecFails } = this._sc;
      const log = this.ctx?.logger || noopLog();
      // A2: the ledger capacity budget follows the HOST context window live
      // (host contextWindow × capacityRatio), with the env DASHSC_CAPACITY
      // absolute override on top and the fail-open fallback to the static
      // `capacityTokens` (default 1000) when no host signal is available.
      // NEVER 0: a zero cap would zero the data plane's waterlines.
      const capacityTokens = this._resolveCapacityTokens(agent);
      const capSrc = process.env.DASHSC_CAPACITY
        ? "env DASHSC_CAPACITY"
        : this.ctx?.get?.("tokenMeter")?.contextPressure?.(agent?.session)?.contextWindow
          ? "host contextWindow × capacityRatio"
          : "fallback";
      // G2: R3 cooldown backoff window — the data plane computes the effective
      // remaining cooldown from this fail-streak state and HOLDS the P0 pending
      // escape while the degraded endpoint is still inside it.
      const nowSec = () => Date.now() / 1000;
      const cooldown =
        consecFails >= 1
          ? { level: consecFails, since: this._sc.streakSince || nowSec(), now: nowSec(), base: 60 }
          : {};
      try {
        // The Go-side digest flag now rides the UNIFIED 40% pre-digest knob
        // (step 3: the 55-band face was retired into it — "evicted stubs may
        // get a rich digest" is the same semantics under the new name).
        const dist = await client.distill(capacityTokens, consecFails >= 3, this._resolveEnable40PreDigest(), cooldown);
        this._sc.consecFails = 0; // success -> endpoint/data-plane recovered
        this._sc.streakSince = 0;
        log.debug?.(
          `supercompress engine gate: distill ${dist?.status}, kept_p0=${(dist?.kept_p0 || []).length}` +
            ` (cap=${capacityTokens} via ${capSrc})`,
        );
        // The 55-band head80-stub upgrade was RETIRED here (step 3): the
        // unified pre-digest face below subsumes it (the 40% band's primary
        // execution + this P0-gate fallback leg, marker-gated).
      } catch (err) {
        // fail-open: a data-plane miss must NOT block the host's own
        // compaction. Log + count the streak for the R3 degraded flag.
        if (consecFails === 0) this._sc.streakSince = nowSec(); // the streak just started
        this._sc.consecFails = consecFails + 1;
        log.warn?.(`supercompress engine gate degraded (${this._sc.consecFails}): ${err.message}`);
      }
      // The unified 40% pre-digest face (the 4-band redesign step 3): ONE
      // batched LLM digest of the session's not-yet-digested model segments
      // (supersedes the 55-band head80-stub upgrade + the tiering O(N) burst
      // — the owner's "两个 LLM 预消化面并成一个" ruling). This P0 gate is the
      // FALLBACK leg: the PRIMARY execution point is the 40% band
      // (_bandPreclean); when the 40% band already digested, the per-session
      // marker makes this leg a no-op; when the session jumped straight to the
      // 50% band (a big paste skipping the 40% band), this leg still catches
      // up. Bounded (the tierLlm* residual-② bounds); fail-open.
      if (this._resolveEnable40PreDigest() !== false) {
        try {
          const pd = await run40PreDigest({
            client,
            ctx: this.ctx,
            agent,
            cfg: {
              enable40PreDigest: this._resolveEnable40PreDigest(),
              dshRoot: this._sc.rowConfig?.dshRoot,
              // 残留② (2026-11-23): the compact-window LLM BOUND, reused
              // verbatim by the batched face (a per-call timeout raced with
              // a TOTAL budget, earliest abort wins; a miss falls to the
              // P1 floor, 宁漏勿错). 0 = legacy.
              llmTimeoutMs: this._sc.rowConfig?.tierLlmTimeoutMs,
              llmBudgetMs: this._sc.rowConfig?.tierLlmBudgetMs,
              // The batch bounds (step 3): the per-batch segment count + the
              // per-batch input-token cap (one LLM call, NOT the O(N) burst
              // the tierLlmCap used to gate — the cap is superseded).
              predigestBatchMax: this._sc.rowConfig?.predigestBatchMax,
              predigestMaxInputTokens: this._sc.rowConfig?.predigestMaxInputTokens,
              // The 2026-11-23 P1 observability leg (carried over): the
              // face's skip/success reasons land in the ledger audit trail
              // (the silent no-op is gone).
              audit: (branch, reason) => this._auditLedgerBranch(agent, branch, reason),
            },
          });
          if (pd?.digested > 0)
            log.debug?.(
              `supercompress 40% pre-digest face: ${pd.digested} model segments -> rich digests ` +
                `(batched, 1 LLM call${(pd.advanced ?? 0) < pd.batch ? "; a mid-batch miss is held for the next firing" : ""})`,
            );
        } catch (err) {
          log.warn?.(`supercompress 40% pre-digest face degraded: ${err.message}`);
        }
      }
    }

    /** Live resolution of the tiering on/off (row config > shared getter > true). */
    _resolveEnableTiering() {
      const { rowConfig, resolveSharedEnableTiering } = this._sc;
      if (rowConfig?.enableTiering !== undefined && rowConfig?.enableTiering !== null) {
        return rowConfig.enableTiering === true || rowConfig.enableTiering === false
          ? rowConfig.enableTiering
          : rowConfig.enableTiering !== false;
      }
      return resolveSharedEnableTiering ? resolveSharedEnableTiering() !== false : true;
    }

    /**
     * Live resolution of the UNIFIED 40% pre-digest face on/off (the 4-band
     * redesign step 3; supersedes the enable55Band + enableTiering pair):
     * row config `enable40PreDigest` > the legacy expression
     * (`enable55Band === true OR the tiering face on`, which is what the two
     * pre-consolidation faces composed to; the web row ran enable55Band=true
     * + enableTiering=false -> ON; both absent -> the tiering default ON).
     */
    _resolveEnable40PreDigest() {
      const { rowConfig } = this._sc;
      if (rowConfig?.enable40PreDigest !== undefined && rowConfig?.enable40PreDigest !== null) {
        return rowConfig.enable40PreDigest === true || rowConfig.enable40PreDigest === false
          ? rowConfig.enable40PreDigest
          : rowConfig.enable40PreDigest !== false;
      }
      return rowConfig?.enable55Band === true || this._resolveEnableTiering() !== false;
    }

    /**
     * 55-band LLM digest upgrade: evicted P1/P2 segments still on the head80
     * stub get a real digest through the host ctx.llm (aux ≡ main-model
     * endpoint; the segment text + instruction ride the warm prefix). Non-
     * critical: every miss keeps the head80 placeholder, never blocks.
     * @returns {Promise<number>} number of upgraded segments.
     */
    async _upgrade55Band(agent, dist) {
      const { client } = this._sc;
      const evicted = (dist?.evicted || []).filter(
        (e) =>
          e &&
          (e.tier === "P2" || e.tier === "P1") &&
          e.original_text &&
          e.digest_ref !== "ready:llm55",
      );
      if (evicted.length === 0) return 0;
      if (!safeLlm(this.ctx)) return 0; // no host LLM -> all stay on the stub
      const route = routeFromAgent(agent);
      if (!route) return 0; // no route -> all stay on the stub
      let upgraded = 0;
      for (const seg of evicted) {
        try {
          const text = await oneShotText(this.ctx, {
            route,
            messages: [textUserMessage(DIGEST_INSTRUCTION + String(seg.original_text).slice(0, 4096))],
            purpose: "digest",
            maxTokens: 400,
            signal: undefined,
          });
          if (!text) continue; // empty -> keep the head80 placeholder
          const { keyFact, summary } = parseDigestResponse(text);
          const digest = keyFact || summary
            ? `${keyFact}\n${summary}`.trim()
            : String(seg.original_text).slice(0, 80);
          await client.digest(seg.segment_id, digest, "llm55");
          upgraded++;
        } catch {
          /* fail-open: keep the head80 placeholder for this segment */
        }
      }
      if (upgraded > 0) {
        const log = this.ctx?.logger || noopLog();
        log.debug?.(
          `supercompress engine gate: 55-band LLM digest upgraded ${upgraded}/${evicted.length} segments`,
        );
      }
      return upgraded;
    }
  }
  // Static members (`Config` schemastery schema, `inject` token list,
  // `provide`) are inherited through the class prototype chain, so the
  // loader's class-plugin path (config validation + DI resolution) sees the
  // host's exact compact contract.
  return SupercompressCompactionEngine;
}

/** The audit-line body (kept top-level so it is unit-testable): appends one
 *  JSONL line to <storeDir>/ledger-audit.jsonl, where storeDir = the daemon
 *  client's store directory. A client WITHOUT a storePath (the test fakes)
 *  skips the write — no production-dir pollution from unit tests. */
function _appendAuditLine(appendFileSync, sc, agent, branch, reason) {
  const storePath = sc?.client?.storePath;
  if (!storePath) return;
  const dir = String(storePath).replace(/\/[^/]+$/, "");
  appendFileSync(
    `${dir}/ledger-audit.jsonl`,
    JSON.stringify({ ts: Date.now(), pid: process.pid, session: String(agent?.session?.id ?? ""), branch, reason: reason ?? "" }) + "\n",
  );
}
