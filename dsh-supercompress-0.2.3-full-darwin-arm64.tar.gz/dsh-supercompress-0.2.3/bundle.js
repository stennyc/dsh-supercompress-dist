// bundle.js — the Cordis plugin object (the `dsh.bundle.patch` entry).
//
// A DSH plugin bundle's patch entry is a module exporting a Cordis plugin
// object: { name, inject?, apply(ctx, config) }. `apply` is where we mount:
//   - the pre-step recall face (step-1 tail via agent.inject, transcript-invisible)
//   - user-turn persistence (P0/user into the jsonl data plane)
//   - the pre-compress P0 gate (distill + anchor emission on `compaction/start`)
//
// The host wires this module in via the profile's patch row
// `name: '<this bundle>'` -> its `dsh.bundle.patch` -> this file.
//
// Compaction note: the host's compaction service is a composition ROW, and a
// row's `name` is just a module specifier the loader imports and
// instantiates as a class plugin — so a row pointing at shell/engine.js
// (the SupercompressCompactionEngine subclass, the "P5 engine replacement")
// MOUNTS OUR ENGINE as the `compaction` DI service: with `auto: true` the
// engine's own pressure / model-switch / overflow-recovery listeners manage
// the host context window, and its summarize() override runs the P0 gate
// gate-then-delegate. This bundle's `compaction/start` SESSION EVENT gate
// below is the SECOND, belt-and-suspenders P0 gate (it fires at the exact
// pre-shadow moment even when only this bundle — not the engine row — is
// mounted, and re-runs the 40% pre-digest LLM digest upgrade on evicted
// stubs — the unified enable40PreDigest face (the legacy 55-band / tiering
// keys were retired at the 4-band redesign step 3 and removed at the
// 2026-11-27 cleanup).
// The pre-step soft-pressure distill (below) is the data-plane density path
// that runs BETWEEN host compacts — it never touches the host's own
// messages; only the mounted engine row does the actual window compaction.

import { DaemonClient, sharedDaemonClient, releaseSharedClient, setSharedEnableTieringGetter, clearSharedEnableTieringGetter, setSharedUseLedgerSummarizerGetter, clearSharedUseLedgerSummarizerGetter, setSharedCapacityRatioGetter, clearSharedCapacityRatioGetter, setSharedBandThresholdsGetter, clearSharedBandThresholdsGetter, setSharedLiveUserTrimGetter, clearSharedLiveUserTrimGetter, setSharedBandGatesGetter, clearSharedBandGatesGetter, setSharedRenderLadderGetter, clearSharedRenderLadderGetter } from "./ipc.js";
import { makeTurnPersistListener } from "./turn-persist.js";
import * as dshTools from "@deepseek-ai/dsh-tools";
// The rc.1-generation host's @deepseek-ai/dsh-tools does NOT export
// ToolContextUnavailableError (only ToolExecutorUnavailableError; evidence:
// the rc.1 dist's dsh-tools export table). A NAMESPACE import + fallback keeps
// this module loadable on BOTH host generations — the old named import
// `import { ToolContextUnavailableError } from ...` throws a load-time
// SyntaxError on rc.1 (the phone host) because that export is absent.
const defineTool = dshTools.defineTool;
const ToolArgsError = dshTools.ToolArgsError;
const ToolContextUnavailableError =
  dshTools.ToolContextUnavailableError ??
  dshTools.ToolExecutorUnavailableError ??
  class ToolContextUnavailableError extends Error {};
import { safeLlm, isLegacyInject } from "./llm-guard.js";
import { resolveHostDir, resolveHostSession, resolveHostSessionBySessionId } from "./host-session.js";
import { makeCacheKeeper } from "./cache-keeper.js";

export const name = "dsh-supercompress";

// Config schema (schemastery). The host validates the patch row's `config`
// against this at activation via `Config["~standard"].validate(config)`:
//   - missing keys get their `.default()` applied
//   - wrong types / out-of-range / unknown-enum values are REJECTED
//   - unknown keys pass through (loose merge) — so extra keys never fail activation
//
// Resolution: the host's own bundles import '@deepseek-ai/schemastery' by
// name (the host's node_modules provides it). From the linked bundle's own
// directory the bare specifier does NOT resolve, so we try the bare import
// first and fall back to the host's absolute install path when running under
// the host's runtime (the dsh web profile). The fallback keeps `node --test`
// (run from the shell dir, no host tree) working — in that case the bare
// import misses, the absolute path misses, Config stays undefined and no
// validation runs (the plugin still activates with the ad-hoc defaults in
// apply()). NOTE: schemastery's Schema is a callable object — it has NO
// z.enum / z.union API; enum fields are built as
// `z.union([z.const("a"), z.const("b")]).default("a")`.
let z;
try {
  z = (await import("@deepseek-ai/schemastery")).default;
} catch {
  // host global-install probe: <node prefix>/lib/node_modules — either a
  // hoisted top-level schemastery or the nested copy under the global
  // @deepseek-ai/dsh install. (dist-only: the dev tree hardcodes the build
  // machine's nvm path here; the dist artifact probes process.execPath's
  // prefix instead.)
  try {
    const exe = typeof process !== "undefined" ? (process.execPath || "") : "";
    const bi = exe.lastIndexOf("/bin/");
    if (bi >= 0) {
      const prefix = exe.slice(0, bi);
      for (const c of [
        prefix + "/lib/node_modules/@deepseek-ai/schemastery/lib/index.mjs",
        prefix + "/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/schemastery/lib/index.mjs",
      ]) {
        try { z = (await import(c)).default; break; } catch { /* next candidate */ }
      }
    }
  } catch {
    z = undefined;
  }
}

export const Config = z
  ? z.object({
      // Go daemon spawn (resolved relative to the bundle package dir; the host
      // does NOT expand ~/ or relative paths — the plugin resolves them).
      daemonPath: z.string().default("./bin/scd"),
      // jsonl store path (the data-plane single source of truth).
      storePath: z.string().default("~/.dsh-supercompress/session.jsonl"),
      // P1/P2 lazy-batch flush cap (bytes); power-loss bound = one batch.
      lazyBatchCap: z.number().step(1).min(1024).default(256 * 1024),
      // recall top-k. `.volatile()` = live-editable on the dsh web card; the
      // pre-step recall listener re-reads it on every tick (no restart).
      // window capacity tokens for distill (the 80% waterline baseline).
      // `.volatile()` = live-editable on the card; the distill faces re-read it
      // on every call (no restart). A2: when unset the distill faces instead
      // resolve the cap LIVE as host contextWindow × capacityRatio (below)
      // — this field stays the absolute override (highest priority), the
      // static fail-open floor when no host window signal is available.
      capacityTokens: z.number().step(1).min(256).default(1000).volatile(),
      // A2: the data-plane ledger capacity budget as a FRACTION of the HOST
      // context window (live-read via the O(1) tokenMeter contextPressure
      // projection at each distill): capacity = contextWindow × ratio. The
      // host's contextWindow scales per deployment (the dsh web host is
      // 512000) — the fixed default ledger of 1000 tokens kept the 90%
      // waterline at 900, over-pressured against a live ledger of ~17k
      // tokens, so P0 turns evicted uselessly onto head80 placeholders.
      // Default 0.5 (the ledger carries half the host window; the recall
      // face re-injects digests of evicted segments, so half is ample).
      // `.volatile()` = live-editable on the card; the distill faces + the
      // mounted engine row re-read it on every distill (no restart). The
      // absolute `capacityTokens` field / the env DASHSC_CAPACITY override
      // this fraction (highest priority).
      capacityRatio: z.number().step(0.05).min(0.05).max(1).default(0.5).volatile(),
      // persist user turns into the P0 store (default on). `.volatile()` =
      // live-editable on the dsh web card; the persistence face re-checks it on
      // every session/event (no restart).
      persistUserTurns: z.boolean().default(true).volatile(),
      // user-source mode: "live" ingests splice-time user turns; "host"
      // (scheme A) sources them from the host's native zstd session log.
      // `.volatile()` = live-editable on the card (the dispatch re-reads it).
      userSource: z.union([z.const("live"), z.const("host")]).default("live").volatile(),
      // historical backfill from the host native session log at session/created.
      // `.volatile()` = live-editable; the backfill handler re-checks it.
      hostBackfill: z.boolean().default(true).volatile(),
      // cross-period reopen face (G1): at session/created, a COLD reopen of the
      // same session (the store already carries prior-period P1) stale-marks the
      // replayed P1 middle-reasoning IN MEMORY (file bytes untouched, matching
      // Python 文件字节不动) so recall downweights it ×0.5 + "verify before
      // acting". Default on (matches Python's automatic cold-reopen branch);
      // a fresh session marks 0 (no-op). `.volatile()` = live-editable.
      enableReopen: z.boolean().default(true).volatile(),
      // pre-compress P0 gate on `compaction/start` (distill + anchor emission).
      // `.volatile()` = live-editable; the gate/pressure handlers re-check it.
      enableCompaction: z.boolean().default(true).volatile(),
      // The unified 40% pre-digest face (the 4-band redesign step 3): ONE
      // batched LLM digest of the session's not-yet-digested model segments,
      // run at the 40% band (the earliest pressure waterline — "打扫房间") so
      // the 50% band's 0-LLM bind reads ready rich digests. Supersedes the
      // two separate LLM pre-digest faces (the 55-band head80 upgrade + the
      // tiering O(N) burst — the owner's "并成一个面" ruling). Default ON.
      // `.volatile()` = live-editable; the band re-reads it on every firing.
      enable40PreDigest: z.boolean().default(true).volatile(),
      // DEPRECATED (step 3): superseded by enable40PreDigest (the unified
      // face). Kept as a row-config key for back-compat (old rows still load);
      // the engine's legacy resolution falls through to the unified knob.
      // model-segment tiering face (LLM aux via ctx.llm, 宁漏勿错 floor).
      // `.volatile()` = live-editable; compaction.js re-reads it per call.
      enableTiering: z.boolean().default(true).volatile(),
      // Per-turn model-record persistence (the Python model-store
      // on_turn_complete hook, ported onto DSH's agent/turn-stopping serial
      // point, see turn-persist.js): at each turn end the gate-passing
      // assistant segments are ingested P0/model (append+fsync+readback —
      // crash-durable, the reference "persist-then-refine" invariant), so a
      // compact-time ledger coverage check sees the model rows even when the
      // host zstd log read races a live append or a torn tail frame.
      // `.volatile()` = live-editable; the listener re-checks it per turn.
      persistModelTurns: z.boolean().default(true).volatile(),
      // The Python `model_min_chars` gate: the minimum assistant-text length
      // for per-turn persistence (a meaningful marker hit persists at ANY
      // length; the reasoning-monologue open is skipped regardless — the R5
      // repeat-reading fix). `.volatile()` = live-editable.
      modelMinChars: z.number().step(1).min(0).default(200).volatile(),
      // Per-compact cap on the tiering face's one-shot LLM calls (0 =
      // unbounded): beyond the cap, undecided model segments fall to the
      // deterministic P0 structural floor (宁漏勿错 — a cap never drops data,
      // it only stops the O(N)-per-compact LLM burst that dominated the
      // 2026-11-23 compact window). Static (no card control).
      tierLlmCap: z.number().step(1).min(0).max(512).default(32),
      // 残留② (2026-11-23): the compact-window LLM BOUND. Per one-shot call
      // timeout (ms; 0 = off) raced with the TOTAL face budget below via
      // AbortSignal.any (earliest abort wins — the host LLM contract's
      // fail-soft item-6 pattern). A timeout/abort/miss falls to the
      // deterministic P0/head80 floor (宁漏勿错: a bound never drops data,
      // it only stops the unbounded wait that let a degraded endpoint hold
      // the 2026-11-23 compact windows open 118s+). Also bounds the
      // the 40% pre-digest / 70% LLM-merge / compact-ledger digest faces
      // (per call; the 40% pre-digest face was folded into the 40% pre-digest at
      // the 4-band redesign step 3 — the legacy keys stay as fallback legs).
      tierLlmTimeoutMs: z.number().step(1000).min(0).default(30000),
      // The tiering face's TOTAL one-shot LLM budget per compact (ms from
      // face start; 0 = no total budget): after it, remaining undecided
      // segments fall to the deterministic P0 floor. The per-call timeout
      // above is the finer-grained bound; this one caps the WINDOW.
      tierLlmBudgetMs: z.number().step(1000).min(0).default(120000),
      // Ledger-backed summarizer (the P5 full-replacement of the host LLM
      // checkpoint): when ON, the MOUNTED engine composes the compaction
      // checkpoint from this bundle's ledger (0 LLM calls in the compact
      // window; the unmarked-SummaryResult contract), and the host LLM
      // summarizer stays the fail-open fallback. Default OFF = today's
      // behavior. `.volatile()` = live-editable; the engine re-reads it on
      // every summarize().
      useLedgerSummarizer: z.boolean().default(false).volatile(),
      // ── form-ladder render face (RENDER_FIX_PROPOSAL §2.1 — the Python
      // choose_forms alignment; the "head80-everywhere / no P1-P2" fix,
      // owner ruling 2026-11-26) ──
      // When ON, the mounted engine renders the checkpoint ledger digest
      // through the form ladder (L3/L2/L1/L0 per row; the P0 push-cap + the
      // index pool; the anti-drift anchor exemption; the log display order;
      // over-budget rows DOWNGRADE to the L0 pointer floor — a ledger row is
      // never dropped out of the window) instead of the legacy paged face
      // (structural-first + head80 + tail-truncate). Default OFF = zero
      // behavior change (the legacy session_digest face, byte-stable).
      // `.volatile()` = live-editable; the engine re-reads it on every
      // summarize().
      renderLadder: z.boolean().default(false).volatile(),
      // The ladder's pool knobs (byte units — the Go renderer's byte
      // discipline): P0 L3 push cap (the Python 15% push cap, byte-ized) /
      // the index pool (L2+L1 shared, newest-first allocation) / the per-row
      // L3+L2 body cap / the whole-text cap (the shell clamps it against the
      // 0.6×shadow floor; the host's shrink check is the final arbiter).
      renderLadderP0Cap: z.number().step(1).min(512).default(8192).volatile(),
      renderLadderIndexPool: z.number().step(1).min(256).default(4096).volatile(),
      renderLadderL3Cap: z.number().step(1).min(64).default(512).volatile(),
      renderLadderTotalCap: z.number().step(1).min(1024).default(16384).volatile(),
      // The L1/L0 dual-end 路标 window (owner ruling 2026-11-27): head N chars +
      // tail M chars of the row's original (rune counting; 0/absent = the
      // renderer's 24/24 defaults). The 路标 keeps a zero-budget row legible
      // (the model sees who said what-briefly) without loading the full text;
      // the full original stays durable on disk for the c#N/seq point-fetch.
      renderLadderLandmarkHead: z.number().step(1).min(0).default(24).volatile(),
      renderLadderLandmarkTail: z.number().step(1).min(0).default(24).volatile(),
      // ── live-ledger face (Block ③, ported from Python sc/ledger.py) ──
      // Opt-in: when on, each ingested user instruction drives the ledger's
      // phase migration (old phase supersedes, new phase opens, P0 ledger row
      // written). Default off = zero behavior change (the ledger command is
      // still reachable for explicit done/checkpoint driving).
      enableLedger: z.boolean().default(false).volatile(),
      // The pinned top-level goal the ledger books under (user-sourced).
      ledgerGoal: z.string().default(""),
      // turn-boundary on-delta checkpoint cadence (0 = no auto checkpoints).
      ledgerCheckpointEvery: z.number().step(1).min(0).default(0),
      // explicit dsh root for host session dir resolution (default ~/.dsh).
      dshRoot: z.string().default("~/.dsh"),
      // host context-pressure factor (soft-pressure distill trigger): when the
      // host's measured used/contextWindow >= this, run an extra distill pass
      // so the data-plane window compresses between host compacts. Default 0.8.
      hostPressureFactor: z.number().step(0.05).min(0.5).max(0.95).default(0.8).volatile(),
      // C tier: the "打扫房间" 5-band waterline thresholds (the volatile card
      // fields the MOUNTED engine re-reads on every compactIfNeeded call).
      // Each is a percentage (0,100]; the 4-band switch runs high-to-low
      // (90 -> 70 -> 50 -> 40 -> pass-through). Defaults = the contract v4
      // (90/70/50/40); row config / the env DASHSC_T90..T40 override.
      t90: z.number().step(1).min(1).max(100).default(90).volatile(),
      t70: z.number().step(1).min(1).max(100).default(70).volatile(),
      t50: z.number().step(1).min(1).max(100).default(50).volatile(),
      t40: z.number().step(1).min(1).max(100).default(40).volatile(),
      // The live user-paste trim-at-production face on/off (the engine's
      // pre-step listener re-reads it every tick — the card toggle is
      // INSTANT, no restart). Deliberately NO default: an untouched field
      // yields undefined, letting the engine ROW config's `liveUserTrim`
      // speak; a card write OVERRIDES the row value.
      liveUserTrim: z.boolean().volatile(),
      // ── the C-tier band GATES (card refactor 2026-11-26): the four
      // per-band enable switches (90% handoff / 70% LLM paged compaction /
      // 50% ledger bind / 40% preclean + pre-digest). Deliberately NO
      // defaults: an untouched card field yields undefined -> the engine's
      // band switch keeps the all-enabled module default; a card write
      // (explicit true/false) OVERRIDES per band. .volatile() = live, no
      // restart (the engine re-reads the published getter every call).
      enableBand90: z.boolean().volatile(),
      enableBand70: z.boolean().volatile(),
      enableBand50: z.boolean().volatile(),
      enableBand40: z.boolean().volatile(),
      // The compact-ledger host consumer face (ported from Python
      // sc/compact_ledger.py): when ON, each host compact event (the
      // compaction/start gate's distill pass) stages THIS cycle's evicted P1/P2
      // block into the <sid>.compact.json cumulative ledger (append-only,
      // cap-bounded: trimmable-fold -> settled -> seal fallback). Default OFF
      // (opt-in; the data plane + daemon face is ready, the host consumer is a
      // deliberate opt-in so the default live behavior is unchanged).
      enableCompactLedger: z.boolean().default(false).volatile(),
      // ── cache-keeper face (provider prefix-cache keep-alive, 2026-11-26) ──
      // The measured gateway behavior (riway30, 2026-11-25 window analysis):
      // an idle session loses the OLDEST ~6-13% of its cached prefix pages
      // somewhere after ~60s of silence (LRU under KV-pool pressure), so the
      // resume request drops from 99.5% to 87-93% hit. The DSH host has no
      // prefix-cache control surface — the only client-side refresh lever is
      // re-sending the session's own last request prefix. This face records
      // each main request's exact prompt options (the llm/stream waterfall
      // seam, the rpm-limiter's own gate point) and, while a session sits
      // idle inside the keep window, re-sends it with maxTokens=1 so the
      // gateway's cache pages for that exact prefix stay warm (or get
      // re-written EARLY, off the model's critical path). Default OFF =
      // zero behavior change (the owner flips it on per deployment — this
      // deployment's row sets it on). .volatile() = live-editable; the
      // recorder + the tick re-read every getter on every event/tick.
      cacheKeeper: z.boolean().default(false).volatile(),
      // Provider ROUTE keys to keep alive (the llm-pi-ai "providers" dict
      // keys, e.g. "riway30"). EMPTY = the face is INERT (nothing is ever
      // recorded — the rpm-limiter's "no routes = inert" precedent).
      ckProviders: z.array(z.string()).default([]).volatile(),
      // First refresh after this much idle (ms). Default 45000: lands
      // ~15s ahead of the measured ~60s eviction point. .volatile().
      ckIdleTriggerMs: z.number().step(1000).min(5000).default(45000).volatile(),
      // Re-fire cadence while still idle (ms). Default = the trigger (45s):
      // one heartbeat per keep window. .volatile().
      ckRefreshPeriodMs: z.number().step(1000).min(5000).default(45000).volatile(),
      // Stop heartbeating after this much idle (ms; a dead session burns no
      // tokens and its record is freed). Default 30min. .volatile().
      ckMaxIdleMs: z.number().step(1000).min(60000).default(1800000).volatile(),
      // Cost ceiling: skip recording sessions whose last prompt exceeds
      // this many CHARS (~4 chars/token -> 2M ≈ 500K tokens). .volatile().
      ckMaxPromptChars: z.number().step(1000).min(65000).default(2000000).volatile(),
      // Per-heartbeat LLM wait (ms; 0 = unbounded — the repo's
      // tierLlmTimeoutMs analog). .volatile().
      ckTimeoutMs: z.number().step(1000).min(0).default(30000).volatile(),
      // The heartbeat audit JSONL (one line per beat: ok/fail + promptChars
      // + ms). "~" expands to the host's home. "" = audit off. Static.
      ckAuditPath: z.string().default("~/.dsh-supercompress/cache-keeper.jsonl"),
    })
  : undefined;

// DI inject: the host resolves these tokens onto the plugin ctx.
//  - "llm" is resolvable by the host (BasicCompactionEngine's own inject lists
//    it), used by compaction.js's digest/tier faces if that module is wired in.
//  - "tokenMeter" is the host's context-pressure service (dsh-token-meter):
//    `ctx.get("tokenMeter").contextPressure(session)` is O(1) and yields
//    { pressureTokens, contextWindow } — the soft-pressure read the 降档带
//    trigger consumes. BasicCompactionEngine's own inject also lists
//    "tokenMeter", so it is resolvable (does not leave the entry pending).
// GENERATION SPLIT (isLegacyInject, the dist esbuild --define __SC_LEGACY
// switch): the rc.1 host generation has NO `llm` / `tokenMeter` DI tokens, so
// the RC1HOST build declares only `["tools"]` (resolvable on rc.1) — the LLM
// faces take their coded deterministic floor there. The FULL build (rc.5+)
// keeps the full triple.
export const inject = isLegacyInject ? ["tools"] : ["llm", "tokenMeter", "tools"];

/**
 * Read a config field that the host may have handed us as a schemastery
 * Volatile getter (`.get()` — set when the field is declared `.volatile()` and
 * edited live on the dsh web card) OR as a plain value (tests / a
 * non-volatile activation). Falls back to `dft` when missing / not a number.
 */
function readNum(field, dft) {
  const v = typeof field?.get === "function" ? field.get() : field;
  return typeof v === "number" && Number.isFinite(v) ? v : dft;
}

/** Read a boolean config field (Volatile getter or plain) with a default. */
function readBool(field, dft) {
  const v = typeof field?.get === "function" ? field.get() : field;
  return typeof v === "boolean" ? v : dft;
}

/** Read a string config field (Volatile getter or plain) with a default. */
function readStr(field, dft) {
  const v = typeof field?.get === "function" ? field.get() : field;
  return typeof v === "string" ? v : dft;
}

/** Read a string-array config field (Volatile getter or plain) with a default. */
function readStrArray(field, dflt) {
  const v = typeof field?.get === "function" ? field.get() : field;
  return Array.isArray(v) ? v.map(String) : (Array.isArray(dflt) ? dflt : []);
}

/**
 * @param {import("@deepseek-ai/cordis").Context} ctx
 * @param {object} [config]
 */
export async function apply(ctx, config = {}) {
  // A DI-provided client (config.client) is caller-owned; otherwise the
  // module-shared resident daemon is used (one scd process per store).
  const client =
    config.client ||
    sharedDaemonClient({
      storePath: config.storePath,
      daemonPath: config.daemonPath,
      lazyBatchCap: config.lazyBatchCap ?? 256 * 1024,
    });

  // `enableTiering` is `.volatile()` (the model-segment tiering face on/off).
  // Publish a LIVE getter so the MOUNTED engine path (engine-core) drives the
  // tiering face when it is on (default), re-reading on each compaction gate.
  const tierField = config.enableTiering;
  setSharedEnableTieringGetter(() =>
    typeof tierField?.get === "function" ? tierField.get() !== false : tierField !== false,
  );

  // `useLedgerSummarizer` is `.volatile()` (the ledger-backed summarizer
  // on/off): publish a LIVE getter so the MOUNTED engine composes the
  // checkpoint from the ledger when it is on (default off = the host LLM
  // path), re-reading on each summarize() call.
  const ledgerField = config.useLedgerSummarizer;
  setSharedUseLedgerSummarizerGetter(() =>
    typeof ledgerField?.get === "function" ? ledgerField.get() === true : ledgerField === true,
  );

  // `renderLadder` + the pool knobs are `.volatile()` (the form-ladder
  // render face, RENDER_FIX_PROPOSAL §2.1): publish a LIVE getter that
  // yields the resolved knob set, so the MOUNTED engine (a separate cordis
  // activation) re-reads it on every summarize() call — the exact pattern
  // the ledger / tiering knobs use. Default OFF = the legacy paged face
  // (zero behavior change).
  const ladderField = config.renderLadder;
  const ladderP0Field = config.renderLadderP0Cap;
  const ladderPoolField = config.renderLadderIndexPool;
  const ladderL3Field = config.renderLadderL3Cap;
  const ladderTotalField = config.renderLadderTotalCap;
  const ladderLandmarkHeadField = config.renderLadderLandmarkHead;
  const ladderLandmarkTailField = config.renderLadderLandmarkTail;
  setSharedRenderLadderGetter(() => ({
    on: typeof ladderField?.get === "function" ? ladderField.get() === true : ladderField === true,
    p0Cap: readNum(ladderP0Field, 8192),
    indexPool: readNum(ladderPoolField, 4096),
    l3Cap: readNum(ladderL3Field, 512),
    totalCap: readNum(ladderTotalField, 16384),
    landmarkHead: readNum(ladderLandmarkHeadField, 24),
    landmarkTail: readNum(ladderLandmarkTailField, 24),
  }));

  // A2: `capacityRatio` is `.volatile()` (the data-plane ledger capacity as a
  // fraction of the HOST context window, live-read at each distill): publish a
  // LIVE getter so the MOUNTED engine path (engine-core) resolves the cap as
  // contextWindow × ratio, re-reading on each distill. 0 / out-of-range
  // normalizes to unset (the engine falls back to the static capacityTokens
  // — fail-open).
  const ratioField = config.capacityRatio;
  setSharedCapacityRatioGetter(() =>
    typeof ratioField?.get === "function" ? ratioField.get() : ratioField,
  );

  // C tier: the "打扫房间" 5-band waterline thresholds (the `.volatile()`
  // card fields t90/t70/t50/t40): publish a LIVE getter so the MOUNTED
  // engine's compactIfNeeded switch re-reads the CURRENT value on every call
  // (editing a threshold on the dsh web card applies without a restart).
  // Each field is a Volatile getter at host runtime (reads the live value);
  // in tests / non-volatile activations it is a plain number.
  const t90Field = config.t90;
  const t70Field = config.t70;
  const t50Field = config.t50;
  const t40Field = config.t40;
  setSharedBandThresholdsGetter(() => ({
    t90: typeof t90Field?.get === "function" ? t90Field.get() : t90Field,
    t70: typeof t70Field?.get === "function" ? t70Field.get() : t70Field,
    t50: typeof t50Field?.get === "function" ? t50Field.get() : t50Field,
    t40: typeof t40Field?.get === "function" ? t40Field.get() : t40Field,
  }));

  // The live user-paste trim face (the `.volatile()` card field
  // `liveUserTrim`, NO schema default — an untouched field yields
  // undefined, letting the engine row config's `liveUserTrim` speak; the
  // card OVERRIDES when set): publish a LIVE getter so the mounted
  // engine's pre-step live pass re-reads the CURRENT value every tick
  // (the card toggle applies without a restart).
  const liveUserTrimField = config.liveUserTrim;
  setSharedLiveUserTrimGetter(() =>
    typeof liveUserTrimField?.get === "function" ? liveUserTrimField.get() : liveUserTrimField,
  );

  // The four band-gate card switches: publish ONE live getter (the engine's
  // band switch consults it per compactIfNeeded call). Untouched fields
  // yield undefined entries = the band stays enabled (module default);
  // only an explicit false disables a band.
  const bandGateRead = (field) =>
    typeof field?.get === "function" ? field.get() : (typeof field === "boolean" ? field : undefined);
  setSharedBandGatesGetter(() => ({
    b90: bandGateRead(config.enableBand90),
    b70: bandGateRead(config.enableBand70),
    b50: bandGateRead(config.enableBand50),
    b40: bandGateRead(config.enableBand40),
  }));

  // A2: the data-plane ledger capacity budget — live resolution shared by the
  // compaction/start gate AND the host-pressure soft-distill listener.
  // Order (highest first): the absolute `capacityTokens` field (a real number
  // from the card / row config — the volatile getter yields the CURRENT
  // value; an untouched host default is the schema default 1000, NOT the
  // "unset" the legacy `readNum(field, 1000)` shape treated it as), then the
  // env DASHSC_CAPACITY absolute override, then host contextWindow ×
  // `capacityRatio` (the O(1) tokenMeter read, live per call). Fail-open:
  // no host window signal -> the static 1000 floor. NEVER 0 (a zero would
  // zero the data plane's waterlines — the full-eviction dangerous state).
  const resolveDistillCapacity = (session) => {
    const abs = readNum(config.capacityTokens, NaN);
    if (Number.isFinite(abs) && abs > 0) return abs;
    const env = process.env.DASHSC_CAPACITY;
    const envV = env !== undefined && env !== "" ? Number(env) : NaN;
    if (Number.isFinite(envV) && envV > 0) return envV;
    const p = ctx.get?.("tokenMeter")?.contextPressure?.(session);
    const window = p?.contextWindow;
    const ratio = readNum(config.capacityRatio, 0.5);
    if (typeof window === "number" && window > 0 && typeof ratio === "number" && ratio > 0) {
      return Math.max(1, Math.floor(window * ratio));
    }
    return 1000;
  };


  // ── persistence face: user turns -> P0/user into the jsonl data plane ──
  // userSource: "live" (default) ingests each user turn as the host splices it;
  // "host" (scheme A) sources user turns from the host's native session log via
  // the daemon (deduped once per session, no parallel re-ingest) — the host file
  // is read-only. In "host" mode the session handler reads the host session file
  // (session.id + session.header.cwd) and ingests the deduped user turns.
  // ── scheme A-2: historical backfill from the host native session log ──
  // At session open/resume, read the PRIOR session's durable user turns from the
  // host's zstd V4 log and backfill them into our P0 store (deduped by content
  // hash, so an already-persisted turn is a no-op). The CURRENT session's own
  // turns still flow through the live handler below — so history is sourced
  // from the host (no parallel re-ingest), the in-flight turn stays real-time.
  // Fail-open: a missing/unreadable host log backfills 0; the live path still runs.
  // Live: the volatile hostBackfill is re-checked on every session/created
  // (toggling it on the dsh web card takes effect for new sessions, no restart).
  ctx.on("session/created", (session) => {
    // G1 cross-period reopen: a COLD reopen of this session stale-marks the
    // replayed P1 middle-reasoning in memory (file bytes untouched, matching
    // Python 文件字节不动). Default on (Python's automatic cold-reopen branch);
    // a fresh session marks 0 (no-op). Fire-and-forget (fail-open) and
    // INDEPENDENT of hostBackfill. The P1 stale-mark is scoped to THIS session
    // (the shared store carries many sessions' P1 — a reopen of session X must
    // not mis-downweight session Y's live P1). A daemon miss never blocks the
    // session.
    if (readBool(config.enableReopen, true)) {
      client.reopen({ session: sessionKeyOf(session) }).catch(() => {});
    }
    if (!readBool(config.hostBackfill, true)) return; // live: backfill off
    // Fire-and-forget: backfill must not block the session/created listener
    // (a sync rejection rolls the attach per the host contract).
    backfillFromHost(client, session, config).catch(() => {});
  });
  let offSession;
  // ── compaction face: pre-compress P0 gate (write-before-compress) ──
  // The host appends `compaction/start` to the session (synchronously adjacent
  // to the durable lock, dsh-compaction-basic) the moment it is about to shadow
  // a surface range. Run the data-plane P0 gate (distill + anchor emission) so
  // the P0 user turns about to be shadowed are durable on disk BEFORE the host
  // commits the compaction. Mounted for BOTH userSource modes (independent of
  // the persistence face). Fail-open: a daemon miss must not block the host's
  // own compaction (the durable, correct path).
  // Live: the volatile enableCompaction is re-checked on every gate/pressure
  // event (toggling it on the dsh web card takes effect without a restart).
  // R3 健康探测（reference aux_provider.consec_fails / endpoint_degraded）：
    // the host LLM endpoint's digest/aux calls share the main-model channel. A
    // consec-fail streak ≥ 3 marks the endpoint "degraded" and the gate passes
    // it to distill so the P0 pending escape-hatch releases (head80) instead of
    // holding the window over-store. A success resets the streak. Zero new
    // provider — this reuses the host's own endpoint health, not a probe.
    let consecFails = 0;
    let streakSince = 0; // G2: seconds when the current fail-streak started
    const nowSec = () => Date.now() / 1000;
    const cooldown = () =>
      consecFails >= 1
        ? { level: consecFails, since: streakSince || nowSec(), now: nowSec(), base: 60 }
        : {};
    const gate = ctx.on("session/event", async (session, event) => {
      if (event?.type !== "compaction/start") return;
      if (!readBool(config.enableCompaction, true)) return; // live: gate off
      // F4 resume-safe backfill (2026-11-24): the session/created-bound A-2
      // backfill does NOT re-run when a RESTARTED host takes over an EXISTING
      // session (session/created fires on creation, not on resume) — the
      // 00:05 and 02:46 opens backfilled nothing, leaving 4 old user turns
      // (two 11-23 agent/inbox/spliced turns + two msg-optimizer turns) out
      // of the store forever. A compaction happens on every live session
      // (this listener is the compact gate), so re-running the deduped
      // host-log backfill HERE is the resume-safe trigger: persisted turns
      // no-op (content-hash dedup), the missing ones land as P0.
      // Fire-and-forget + fail-open: it must never block or taint the P0
      // gate that follows.
      if (readBool(config.hostBackfill, true)) {
        backfillFromHost(client, session, config).catch(() => {});
      }
      try {
        // A2: the ledger capacity follows the host context window live
        // (resolveDistillCapacity: absolute capacityTokens/env override >
        // contextWindow × capacityRatio > the fail-open 1000 floor, never 0).
        const dist = await client.distill(resolveDistillCapacity(session), consecFails >= 3, cooldown());
        // The compact-ledger host consumer face: stage this cycle's evicted
        // P1/P2 block into the cumulative ledger (opt-in, LLM-digested when a
        // host route is available, head80 fallback otherwise; fail-open).
        const staged = await compactLedgerStage(client, ctx, config, dist, session);
        if (staged > 0) {
          ctx.logger?.debug?.(`dsh-supercompress: compact-ledger staged ${staged} evicted segment(s)`);
        }
        consecFails = 0; // success → reset the fail streak (endpoint recovered)
        streakSince = 0;
        ctx.logger?.debug?.(
          `dsh-supercompress: compaction gate distill ${dist.status}, kept_p0=${(dist.kept_p0 || []).length}`,
        );
      } catch (err) {
        if (consecFails === 0) streakSince = nowSec(); // the streak just started
        consecFails++; // the data-plane miss IS the endpoint-health signal
        ctx.logger?.warn?.(
          `dsh-supercompress: compaction gate degraded (${consecFails}): ${err.message}`,
        );
      }
    });
    // ── 宿主 context 压力读口（reference engine: tokenMeter-driven 降档带）──
    // The host's agent-loop measures context pressure each step. Read it via
    // the host's token-meter service: `ctx.get("tokenMeter").contextPressure(
    // session)` is O(1) (reads the durable `contextPressure` projection the
    // host updates on every LLM settlement) and returns
    // { pressureTokens, contextWindow } — NOT the O(surface) `measure()`.
    // When the host is running hot (pressureTokens/contextWindow >= factor),
    // run an EXTRA distill pass so the data-plane window density drops —
    // evicted segments become digest-only, and the recall face re-injects the
    // short excerpts instead of original text. This is the "维持宿主 context
    // 不 overflow" 路径：the 降档带 (90%/75%/65%) runs on host pressure, not
    // just on host compact. Fail-open: a miss (no meter / no signal) never
    // blocks the host step (the recall face + compaction/start gate still run).
    // The host rc.5 pre-step payload is { messages, turn, step, signal,
    // modelSelection, agent } — it does NOT carry `session`; resolve it from
    // the agent (payload.session kept for forward host compat, undefined now).
    const preStepPressure = ctx.on("agent/pre-step", async (payload, next) => {
      const agent = payload?.agent;
      const session = payload?.session ?? agent?.session;
      const decision = await next(); // always run the rest of the waterfall first
      if (decision?.kind !== "enter") return decision;
      if (!readBool(config.enableCompaction, true)) return decision; // live: gate off
      try {
        // O(1) context-pressure read from the host's token-meter service.
        // `ctx.get("tokenMeter")` resolves the injected service (bundle's
        // inject lists it); a miss returns undefined -> no soft distill.
        const meter = ctx.get?.("tokenMeter");
        const p = meter?.contextPressure?.(session);
        const used = p?.pressureTokens ?? 0;
        const windowTokens = p?.contextWindow ?? 0;
        if (!used || !windowTokens) return decision; // no pressure signal -> skip
        const factor = readNum(config.hostPressureFactor, 0.8);
        if (used / windowTokens >= factor) {
          // Host is hot: run an extra distill pass so the data-plane window
          // compresses (P2/P1 evicted to digest-only; P0 held or escape-hatched).
          // The recall face (pre-step-1) then re-injects the digest excerpts.
          // A2: the cap follows the host context window live (this listener
          // already holds the O(1) projection — the same read drives both the
          // hot check and the capacity budget).
          const dist = await client.distill(resolveDistillCapacity(session), consecFails >= 3, cooldown());
          ctx.logger?.debug?.(
            `dsh-supercompress: host-pressure distill ${dist.status} (used ${used}/${windowTokens})`,
          );
        }
      } catch {
        /* fail-open: a pressure-distill miss must not block the host step */
      }
      return decision;
    });
    offSession = () => {
      gate();
      preStepPressure();
      offPersistence?.();
    };
  // ── persistence face: user turns -> P0/user into the jsonl data plane ──
  // userSource "live" (default): mount the splice-time live ingester.
  // userSource "host" (scheme A): the host log is the deduped source; the live
  // splice handler is NOT mounted (no parallel re-ingest) — instead the host
  // session file is read ONCE per session on the first splice.
  let offPersistence;
  const hostIngested = new Set();
  // Live: the volatile persistUserTurns + userSource are re-checked on every
  // splice event (toggling them on the dsh web card takes effect without a
  // restart). One dispatcher, branched on the live values each event.
  offPersistence = ctx.on("session/event", async (session, event) => {
    if (!readBool(config.persistUserTurns, true)) return; // live: persistence off
    if (readStr(config.userSource, "live") !== "host") {
      await persistSpliceUserTurn(client, session, event, config);
    } else if (event?.type === "agent/inbox/spliced" && event.data?.target === "next-turn") {
      await ingestHostUserSegments(client, session, config, hostIngested);
    }
  });

  // ── per-turn model-record persistence face (the Python model-store's
  // on_turn_complete hook, ported onto DSH's agent/turn-stopping serial
  // point — see turn-persist.js) ──
  // At each turn end: this turn's gate-passing assistant segments are
  // ingested P0/model into the session shard (append+fsync+readback —
  // crash-durable), restoring the reference "persist-then-refine" invariant
  // that the compact-time-only tiering face could not (a torn zstd tail or a
  // live-append race lost the whole read; the restart-pkill lost the lazy
  // batch) -> the chronic coverage-gap -> P2 fallback every compact.
  //
  // Registration legs (the kbs-dsh 2026-11-23 verified shape): the host-ctx
  // leg ({ global: true } — the carrier's context filter drops a plain
  // profile-ctx hook) AND the per-agent actx legs (agent scope is the
  // dispatch chain's ANCESTOR layer, so they stay live across host-ctx
  // activation states) + a bounded poller for agents alive BEFORE apply
  // (resumed web sessions). The (sid,turn) guard inside the listener makes a
  // double-delivery a no-op, never a duplicate ingest.
  const turnPersist = makeTurnPersistListener({
    client,
    logger: ctx.logger,
    enabled: () => readBool(config.persistModelTurns, true),
    minChars: () => readNum(config.modelMinChars, 200),
  });
  const offTurnEnd = ctx.on?.("agent/turn-stopping", turnPersist, { global: true });
  const agentTurnDisposers = new Map();
  const registerAgentTurnFace = (agent) => {
    const actx = agent?.ctx;
    if (!agent || typeof actx?.on !== "function") return;
    const off = actx.on("agent/turn-stopping", turnPersist);
    if (typeof off === "function") agentTurnDisposers.set(agent, off);
  };
  const offAgentCreated = ctx.on?.(
    "agent/created",
    (payload) => registerAgentTurnFace(payload?.agent ?? payload),
    { global: true },
  );
  // Bounded re-registration of LIVE agents born before this apply flushed in
  // (a resumed web session's agent is created at boot, before the
  // agent/created listener): 2s cadence × 30 ticks = a 60s window,
  // self-closing (unref'd timer + the Set dedup + the agent-lifecycle
  // disposer map).
  const seenAgents = new Set();
  let agentPollTicks = 0;
  const agentPoller = setInterval(() => {
    agentPollTicks++;
    let list = [];
    try {
      list = ctx.agents?.list?.() ?? [];
    } catch {
      /* the agents service miss is fail-open */
    }
    for (const agent of list) {
      if (!agent || seenAgents.has(agent)) continue;
      seenAgents.add(agent);
      registerAgentTurnFace(agent);
    }
    if (agentPollTicks >= 30) clearInterval(agentPoller);
  }, 2000);
  agentPoller.unref?.();

  // ── cache-keeper face: provider prefix-cache keep-alive (opt-in master) ──
  // Records each main request's exact prompt options (the llm/stream waterfall
  // seam — the rpm-limiter's own gate point) and, while a session sits idle
  // inside the keep window, re-sends that prefix with maxTokens=1 through the
  // host's ctx.llm one-shot face so the gateway's cached prefix pages stay
  // warm across the idle gap (the measured 61s-1h eviction cost, moved off
  // the model's critical path). Master default OFF = zero behavior change;
  // this deployment's HOME row sets cacheKeeper: true + ckProviders: [riway30].
  // Every getter is LIVE (volatile re-read per tick / per recorded request),
  // so card edits apply without a restart. Fail-soft: a recorder miss, a
  // timer miss, or a heartbeat failure degrades to "no refresh" — the next
  // real request pays the ordinary re-warm, nothing ever blocks.
  const cacheKeeper = makeCacheKeeper({
    ctx,
    logger: ctx.logger,
    enabled: () => readBool(config.cacheKeeper, false),
    providers: () => readStrArray(config.ckProviders, []),
    idleTriggerMs: () => readNum(config.ckIdleTriggerMs, 45000),
    refreshPeriodMs: () => readNum(config.ckRefreshPeriodMs, 45000),
    maxIdleMs: () => readNum(config.ckMaxIdleMs, 1800000),
    maxPromptChars: () => readNum(config.ckMaxPromptChars, 2000000),
    timeoutMs: () => readNum(config.ckTimeoutMs, 30000),
    auditPath: readStr(config.ckAuditPath, "~/.dsh-supercompress/cache-keeper.jsonl"),
  });

  // ── sc_drill 点取面（owner 裁决 2026-11-27「建」）：②路标设计的 pull 腿 ──
  // The auto-recall face is RETIRED (clean sweep 0967f0e): the model's memory of
  // compacted content now rides the ② dual-end 路标 rows (c#N + prov + head24…tail24,
  // the L0 pointer's sha16) and this tool is how the model PULLS the full original
  // back on demand. The tool's description IS the guidance text (the owner's
  // "指导提示词很重要，这决定模型用不用、什么时候用"): it says WHAT the tool is,
  // WHEN to use it (a truncated checkpoint row + a need for the complete original),
  // WHEN NOT to (content already in context / empty P2 bodies / cross-session),
  // and the cost semantics (read-only, O(1)-class, no LLM, fail-soft).
  if (ctx.tools?.register) {
    ctx.tools.register(defineTool({
      name: "sc_drill",
      description:
        "Fetch the FULL on-disk original text of a compact-checkpoint ledger row from the supercompress data plane (the pull replacement for the retired per-step auto-recall). " +
        "USE WHEN: a compact checkpoint in THIS session shows a truncated ledger row — an L0 pointer row like `c#143: [P0 prov=user] head24…（中省略）…tail24 (sha16=…)` or a head80 row — and you need the COMPLETE original (a decision's reasoning, code, a config value, an instruction that was compacted out of the live context) to continue the work. " +
        "DO NOT USE: when the content you need is already in your context; when the row is a P2 stub whose body was evicted with no durable digest (the tool then reports found=false — fall back to a plain re-ask or the knowledge-base face); or for cross-session archaeology (it resolves the calling session's ledger only). " +
        "Read-only, sub-second O(1)-class lookup, no LLM, no side effects. " +
        "[route-d] When the host LLM is unavailable (the rc1host host generation / a transient miss), an evicted P1/P2 row's response carries a trailing [route-d] directive: the row's digest is a compact-time head80 placeholder, and you may author a better short digest yourself and back-fill it via the sc_digest tool (the data plane stamps digest_ref='pre40'). Skip it when the placeholder already suffices.",
      parameters: {
        c_index: {
          type: "integer",
          description:
            "The ledger row number exactly as rendered in the checkpoint: the number after `c#` in a row like `c#143: …` (it is the segment's global seq). Pass this when the row shows a c#N prefix — the most common case.",
        },
        sha16: {
          type: "string",
          description:
            "The 16-hex content-hash pointer shown on L0 rows, i.e. the value inside `(sha16=…)` on the row. The most precise locator (exact/prefix content-hash match). Pass this when the row shows a sha16 pointer.",
        },
        text: {
          type: "string",
          description:
            "A distinctive fragment of the row's original text (the head24/tail24 路标 snippets, or any unambiguous substring). Bounded landmark match; use only when the row shows neither a c#N number nor a sha16 pointer.",
        },
      },
      output: {
        schema: { type: "string" },
        render: (_args, value) => [{ type: "text", text: value }],
      },
      async execute(args, exec) {
        const owner = exec.agent;
        if (owner === undefined) {
          throw new ToolContextUnavailableError("sc_drill requires an owning agent session");
        }
        // Presence-based locator detection (the c#0 row is a LEGAL c_index
        // value — the store's seq counter starts at 0, so truthiness would
        // misread c_index:0 as "no locator").
        const hasC = args.c_index !== undefined && args.c_index !== null && Number.isFinite(Number(args.c_index));
        const cIndex = hasC ? Number(args.c_index) | 0 : 0;
        const sha16 = String(args.sha16 || "").trim();
        const text = String(args.text || "").trim();
        const locCount = (hasC ? 1 : 0) + (sha16 ? 1 : 0) + (text ? 1 : 0);
        if (locCount !== 1) {
          throw new ToolArgsError([
            "sc_drill takes exactly ONE locator: c_index (the c#N row number), sha16 (the L0 pointer hash), or text (a landmark fragment)",
          ]);
        }
        // The session stamp must MATCH the ingest face's stamp (sessionKeyOf —
        // the recall-scope / ingest key shape; the daemon scopes the drill
        // window to rows stamped with exactly this key).
        const session = sessionKeyOf(owner?.session ?? owner);
        const res = await client.drill({ session, cIndex, useSeq: hasC, sha16, text });
        const data = res?.found === undefined ? (res?.data ?? res) : res;
        if (!data?.found) {
          return `sc_drill: not found — ${data?.note || "unknown locator"} (fall back to a plain re-ask or the knowledge-base face)`;
        }
        const head = `c#${data.seq} [${data.tier} prov=${data.prov}${data.kind ? " " + data.kind : ""}]`;
        const note = data.note ? `\n(${data.note})` : "";
        // route d (owner 2026-11-27, ported from the filemem handoff floor, KB
        // 4e5a93ef): on the FLOOR (no host LLM — safeLlm is undefined, i.e. the
        // rc1host host generation or a transient miss) an evicted P1/P2 row's
        // digest is a compact-time head80 placeholder. The CALLING model (already
        // running on the host's own provider) may author a better digest and
        // back-fill it via the sc_digest tool — the data plane stamps
        // digest_ref='pre40' (the 40% pre-digest face respects it: it never
        // re-digests an already-upgraded row). No host LLM API, no key, any
        // host generation. The deterministic head80 placeholder stands when the
        // model skips. On an rc.5+ host with ctx.llm the 40% pre-digest face
        // auto-upgrades, so the directive is floor-only.
        const routeD = !safeLlm(ctx) && (data.tier === "P1" || data.tier === "P2")
          ? "\n\n[route-d] This evicted row's digest is a compact-time placeholder (the host LLM was unavailable at compact time). If a better digest is worth persisting for future compacts, author a short one (<=200 chars: the single key fact + a 1-3 sentence summary) from the material above and call the sc_digest tool with { sha16: \"<this row's (sha16=…)\", digest: \"<your digest>\" } — the data plane stamps digest_ref='pre40' (the 40% pre-digest face will not re-digest it). Skip when the placeholder already suffices or you do not have the row's sha16."
          : "";
        return head + note + "\n" + String(data.text ?? "") + routeD;
      },
      presentCall: (args) => ({
        card: "text",
        title: `sc_drill ${args.sha16 ? String(args.sha16).slice(0, 8) : args.c_index ? "c#" + args.c_index : "text"}`,
      }),
    }));

    // ── sc_digest — the route-d LLM back-fill channel (owner 2026-11-27) ─────
    // The companion write face to the sc_drill floor's [route-d] model_directive:
    // when the host LLM is unavailable (the rc1host host generation, or a
    // transient miss) an evicted P1/P2 row's digest is a compact-time head80
    // placeholder. The CALLING model (already running on the host's own
    // provider) authors a better digest and writes it back HERE — the data
    // plane stamps the segment's digest_ref to 'pre40' (the 40% pre-digest face
    // respects it: it never re-digests an already-upgraded row; the durable
    // digest-ref marker survives a daemon restart). No host LLM API and no key
    // management: the LLM work is done by the model already in the turn, so it
    // is universal across host generations. The deterministic head80
    // placeholder stands when the model skips the directive (fail-open).
    // Registered on BOTH variants: on the FULL host it is a manual override
    // (the 40% pre-digest face auto-upgrades), on the RC1HOST host it is the only
    // channel to a real LLM digest.
    ctx.tools.register(defineTool({
      name: "sc_digest",
      description:
        "Back-fill a model-authored digest onto an evicted compact-checkpoint segment (the route-d channel, the companion write face to sc_drill's [route-d] directive). " +
        "USE WHEN: a sc_drill response carries a [route-d] directive — the row's digest is a compact-time head80 placeholder because the host LLM was unavailable at compact time — and you have read the row's original text above and a better short digest is worth persisting for future compacts. " +
        "Write a short digest (<=200 chars: the single key fact + a 1-3 sentence summary) of the material and pass it with the row's sha16 (the L0 pointer row's `(sha16=…)` marker). " +
        "The data plane stamps the segment's digest_ref to 'pre40' (the 40% pre-digest face will not re-digest it) and persists a durable marker (survives a daemon restart). " +
        "No host LLM API / no key: the digest is YOUR output. Deterministic fail-open: an unknown sha16 is reported, not an error (the placeholder stands); skip when the head80 placeholder already suffices. " +
        "Writes ONLY the digest_ref marker + digest text onto the evicted segment — it never re-tiers or mutates the original text.",
      parameters: {
        sha16: {
          type: "string",
          description:
            "The 16-hex content-hash handle of the evicted segment — the value inside the L0 pointer row's `(sha16=…)` marker. This is the segment_id the data plane keys the digest onto.",
        },
        digest: {
          type: "string",
          description:
            "The model-authored digest: a short (<=200 char) key_fact + summary of the segment's original text (the material the sc_drill face returned). Persisted as the segment's LLM digest (digest_ref='pre40').",
        },
      },
      output: {
        schema: { type: "string" },
        render: (_args, value) => [{ type: "text", text: value }],
      },
      async execute(args, exec) {
        const owner = exec.agent;
        if (owner === undefined) {
          throw new ToolContextUnavailableError("sc_digest requires an owning agent session");
        }
        const sha16 = String(args.sha16 || "").trim();
        const digest = String(args.digest || "").trim();
        if (!sha16) {
          throw new ToolArgsError(["sc_digest: the sha16 content-hash handle is required (the L0 pointer row's (sha16=…) marker)"]);
        }
        if (!digest) {
          throw new ToolArgsError(["sc_digest: the digest text is required (your short key_fact + summary of the segment's original text)"]);
        }
        // The data-plane digest write-back (the Go `digest` cmd: SetDigest + the
        // durable digest-ref marker). Fail-open: an unknown handle is reported
        // (written=false + note), not an error — the head80 placeholder stands.
        const res = (await client.digest(sha16, digest, "pre40")) ?? {};
        if (res.written === false) {
          return `sc_digest: not written — ${res.note || "unknown handle"} (the head80 placeholder stands; re-check the row's sha16)`;
        }
        return `sc_digest: digest back-filled for sha16=${sha16.slice(0, 8)}… (digest_ref stamped 'pre40'; the durable digest-ref marker is ${res.durable_ref ? "written" : "pending"} — the 40% pre-digest face will not re-digest this row)`;
      },
      presentCall: (args) => ({
        card: "text",
        title: "sc_digest " + String(args.sha16 || "").slice(0, 8),
      }),
    }));
  }

  // ── teardown ──
  // Mirror dsh-mcp-client exactly: ctx.effect(() => dispose, label) where the
  // arrow RETURNS the disposer function (the SyncEffect the fiber runs on
  // disposal). Returning undefined / not-a-fn triggers "Invalid effect".
  // A shared client is released (refcount) — the daemon stops only when the
  // LAST activation releases it; a caller-provided client is stopped now.
  const dispose = () => {
    cacheKeeper.dispose();
    offSession?.();
    offPersistence?.();
    // The per-turn model-persistence legs: stop the bounded poller, drain the
    // per-agent ctx disposers (the two-owner rule: a plugin unload must
    // remove the agent.ctx registrations itself), and the host-ctx hooks.
    clearInterval(agentPoller);
    for (const off of agentTurnDisposers.values()) {
      try {
        off?.();
      } catch {
        /* a disposer miss must not block teardown */
      }
    }
    agentTurnDisposers.clear();
    offAgentCreated?.();
    offTurnEnd?.();
    // Close the session on the daemon before releasing the shared client (the
    // shared client is refcounted — it only stops when the LAST activation
    // releases it; a caller-provided client is stopped now). Fail-open: a
    // session_end miss must not block teardown.
    client.sessionEnd?.().catch(() => {});
    // The compact-ledger session boundary (/new, rotation rebind): a whole-
    // section clear (entries 0, generation +1, seals +1) so the next session
    // re-accumulates cleanly. Fail-open: a reset miss must not block teardown.
    client.compactLedger?.("reset").catch(() => {});
    releaseSharedClient(client);
    // Release this activation's shared live getters (single-activation host:
    // the next apply republishes; a stale getter must not leak across
    // activations in the same process).
    clearSharedEnableTieringGetter();
    clearSharedUseLedgerSummarizerGetter();
    clearSharedRenderLadderGetter();
    clearSharedCapacityRatioGetter();
    clearSharedBandThresholdsGetter();
    clearSharedLiveUserTrimGetter();
    clearSharedBandGatesGetter();
  };
  // Register teardown the mcp-client way: ctx.effect(() => dispose, label). The
  // apply() body must NOT return a plain object (the outer effect would try to
  // collect it as a disposable -> "Invalid effect"). Return undefined.
  if (typeof ctx.effect === "function") {
    ctx.effect(() => dispose, "dsh-supercompress.cleanup");
  }
}

function extractText(content) {
  if (content == null) return "";
  if (typeof content === "string") return content;
  if (Array.isArray(content)) return content.map((b) => b?.text ?? "").join(" ");
  return String(content);
}

// ── compact-ledger host consumer face (ported from Python sc/compact_ledger.py) ──
// Stage THIS compact cycle's evicted P1/P2 block into the <sid>.compact.json
// cumulative ledger (the Python engine's `compress()` -> `self._ledger.append(
// staged_text)` call face). The staged block = the evicted P1/P2 segments'
// digest-or-head80 (the compact summary of this cycle); the ledger is
// append-only + cap-bounded (trimmable P1 fold -> settled -> seal fallback),
// so the cumulative card stays bounded across many compacts.
//
// LLM hookup (this face + the 40% pre-digest pattern): when the host ctx.llm + a
// resolvable route are available, each evicted segment is DIGESTED via the host
// main-model endpoint (aux ≡ main-model, zero new provider) BEFORE staging —
// the ledger gets a real LLM digest (key_fact + summary) instead of the raw
// head80. A digest miss (no LLM / no route / empty reply) falls back to the
// head80 (宁漏勿错: the ledger block is always populated, never dropped).
// Fail-open: a compactLedger miss never blocks the host compact gate.
async function compactLedgerStage(client, ctx, config, dist, routeSource) {
  if (!readBool(config.enableCompactLedger, false)) return 0;
  const evicted = (dist?.evicted ?? []).filter((e) => e && (e.tier === "P1" || e.tier === "P2"));
  if (evicted.length === 0) return 0;
  // LLM resolver (aux ≡ host main-model endpoint, same as the 40% pre-digest
  // face). No ctx.llm / no route -> undefined -> head80 fallback per segment.
  const { oneShotText, routeFromAgent, textUserMessage } = await import("./llm-one-shot.js");
  const { parseDigestResponse } = await import("./tagger.js");
  const route = routeFromAgent(routeSource || {});
  const hasLlm = Boolean(route && safeLlm(ctx));
  // 残留②: the same bounded per-call LLM wait as the 40% pre-digest face (0 = off).
  const llmTimeoutMs = readNum(config.tierLlmTimeoutMs, 30000);
  const lines = [];
  for (const seg of evicted) {
    const raw = String(seg.original_text || "");
    let body;
    if (hasLlm) {
      try {
        const text = await oneShotText(ctx, {
          route,
          messages: [
            textUserMessage(
              "Compress the conversation segment below into strict JSON (no code fence, no extra text):\n" +
                '{"key_fact": "<=60 chars: the single most important fact/decision", ' +
                '"summary": "<=200 chars: 2-4 sentence digest"}\n--- segment ---\n' +
                raw.slice(0, 4096),
            ),
          ],
          purpose: "compact-ledger",
          maxTokens: 300,
          signal: undefined,
        });
        const { keyFact, summary } = parseDigestResponse(text);
        body = keyFact || summary ? `${keyFact}\n${summary}`.trim() : raw.slice(0, 80);
      } catch {
        body = raw.slice(0, 80); // 宁漏勿错: a digest miss keeps the head80
      }
    } else {
      body = raw.slice(0, 80); // no LLM -> head80 (the deterministic fallback)
    }
    lines.push(`[${seg.tier}/${seg.digest_ref || "none"}] ${body}`);
  }
  const staged = lines.join("\n");
  try {
    // The staged compact block is a TRIMMABLE P1-style page (the cap-trim
    // folds it to a stub before the seal floor; the original stays durable).
    await client.compactLedger("append", { text: staged, settled: false, kind: "adhoc", trimmable: true });
    return evicted.length;
  } catch {
    /* fail-open: the compact-ledger staging miss must not block the host compact */
    return 0;
  }
}

// ── live persistence face: one splice-time user turn -> P0/user ──
// DSH surfaces the user turn as `agent/inbox/spliced` (target next-turn,
// source.kind === "user"), NOT a top-level user/message. Persist user-source
// splices; keep a user/message fallback for surfaces that emit it directly.
// The dshsc marker + host-noise guards keep our own recall tail and host
// boilerplate out of the P0 store. De-dup: exact repeats across retries are
// absorbed by the store's content-hash dedup.
async function persistSpliceUserTurn(client, session, event, config = {}) {
  let userText = null;
  if (event?.type === "agent/inbox/spliced" && event.data?.target === "next-turn") {
    for (const m of event.data?.inserted ?? []) {
      // A genuine user turn: user-source. DSH-native: the host marks its
      // own noise with distinct source kinds (user-approval, tool-jobs,
      // repeat-tool-reminder, dshsc-recall, …) — only kind "user" is the
      // real user turn. (A plain `user: true` boolean field does not exist
      // on the DSH UserMessage; the source.kind check is the interface.)
      const src = m?.source;
      if (src?.kind !== "user") continue;
      if (src?.dshsc === "recall") continue; // skip OUR recall injection (no feedback loop)
      const raw = Array.isArray(m?.content)
        ? m.content.map((c) => c?.text ?? "").join("")
        : String(m?.content ?? "");
      // Per-message: strip host preamble lines that are glued onto the user
      // channel (the "Time sampled…" + system-reminder + browser-TZ block).
      // The result is the user's actual content (or "" when the message was
      // pure preamble). The noise check runs on the cleaned text, so a
      // preamble-only message drops out here without polluting userText.
      const cleaned = extractUserContent(raw);
      if (looksLikeHostNoise(cleaned)) continue;
      if (!cleaned || !cleaned.trim()) continue;
      userText = userText ?? "";
      userText += cleaned;
    }
  } else if (event?.type === "user/message") {
    // DSH-native filter (verified against dsh-llm MessageSourceMap + the
    // live session logs): a user/message event's `data` IS the UserMessage
    // ({ role, content, source, id }). Only GENUINE user turns carry
    // source.kind "user". The host rides its own noise over the user
    // channel with distinct source kinds — time-context ("Time sampled…"),
    // runtime-context / skill-catalog / agent-instructions
    // (<system-reminder> blocks), user-approval ("The user changed the
    // approval policy…"), tool-jobs ("background job …"),
    // repeat-tool-reminder ("You are repeating…"), plus our own
    // dshsc-recall tails and sibling plugins' kinds (filemem-dsh). The
    // kind check below is the DSH interface that excludes every
    // host-injected source in one shot, instead of relying on fragile text
    // heuristics alone.
    const kind = event.data?.source?.kind;
    if (kind && kind !== "user") return;
    const t = extractText(event.data?.content);
    // Belt-and-suspenders for kind "user" turns that carry host records
    // glued onto the user text (the host appends a tool-abort record —
    // "Failed / <tool> / Error: tool call aborted / IN {…} / OUT …" — to
    // the user message when a tool call aborts mid-turn): strip the
    // known noise lines, keep only the user's own words.
    const cleaned = extractUserContent(t);
    if (looksLikeHostNoise(cleaned)) return;
    userText = cleaned;
  }
  if (!userText || !userText.trim()) return;
  try {
    await client.ingest(userText, {
      tier: "P0",
      prov: "user",
      kind: "segment",
      // session isolation stamp: the recall face's scope is an EQUALITY
      // filter on this field — this session's turns stay in this session's
      // recall tail, never leak across sessions.
      session: sessionKeyOf(session),
    });
    // Live-ledger face (Block ③, opt-in): each ingested user instruction drives
    // the phase migration (old phase supersedes -> open tasks close as
    // blocked; the P0 ledger row is written write-before-compress). Off by
    // default (zero behavior change); fail-open (a ledger miss never breaks
    // the persistence path).
    if (readBool(config?.enableLedger, false)) {
      try {
        await client.ledger("instruction", {
          text: userText,
          goal: readStr(config?.ledgerGoal, ""),
          topic: sessionKeyOf(session),
          checkpointEvery: Number(config?.ledgerCheckpointEvery ?? 0),
        });
      } catch {
        /* fail-open: a ledger miss must not break the user-turn persistence */
      }
    }
  } catch {
    /* fail-open: a persistence miss must not break the session */
  }
}

// sessionKeyOf — the host session id used as the recall-scope / ingest stamp
// (same key shape the recall face passes as recall_scope).
function sessionKeyOf(session) {
  return session?.id || session?.header?.id || "";
}

// Host-injected boilerplate that is NOT a user turn: <system-reminder> blocks,
// our own recall step-tail, the host compaction CHECKPOINT message (the
// `compaction/summary` user message the host injects after shadowing a range —
// it rides the user channel but is host-generated, not user speech), the
// per-turn "Time sampled while preparing…" preamble, host job/agent notices
// ("background job …", "[filemem …]"), and host policy-change announcements.
// These must never become durable P0 user segments (the P0 of the shadowed
// range is already anchored by our own distill gate; the checkpoint is a
// LLM-condensed copy and would pollute the store with a lossy duplicate; the
// "Time sampled" preamble is a timestamp, not content; the job/filemem
// notices are host noise that — once ingested — dominated the global-store
// recall top-k and is exactly the "demo data" the user saw repeated in
// every session's injected block).
function looksLikeHostNoise(t) {
  if (!t) return true;
  const s = t.trimStart();
  // host boilerplate prefixes (exact startswith — zero false-positives):
  if (s.startsWith("<system-reminder>")) return true;
  if (s.startsWith("[supercompress recall")) return true;
  if (s.startsWith("[filemem ")) return true;
  if (s.startsWith("Time sampled while preparing")) return true;
  if (s.startsWith("This is an automatically generated checkpoint")) return true;
  if (s.startsWith("<compacted-summary>")) return true;
  if (s.startsWith("You are repeating the exact same tool call")) return true;
  if (s.startsWith("background job ")) return true;
  if (s.startsWith("The user changed the approval policy")) return true;
  // Host tool-call failure/abort notice: a payload that is a JSON object
  // carrying host-notice fields ("command"/"description"/"error"/"tool call
  // aborted") — the host's own tool-failure record, not user speech. Only
  // triggered when the payload STARTS with "{" (a bare JSON notice), so user
  // prose that merely mentions JSON or "Failed" mid-sentence is NOT dropped.
  if (s.startsWith("{")) {
    const hasHostMarker =
      s.includes('"command"') ||
      s.includes('"description"') ||
      s.includes('"tool call aborted"') ||
      s.includes('"error"');
    if (hasHostMarker) return true;
  }
  // A user message that is ENTIRELY host preamble (no user content): the host
  // splices "Time sampled…" + system-reminder + browser-TZ lines together with
  // no user text at all — that is noise, not a P0 user turn.
  if (s.startsWith("Time sampled while preparing")) {
    const userLines = s.split(/\r?\n/).filter((l) => {
      const t2 = l.trim();
      if (!t2) return false;
      if (t2.startsWith("<system-reminder>")) return false;
      if (t2.startsWith("[supercompress recall")) return false;
      if (t2.startsWith("[filemem ")) return false;
      if (t2.startsWith("Time sampled while preparing")) return false;
      if (t2.startsWith("Browser time zone for this request:")) return false;
      if (t2.startsWith("Elapsed since the preceding model-visible message:")) return false;
      if (t2.startsWith("This is an automatically generated checkpoint")) return false;
      if (t2.startsWith("You are repeating the exact same tool call")) return false;
      if (t2.startsWith("background job ")) return false;
      if (t2.startsWith("The user changed the approval policy")) return false;
      return true;
    });
    if (userLines.length === 0) return true;
    // Mixed: keep the user lines only (drop the preamble), so a real user
    // turn glued onto a host preamble still persists its user content.
    return false; // caller re-extracts; see extractUserContent below
  }
  if (s.includes("<compacted-summary>") && s.includes("automatically generated checkpoint")) return true;
  return false;
}

// extractUserContent — when a user-channel payload is host preamble + real user
// speech glued together (e.g. "Time sampled…" + a system-reminder block + the
// user's actual message, OR a real user line + a host tool-abort/failure JSON
// block), strip the unambiguous host-notice lines and return the remaining user
// content. Returns "" when nothing but host noise is present.
//
// Conservative classifier: a line is dropped ONLY when it is unambiguously a
// host notice — a known boilerplate prefix, a bare host-notice JSON object
// (starts with "{" and contains host markers like "command"/"description"), or
// a host-notice value line ("IN …"/"OUT …"/"Error: …"/"Failed"). Genuine user
// prose is NEVER dropped, even when it contains words like "Failed" mid-line
// or is mixed with a notice line.
function extractUserContent(t) {
  if (!t) return "";
  const s = String(t).trimStart();
  const lines = s.split(/\r?\n/);
  // A host-notice prefix line (e.g. "[filemem recall]"): the line itself and
  // any immediately-following list-content lines that belong to the notice
  // body are dropped. We track "in-notice-body" so that user prose appearing
  // AFTER the notice's list body is still kept (the notice body ends when a
  // non-list line appears).
  const NOTICE_PREFIXES = ["[supercompress recall", "[filemem "];
  const isNoticeLine = (t2) => NOTICE_PREFIXES.some((p) => t2.startsWith(p));
  const isListLine = (l) => {
    const t2 = l.trim();
    return t2.startsWith("- ") || t2.startsWith("• ") || t2.startsWith("* ") || /^\d+\.\s/.test(t2);
  };
  const isKnownHostBoilerplate = (t2) =>
    t2.startsWith("<system-reminder>") ||
    t2.startsWith("Time sampled while preparing") ||
    t2.startsWith("Browser time zone for this request:") ||
    t2.startsWith("Elapsed since the preceding model-visible message:") ||
    t2.startsWith("Elapsed since the preceding step context:") ||
    t2.startsWith("This is an automatically generated checkpoint") ||
    t2.startsWith("<compacted-summary>") ||
    t2.startsWith("</compacted-summary>") ||
    t2.startsWith("You are repeating the exact same tool call") ||
    t2.startsWith("background job ") ||
    t2.startsWith("The user changed the approval policy") ||
    isNoticeLine(t2);
  // Host tool-abort block: when the payload carries the host's abort record
  // ("Error: tool call aborted"), the block runs from the "Failed" line to the
  // LAST "Error: tool call aborted" line (Failed -> tool name -> IN -> JSON ->
  // OUT -> Error). Drop that whole zone by index; user prose BEFORE the
  // "Failed" line is the real user turn and is kept.
  const hasAbortRecord = s.includes("Error: tool call aborted");
  let abortStart = -1;
  let abortEnd = -1;
  if (hasAbortRecord) {
    for (let i = 0; i < lines.length; i++) {
      const t2 = lines[i].trim();
      if (abortStart < 0 && t2 === "Failed") abortStart = i;
      if (t2 === "Error: tool call aborted") abortEnd = i;
    }
    if (abortStart < 0) abortStart = -1;
    // No "Failed" anchor: drop from the first abort-record line instead.
    if (abortStart < 0 && abortEnd >= 0) {
      abortStart = abortEnd;
    }
  }
  // Pass 1: drop known host-boilerplate lines and the notice body.
  const kept1 = [];
  let inNoticeBody = false;
  let inReminder = false; // inside a <system-reminder>…</system-reminder> block
  for (let i = 0; i < lines.length; i++) {
    const l = lines[i];
    // Host tool-abort block zone: drop the whole Failed→abort-record span.
    if (abortStart >= 0 && i >= abortStart && i <= abortEnd) continue;
    const t2 = l.trim();
    // Handle <system-reminder> block: the opening line and any line up to and
    // including the closing "</system-reminder>" are host boilerplate. A
    // genuine user message that opens with <system-reminder> and closes it in
    // the same payload is host noise; user prose after the close is kept.
    if (inReminder) {
      // A line inside a reminder/compacted block that still carries the
      // opening tag (e.g. "<compacted-summary>\n## Primary Request" was
      // already split by the caller, so this case is the opening line that
      // did NOT start the block — e.g. the line right after the opening
      // line that repeats the tag). End the block on any line that contains
      // a closing tag.
      if (
        t2.includes("</system-reminder>") ||
        t2.includes("</compacted-summary>")
      ) {
        inReminder = false;
        continue;
      }
      continue; // drop the body line
    }
    if (inNoticeBody) {
      if (isListLine(l)) continue;
      inNoticeBody = false;
    }
    if (!t2) continue;
    if (isNoticeLine(t2)) {
      inNoticeBody = true;
      continue;
    }
    if (t2.startsWith("<system-reminder>")) {
      if (t2.includes("</system-reminder>")) continue;
      inReminder = true;
      continue;
    }
    // <compacted-summary> block: the opening line starts the body-drop mode;
    // the closing line (handled by the inReminder branch) ends it. A
    // single-line block (open+close on the same line) is dropped outright.
    if (t2.startsWith("<compacted-summary>")) {
      if (t2.includes("</compacted-summary>")) continue;
      inReminder = true;
      continue;
    }
    if (isKnownHostBoilerplate(t2)) continue;
    if (t2 === "IN" || t2 === "OUT" || t2.startsWith("Error: tool call aborted")) continue;
    if (t2.startsWith("{") && t2.endsWith("}")) {
      const hasHostMarker =
        t2.includes('"command"') ||
        t2.includes('"description"') ||
        t2.includes('"tool call aborted"') ||
        t2.includes('"error"');
      if (hasHostMarker) continue;
    }
    kept1.push(l);
  }
  return kept1.join("\n").trim();
}

/**
 * Scheme A-2: backfill P0 user turns from the host's native session log at
 * session open/resume. Reads the host zstd V4 log for this session's cwd (via
 * the daemon's multi-frame reader), ingests each deduped user turn as P0/user.
 * The content-hash dedup in the store makes already-persisted turns a no-op,
 * so this safely backfills historical turns without double-storing the current
 * in-flight one (which the live handler owns). Fail-open throughout. When the
 * session header carries no cwd, the last-resort leg locates the log by the
 * tree-unique session id (this session's own user turns only).
 * @returns {number} number of segments read from the host log.
 */
async function backfillFromHost(client, session, config) {
  const cwd = session?.header?.cwd;
  const key = sessionKeyOf(session);
  const dshRoot = config.dshRoot || `${process.env.HOME || "/root"}/.dsh`;
  let res;
  let lastResort = false;
  if (cwd) {
    // Scheme A-2: backfill from the WHOLE cwd session dir (every prior
    // session's durable user turns). At open-time the current session's
    // in-flight turn isn't flushed yet, so this pulls historical turns
    // only; the live path owns the current one. Content-hash dedup makes
    // already-stored turns a no-op.
    const dir = resolveHostDir({ dshRoot, cwd });
    if (!dir) return 0;
    res = await client.hostUserSegmentsDir(dir);
  } else if (key) {
    // The cwd-INDEPENDENT last resort (the 2026-11-23 hardening): the live
    // session header's cwd is OPTIONAL — when it is missing the scheme A-2
    // dir-wide read is not enumerable, and this face used to silently
    // return 0 (zero user turns backfilled on every open of a cwd-less
    // session). The session id is tree-unique, so pull THIS session's own
    // user turns instead. The content-hash dedup makes it safe to run on
    // every open.
    const file = resolveHostSessionBySessionId({ dshRoot, sessionId: key });
    if (!file) return 0;
    res = await client.hostUserSegments(file);
    lastResort = true;
  } else {
    return 0;
  }
  let n = 0;
  for (const seg of res?.segments ?? []) {
    const text = seg?.text;
    if (!text || !text.trim()) continue;
    // session isolation: each segment carries its source session id (the
    // host session dir name the daemon read it from) — a PRIOR session's
    // turns are stamped with THAT session, so they enrich that session's
    // recall tail, not this one's. UNSTAMPED legacy rows stay legacy
    // (scope-empty/global recall only — never re-stamped to this session:
    // that would leak foreign content into the scoped recall). EXCEPT the
    // last-resort leg, where the single file IS this session's log — an
    // old daemon's missing stamp means "this session" (the key fallback).
    const stamp = seg?.session || (lastResort ? key : undefined);
    await client.ingest(text, { tier: "P0", prov: "user", kind: "segment", user_turn: true, session: stamp });
    n++;
  }
  return n;
}

/**
 * Scheme A (userSource === "host"): read the host session file ONCE per session
 * (deduped by `ingested`), hand its user turns to the daemon, and ingest them
 * as P0/user. The existsSync gate makes a missing file a clean 0 (the live
 * path never runs in host mode — see apply() — so a host-log miss is simply
 * "no turns persisted yet"; fail-open, no re-throw).
 * @returns {number} number of user turns ingested from the host log.
 */
async function ingestHostUserSegments(client, session, config, ingested) {
  const key = session?.id;
  if (!key || ingested.has(key)) return 0;
  ingested.add(key); // run once even on failure (don't hammer the daemon per splice)
  let n = 0;
  try {
    const dshRoot = config.dshRoot || `${process.env.HOME || "/root"}/.dsh`;
    const cwd = session?.header?.cwd;
    // The cwd-INDEPENDENT last resort (the 2026-11-23 hardening): the header
    // cwd is optional — when missing, locate the session log by its
    // tree-unique id instead of silently returning 0.
    let file = cwd ? resolveHostSession({ dshRoot, cwd, sessionId: key }) : "";
    if (!file) file = resolveHostSessionBySessionId({ dshRoot, sessionId: key });
    if (!file) return 0; // no native log to read (cwd-less header + no tree hit)
    const res = await client.hostUserSegments(file);
    for (const seg of res?.segments ?? []) {
      const text = seg?.text;
      if (!text || !text.trim()) continue;
      // session isolation stamp (the source session file's dir name); the
      // single-file reader's `session` key degrades to "" on an old daemon
      // (legacy row — served only by the scope-empty/global recall).
      await client.ingest(text, { tier: "P0", prov: "user", kind: "segment", user_turn: true, session: seg.session });
      n++;
    }
  } catch {
    /* fail-open: host-source miss -> 0 */
  }
  return n;
}

export { DaemonClient };
