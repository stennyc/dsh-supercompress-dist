// cache-keeper.js — the provider prefix-cache keep-alive face ("cache-keeper").
//
// Why it exists (measured 2026-11-25, this deployment's riway30 gateway):
//   gap <= 60s between requests   -> 99.5% prefix-cache hit (the warm prefix);
//   gap 61s - 1h                 -> the gateway evicts the OLDEST ~6-13% of
//                                   the session's cached pages (LRU under KV-
//                                   pool pressure) -> 87-93% hit on resume;
//   after a compaction/reseed     -> a full cold jump (4-22%) — that one is
//                                   the supercompress band's job, not this
//                                   module's. The DSH host has NO prefix-cache
//                                   control surface: the only client-side
//                                   refresh lever is re-sending the session's
//                                   own last request prefix, which re-touches
//                                   (or re-writes) exactly those pages.
//
// Design (byte-identity is the whole trick):
//   - RECORDER: an "llm/stream" waterfall listener (the SAME seam the
//     rpm-limiter gates on — the host's LlmRuntime runs every streaming call
//     through this waterfall, dsh-llm L204-206) captures each main request's
//     EXACT GenerateOptions (provider/model/messages/system/tools/toolHistory/
//     sessionId — the provider's prompt bytes). ONE record per session; the
//     LAST request's options win (the host deep-freezes each request, agent-
//     loop L740, so the captured reference is stable and needs no copy).
//     The keeper's own heartbeats (options.purpose === CACHE_KEEPER_PURPOSE)
//     are NOT recorded — otherwise a refresh would update its own idle clock
//     and the keeper would fire forever.
//   - KEEPER: a bounded host-lifetime timer ticks every TICK_MS. For every
//     recorded session that is idle >= idleTriggerMs (but still <= maxIdleMs)
//     and DUE for a refresh (>= refreshPeriodMs since the last beat), it
//     re-sends the recorded options with maxTokens=1 through the host's own
//     ctx.llm one-shot face (the llm-one-shot.js contract: provider/model
//     ride the options, NO prepareCall). The heartbeat's prompt bytes are
//     IDENTICAL to the last main request, so the gateway refreshes exactly
//     those prefix pages: a cheap cache-READ while still warm; a cache-
//     CREATION only for the already-evicted slice — the SAME cost the next
//     real request would have paid, moved off the model's critical path.
//   - Accounting: the heartbeat traverses the same llm/stream waterfall, so
//     the rpm-limiter counts it against the route's window automatically
//     (one heartbeat = one gated request start).
//   - Fail-soft: a recorder miss / timer miss / LLM miss degrades to "no
//     refresh" (the next real request pays the ordinary re-warm — zero
//     behavioral change). Three consecutive heartbeat failures back a
//     session OFF (no hammering a degraded endpoint).
//
// Zero new providers: a refresh rides the session's OWN main-model route.
// Zero deps beyond node stdlib + the host LLM seam (the repo rule).
import { appendFileSync } from "node:fs";
import { homedir } from "node:os";

export const CACHE_KEEPER_PURPOSE = "supercompress-cache-keeper";

// The tick cadence is fixed (not a knob): 15s keeps the first refresh ~30s
// ahead of the measured ~60s eviction without wasting provider requests on
// sessions that will resume within a minute anyway.
export const TICK_MS = 15000;
// Three consecutive failures back a session off for this host lifetime.
export const MAX_CONSEC_FAILS = 3;
// At most one audit line per session per 10s (a stuck failure path must not
// spin the file; success lines are rare by design).
const AUDIT_MIN_GAP_MS = 10000;

/**
 * Estimate the prompt size of a captured request in CHARS (the cost-ceiling
 * unit for ckMaxPromptChars). Counts messages + system + tools.
 */
export function estimatePromptChars(options) {
  let chars = 0;
  const msg = options?.messages;
  if (Array.isArray(msg)) {
    for (const m of msg) {
      const c = m?.content;
      if (typeof c === "string") chars += c.length;
      else if (Array.isArray(c)) {
        for (const b of c) chars += String(b?.text ?? b?.input_text ?? "").length;
      }
    }
  }
  if (typeof options?.system === "string") chars += options.system.length;
  const tools = options?.tools;
  if (Array.isArray(tools)) {
    try {
      chars += JSON.stringify(tools).length;
    } catch {
      /* an un-serializable tool schema still travels byte-identical */
    }
  }
  return chars;
}

/**
 * Build the ONE-SHOT heartbeat options from a captured main-request options
 * object. Keeps every PROMPT-BYTE field byte-identical (messages/system/
 * tools/toolHistory + the provider/model route + reasoningEffort); forces
 * maxTokens=1 (a refresh must not generate 64K tokens) and stamps purpose +
 * a bounded timeout signal. Non-prompt metadata (the captured maxTokens/
 * stop/temperature/signal) is deliberately DROPPED — it is not part of the
 * provider's cache key.
 */
export function heartbeatOptions(captured, { timeoutMs } = {}) {
  const o = captured ?? {};
  const hb = {
    provider: o.provider,
    model: o.model,
    messages: o.messages,
    maxTokens: 1,
    purpose: CACHE_KEEPER_PURPOSE,
  };
  if (o.system !== undefined) hb.system = o.system;
  if (o.tools !== undefined) hb.tools = o.tools;
  if (o.toolHistory !== undefined) hb.toolHistory = o.toolHistory;
  if (o.sessionId !== undefined) hb.sessionId = o.sessionId;
  if (o.reasoningEffort !== undefined) hb.reasoningEffort = o.reasoningEffort;
  if (timeoutMs > 0) hb.signal = AbortSignal.timeout(timeoutMs);
  return hb;
}

/**
 * Mount the cache-keeper face.
 * @param {object} o
 * @param {object} o.ctx the plugin Context (ctx.on + ctx.llm + ctx.logger).
 * @param {object} [o.logger] a logger override (tests).
 * @param {() => boolean} o.enabled the live master-switch getter.
 * @param {() => string[]} o.providers the live provider-route scope getter
 *   (empty = the face is INERT — nothing is recorded, matching the rpm-
 *   limiter's "no routes listed = inert" precedent).
 * @param {() => number} o.idleTriggerMs first refresh after this much idle.
 * @param {() => number} o.refreshPeriodMs re-fire cadence while still idle.
 * @param {() => number} o.maxIdleMs stop heartbeating after this much idle
 *   (a dead session burns no tokens; its record is freed).
 * @param {() => number} o.maxPromptChars cost ceiling on recorded prefixes.
 * @param {() => number} o.timeoutMs per-heartbeat LLM wait (0 = unbounded,
 *   the repo's tierLlmTimeoutMs analog).
 * @param {string} [o.auditPath] the JSONL audit file ("~" expanded; "" = off).
 * @param {object} [o.timers] { setInterval, clearInterval } injection (tests).
 * @returns {{ dispose: () => void, kick: () => void, records: () => number }}
 *   kick() runs ONE tick NOW (test / forced-refresh face); records() is the
 *   live record count (observability).
 */
export function makeCacheKeeper(o) {
  const ctx = o.ctx;
  const logger = o.logger ?? ctx?.logger;
  const setIntervalFn = o.timers?.setInterval ?? globalThis.setInterval;
  const clearIntervalFn = o.timers?.clearInterval ?? globalThis.clearInterval;

  // sessionId -> { options (frozen), promptChars, lastSeenAt, lastBeatAt,
  //                consecFails, lastAuditAt }
  const records = new Map();

  // ── disk evidence (the journal does not route this plugin's logger; the
  // audit file is the observable of record) ──
  // legFirstHit: legName -> ts of that leg's FIRST delivered llm/stream
  // event (proof the waterfall delivers to this registration at all).
  const legFirstHit = {};
  const captureStamp = new Map(); // sid -> last capture-line ts (5min rate)
  const auditLine = (obj) => {
    const path = o.auditPath;
    if (!path) return;
    try {
      const p = String(path).startsWith("~") ? homedir() + String(path).slice(1) : String(path);
      appendFileSync(p, JSON.stringify(obj) + "\n");
    } catch {
      /* best-effort */
    }
  };

  // ── the recorder leg: capture each MAIN request's exact prompt options ──
  // The waterfall listener MUST return the stream synchronously and NEVER
  // block: recording is a Map.set on a frozen reference. The purpose-guard
  // drops the keeper's own heartbeats (no self-refresh loop).
  const recorder = (legName, options, next) => {
    try {
      if (!legFirstHit[legName]) {
        legFirstHit[legName] = Date.now();
        auditLine({ ts: Date.now(), kind: "leg-first-hit", leg: legName, provider: String(options?.provider ?? "") });
      }
      if (options?.purpose === CACHE_KEEPER_PURPOSE) return next(); // our own beat
      const enabled = o.enabled?.() !== false;
      const scope = o.providers?.() ?? [];
      if (!enabled || !Array.isArray(scope) || scope.length === 0) return next();
      if (!scope.includes(String(options?.provider ?? ""))) return next();
      const sid = options?.sessionId;
      if (!sid) return next(); // un-attributable: cannot be refreshed
      const chars = estimatePromptChars(options);
      const cap = o.maxPromptChars?.() ?? 0;
      if (cap > 0 && chars > cap) return next(); // cost ceiling: skip
      const prev = records.get(sid);
      const nowTs = Date.now();
      if (!prev || nowTs - prev.lastSeenAt > 120000) {
        // Capture observability on DISK (rate-limited 1/120s per session):
        // proves the recorder leg sees this route's llm/stream traffic at all.
        const stamp = captureStamp.get(sid) ?? 0;
        if (stamp === 0 || nowTs - stamp > 300000) {
          captureStamp.set(sid, nowTs);
          auditLine({ ts: nowTs, kind: "capture", sid, provider: String(options?.provider), chars, leg: legName });
        }
      }
      records.set(sid, {
        options,
        promptChars: chars,
        lastSeenAt: Date.now(),
        lastBeatAt: 0,
        consecFails: 0,
        lastAuditAt: 0,
      });
    } catch {
      /* fail-open: a recorder miss never touches the stream */
    }
    return next();
  };

  let offRecorder = null;
  if (typeof ctx?.on === "function") {
    offRecorder = ctx.on("llm/stream", (options, next) => recorder("host-plain", options, next));
  }

  // ── the context-filter second leg (the turn-persist / kbs-dsh 2026-11-23
  // verified shape) ──
  // The llm/stream waterfall is dispatched on the LlmRuntime's OWN service
  // ctx (dsh-llm streamWithRegistration: this.ctx.waterfall(this, "llm/
  // stream", ...)). The carrier's context filter DROPS a plain profile-ctx
  // hook for a service-ctx dispatch, so the plain registration above is a
  // no-op unless re-armed on the legs that ARE on the dispatch chain:
  //   1. the host-ctx leg WITH { global: true } (the carrier's documented
  //      escape — a plain profile-ctx hook is filtered out);
  //   2. the per-AGENT actx legs: the agent scope is the dispatch chain's
  //      ANCESTOR layer, so agent-ctx listeners stay live across host-ctx
  //      activation states (the kbs-dsh/turn-persist finding).
  // Both legs share ONE recorder + ONE records Map: a double-delivery is a
  // records.set no-op (idempotent), and the capture log is rate-limited per
  // session either way.
  let offGlobal = null;
  if (typeof ctx?.on === "function") {
    try {
      offGlobal = ctx.on("llm/stream", (options, next) => recorder("host-global", options, next), { global: true });
    } catch {
      /* a global-leg registration miss is fail-open (the other legs may carry it) */
    }
  }
  const agentRecDisposers = new Map();
  const registerAgentRecorder = (agent) => {
    try {
      const actx = agent?.ctx;
      if (!agent || typeof actx?.on !== "function") return;
      if (agentRecDisposers.has(agent)) return;
      const off = actx.on("llm/stream", (options, next) => recorder("actx", options, next));
      if (typeof off === "function") agentRecDisposers.set(agent, off);
    } catch {
      /* an actx leg miss is fail-open (the host legs may already carry it) */
    }
  };
  let offAgentCreated = null;
  if (typeof ctx?.on === "function") {
    offAgentCreated = ctx.on(
      "agent/created",
      (payload) => registerAgentRecorder(payload?.agent ?? payload),
      { global: true },
    );
  }
  // Agents alive BEFORE this apply (resumed web sessions): the same bounded
  // re-registration poller the turn-persist face uses (2s x 30 ticks).
  const seenRecAgents = new Set();
  let recPollTicks = 0;
  const recPoller = setIntervalFn(() => {
    recPollTicks++;
    let list = [];
    try {
      list = ctx.agents?.list?.() ?? [];
    } catch {
      /* the agents service miss is fail-open */
    }
    for (const agent of list) {
      if (!agent || seenRecAgents.has(agent)) continue;
      seenRecAgents.add(agent);
      registerAgentRecorder(agent);
    }
    if (recPollTicks >= 30) clearIntervalFn(recPoller);
  }, 2000);
  if (typeof recPoller?.unref === "function") recPoller.unref();

  // ── the keeper leg: the bounded host-lifetime refresh timer ──
  const audit = (rec, sid, ok, err, ms) => {
    const path = o.auditPath;
    if (!path) return;
    const now = Date.now();
    const firstBeat = rec.lastAuditAt === 0;
    if (!firstBeat && now - rec.lastAuditAt < AUDIT_MIN_GAP_MS && !ok) return;
    rec.lastAuditAt = now;
    try {
      const p = String(path).startsWith("~") ? homedir() + String(path).slice(1) : String(path);
      const line = { ts: now, kind: "beat", sid, ok, promptChars: rec.promptChars, ms, ...(err ? { err } : {}), ...(rec.lastChunkSeq ? { chunks: rec.lastChunkSeq } : {}) };
      appendFileSync(
        p,
        JSON.stringify(line) + "\n",
      );
    } catch {
      /* the audit is best-effort: a miss never surfaces */
    }
  };

  const beat = async (sid, rec) => {
    const t0 = Date.now();
    let ok = false;
    let err = "";
    try {
      if (!ctx?.llm || typeof ctx.llm.stream !== "function") {
        err = "ctx.llm unavailable";
      } else {
        const hbOpts = heartbeatOptions(rec.options, { timeoutMs: o.timeoutMs?.() ?? 30000 });
        const chunkSeq = [];
        for await (const chunk of ctx.llm.stream(hbOpts)) {
          const name = chunk?.type ? String(chunk.type) + (chunk.type === "finish" ? ":" + (chunk.reason?.kind ?? "?") : "") : "?";
          if (chunkSeq.length < 12) chunkSeq.push(name);
          const kind = chunk?.type === "finish" ? chunk?.reason?.kind : undefined;
          if (kind === "stop" || kind === "length") ok = true;
          if (kind === "error" || kind === "aborted") {
            err = String(chunk?.reason?.failure?.code ?? "finish-" + kind);
            break;
          }
        }
        // Success = the refresh request SETTLED without an error/aborted
        // terminal (chunks flowed and the stream ended). The one-shot face
        // does not always emit a finish:stop terminal — a settled stream is
        // what re-touched the provider's cache pages (the 4s round-trip IS
        // the evidence). Zero chunks = the rpm-limiter's stale rule (the
        // request never actually went out) -> failure.
        if (!ok && !err) {
          if (chunkSeq.length > 0) ok = true;
          else err = "zero-chunk stream";
        }
        if (chunkSeq.length) rec.lastChunkSeq = chunkSeq;
      }
      if (ok) {
        rec.consecFails = 0;
      } else {
        rec.consecFails += 1;
        if (rec.consecFails === MAX_CONSEC_FAILS) {
          logger?.debug?.(
            "dsh-supercompress: cache-keeper backing off session " + sid +
              " after " + MAX_CONSEC_FAILS + " consecutive heartbeat failures",
          );
        }
      }
    } catch (e) {
      rec.consecFails += 1;
      err = String(e?.message ?? e);
    }
    audit(rec, sid, ok, err, Date.now() - t0);
  };

  const tick = () => {
    const now = Date.now();
    const enabled = o.enabled?.() !== false;
    const idleTriggerMs = o.idleTriggerMs?.() ?? 45000;
    const refreshPeriodMs = o.refreshPeriodMs?.() ?? 45000;
    const maxIdleMs = o.maxIdleMs?.() ?? 1800000;
    if (!enabled || records.size === 0) return;
    for (const [sid, rec] of records) {
      const idle = now - rec.lastSeenAt;
      if (idle > maxIdleMs) {
        records.delete(sid); // presumed dead: free the record, burn no tokens
        continue;
      }
      if (idle < idleTriggerMs) continue; // not idle enough yet
      if (now - rec.lastBeatAt < refreshPeriodMs) continue; // not due
      if (rec.consecFails >= MAX_CONSEC_FAILS) continue; // backed off
      rec.lastBeatAt = now; // optimistic: the fail-streak governs re-fires
      beat(sid, rec).catch(() => {});
    }
  };

  let tickCount = 0;
  // NOTE (the host-ctx proxy trap, learned the hard way 2026-11-26): the
  // host ctx PROXY THROWS on accessing a non-injected service ("cannot get
  // property X without inject") — `?.` does NOT shield the property access
  // itself, so EVERY ctx.<service> touch must sit inside a try/catch and no
  // bare expression may reference it (the agent poller's ctx.agents read is
  // wrapped accordingly; an unguarded one failed this whole entry's
  // activation).

  const timer = setIntervalFn(() => {
    tickCount++;
    try {
      tick();
      // Boot observability: the first three ticks prove the timer is live
      // (a silent unref'd timer under the host's loop is the #1 suspect).
      if (tickCount <= 3) {
        logger?.debug?.(
          "dsh-supercompress: cache-keeper tick " + tickCount + " (" + records.size + " record(s))",
        );
      }
    } catch {
      /* a tick miss must never take the host down */
    }
  }, TICK_MS);
  if (typeof timer?.unref === "function") timer.unref();

  return {
    dispose() {
      clearIntervalFn(timer);
      clearIntervalFn(recPoller);
      offRecorder?.();
      offGlobal?.();
      offAgentCreated?.();
      for (const off of agentRecDisposers.values()) off?.();
      agentRecDisposers.clear();
      records.clear();
    },
    // Forced-refresh / test face: run one tick NOW.
    kick() {
      tick();
    },
    // Observability: the live record count.
    records() {
      return records.size;
    },
  };
}
