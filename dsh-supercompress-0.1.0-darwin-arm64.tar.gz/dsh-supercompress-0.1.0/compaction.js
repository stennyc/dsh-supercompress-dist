// compaction.js — P5: the compaction face (supercompress pre-compaction behavior
// inside DSH).
//
// NOTE: the mountable engine entry is shell/engine.js (the class the host's
// composition row instantiates — see engine.js/engine-core.js, the P5 engine
// replacement). This file's `supercompressCompactionEngine` factory is the
// DI-client variant: it wraps the same gate-then-delegate subclass with a
// caller-owned shared client (config.client) — used when a host or test
// injects the engine directly instead of mounting the row.
//
// Mechanism (nail-down from dsh-compaction-basic 0.2.2-rc.5):
//   BasicCompactionEngine is the official reference subclass of CompactionEngine.
//   `summarize()` is its SOLE customization hook — the replay/durable-mutation
//   strategy (compaction/start..end lock, shadowed-range replacement,
//   compactCheckpointSource framing, tool-pair edge checks) stays fixed.
//
//   We subclass it and override summarize() to run the supercompress
//   write-before-compress gate FIRST — P0 durable + anchor emission + reversible
//   jsonl booking through the Go daemon — THEN delegate to the official
//   summarizeWithLlm so the provider's warm prefix cache is still reused and
//   the durable checkpoint framing is unchanged. That is exactly the
//   "P0 fsync + readback, anchor only emitted after durable" pre-compaction
//   behavior supercompress guarantees in the DSH host.
//
// Zero deps beyond the dsh install + our shell.

import { SupercompressCompactionEngine as BareCompactionEngine } from "./engine-bare.js";
import { DaemonClient } from "./ipc.js";
import { oneShotText, routeFromAgent, textUserMessage } from "./llm-one-shot.js";
import { classifyTier, parseDigestResponse } from "./tagger.js";
import { resolveHostDir } from "./host-session.js";

/**
 * @param {import("@deepseek-ai/cordis").Context} ctx
 * @param {object} [config]
 * @param {import("./ipc.js").DaemonClient} [config.client] shared daemon client
 * @param {string} [config.storePath]
 * @param {number} [config.capacityTokens]
 */
export function supercompressCompactionEngine(ctx, config = {}) {
  const client = config.client || new DaemonClient({
    storePath: config.storePath,
    daemonPath: config.daemonPath,
    lazyBatchCap: config.lazyBatchCap,
  });

  class SupercompressCompactionEngine extends BareCompactionEngine {
    /**
     * The sole override: run the write-before-compress gate through the Go
     * data plane, then delegate to the inherited 0-LLM summarizer (the bare
     * B-tier engine's ledger + deterministic-fallback core — no host LLM).
     * @param {object} input host SummarizationInput
     * @param {object} agent host Agent
     * @param {AbortSignal} [signal]
     */
    async summarize(input, agent, signal) {
      // 1) write-before-compress gate: persist P0 user turns + emit durable
      //    anchors through the data plane. The summary the host is about to
      //    commit may shadow this range — the P0 rows are already durable on
      //    disk (reversible), so shadowing is safe. `agent` is threaded so the
      //    digest/tiering aux faces can resolve the host LLM route from it.
      await this._p0Gate(input, agent, client, ctx, config);

      // 2) delegate to the INHERITED bare-class summarizer (engine-bare.js's
      //    ledger + deterministic-fallback 0-LLM core) — the sole override is
      //    precisely this gate-then-delegate; the durable-mutation + checkpoint
      //    framing below summarize() is untouched.
      return await super.summarize(input, agent, signal);
    }

    /** Persist the P0 face of the shadowed region; emit anchors. Fail-open. */
    async _p0Gate(input, agent, cli, cctx, cfg) {
      const log = cctx?.logger || { debug() {}, warn() {} };
      let dist;
      try {
        // Distill the current window: runs the P0 gate + P1/P2 flush + anchor
        // emission on the data plane. The summary will shadow the range; the
        // P0 originals are already durable (reversible via the jsonl store).
        dist = await cli.distill(config.capacityTokens ?? 1000);
        log.debug?.(
          `supercompress compaction gate: ${dist.status}, kept_p0=${(dist.kept_p0 || []).length}, anchors=${(dist.anchors || []).length}`,
        );
      } catch (err) {
        // fail-open: a data-plane miss must NOT block the host's own
        // compaction (which is the durable, correct path). Log and delegate.
        log.warn?.(`supercompress compaction gate degraded: ${err.message}`);
        return;
      }
      // Digest face (②): LLM digests for evicted segments still on the stub.
      // aux ≡ host main-model endpoint, zero new provider. Non-critical: a miss
      // leaves the segment pending for regen (idempotent triple), never blocks.
      await this._digestEvicted(agent, cli, cctx, dist);
      // ③ tiering face: source model segments from the host's native session
      // log, ingest them into the store, and run the tagger gate (deterministic
      // floor + LLM, 宁漏勿错 -> P0 on any fail) writing the decided tier back.
      // Fail-open throughout: a miss logs and never blocks the host's own
      // compaction. Non-critical: an undecidable model segment stays on its
      // ingest-time tier (the store keeps it), not a P2 drop.
      await this._tierModelSegments(agent, cli, cctx, cfg);
    }

    /** ② digest face: generate + write back LLM digests for evicted stub segments. */
    async _digestEvicted(agent, cli, cctx, dist) {
      const log = cctx?.logger || { debug() {}, warn() {} };
      const evicted = (dist?.evicted || []).filter(
        (e) => e && e.original_text && String(e.digest_ref || "").startsWith("ready:head"),
      );
      if (evicted.length === 0) return;
      const route = routeFromAgent(agent);
      if (!route || !cctx?.llm) {
        log.warn?.("supercompress digest face: no LLM route; digests stay on head80 stub");
        return;
      }
      for (const seg of evicted) {
        try {
          const text = await oneShotText(cctx, {
            route,
            messages: [textUserMessage(DIGEST_INSTRUCTION + String(seg.original_text).slice(0, 4096))],
            purpose: "digest",
            maxTokens: digestMaxTokens(),
            signal: undefined,
          });
          if (!text) continue; // R3 escape hatch: empty -> head80 placeholder
          // Reference parse_digest_response: strip thinking blocks, extract
          // key_fact/summary, cap lengths; fall back to head80 if unparseable.
          const { keyFact, summary } = parseDigestResponse(text);
          const digest = keyFact || summary
            ? `${keyFact}\n${summary}`.trim()
            : String(seg.original_text).slice(0, 80);
          await cli.digest(seg.segment_id, digest, `llm:${seg.digest_ref || "head80"}`);
          log.debug?.(`supercompress digest: ${seg.segment_id.slice(0, 12)} -> llm (${digest.length}b)`);
        } catch (err) {
          log.warn?.(`supercompress digest degraded for ${seg.segment_id?.slice(0, 12)}: ${err.message}`);
        }
      }
    }

    /**
     * ③ tiering face: source model segments from the host's native session log,
     * ingest them into the store, run the tagger gate (deterministic floor + LLM,
     * 宁漏勿错 -> P0 on any fail), and write the decided tier back via the data
     * plane. Fail-open: every miss logs + keeps the segment on its ingest-time
     * tier; never blocks the host's own compaction.
     *
     * Model segments are sourced from the host zstd V4 log (scheme A: reuse the
     * host's durable session instead of re-ingesting a parallel copy). At the
     * compaction gate the CURRENT session's model output is already flushed, so
     * reading the cwd session dir picks up the real model turns. The ingest
     * face dedupes by content hash, so already-persisted turns are a no-op.
     * @returns {number} number of model segments ingested.
     */
    async _tierModelSegments(agent, cli, cctx, cfg) {
      const log = cctx?.logger || { debug() {}, warn() {} };
      if (cfg?.enableTiering === false) return 0; // opt-out; default on
      // Resolve the host cwd session dir (scheme A-2 backfill source). cwd comes
      // from the session header; dshRoot defaults to ~/.dsh. No cwd -> no native
      // log to read -> 0 (fail-open, the live user path still ran).
      const cwd = cctx?.session?.header?.cwd || cctx?.agent?.session?.header?.cwd;
      if (!cwd) {
        log.debug?.("supercompress tiering face: no session cwd; no host log to source model segments from");
        return 0;
      }
      const dshRoot = cfg?.dshRoot || `${process.env.HOME || "/root"}/.dsh`;
      const dir = resolveHostDir({ dshRoot, cwd });
      if (!dir) {
        log.debug?.("supercompress tiering face: host session dir not found; model segments not sourced");
        return 0;
      }
      const { join: joinP } = await import("node:path");
      const { existsSync } = await import("node:fs");
      let res;
      try {
        // SESSION-SCOPED source (first): this session's own host log file —
        // the cwd-wide dir read floods the gate with OTHER sessions' model
        // text (cross-session contamination + the gate budget burns on
        // foreign files before reaching this session's own turns). The
        // dir-wide scheme A-2 backfill is the FALLBACK only.
        const sessionId = agent?.session?.id || agent?.session?.header?.id || "";
        const ownFile = sessionId ? joinP(dir, sessionId, "session.v4.jsonl.zstd") : "";
        if (ownFile && existsSync(ownFile)) {
          res = await cli.hostModelSegments(ownFile);
        } else {
          res = await cli.hostModelSegmentsDir(dir);
        }
      } catch (err) {
        log.warn?.(`supercompress tiering face degraded (host read): ${err.message}`);
        return 0;
      }
      const segs = res?.segments ?? [];
      if (segs.length === 0) {
        log.debug?.("supercompress tiering face: 0 model segments in host log; nothing to tier");
        return 0;
      }
      // Build the LLM tiering resolver (aux ≡ host main-model endpoint, zero new
      // provider). No route / no ctx.llm -> the resolver is undefined, and the
      // tagger gate falls to the deterministic floor (宁漏勿错: undecided model
      // text -> P0 structural, NEVER a P2 drop).
      const route = routeFromAgent(agent);
      const hasLlm = Boolean(route && cctx?.llm);
      let ingested = 0;
      for (const seg of segs) {
        const text = seg?.text;
        if (!text || !text.trim()) continue;
        let handle;
        try {
          // Ingest the model segment into the store (prov model). The store's
          // content-hash dedup makes already-persisted turns a no-op. Session
          // isolation stamp: this session's id — the tiered model segment is
          // served by THIS session's scoped recall, not a global top-k.
          const got = await cli.ingest(text, {
            // P1 PRE-TAG (the tagger below refines it): P2 rows are NOT
            // appended to the durable jsonl (low-value fold), so a P2
            // pre-tag makes model turns invisible to the summarizer's
            // probe-contains coverage AND to the paged digest — a chronic
            // coverage gap that forces every compact to fall back to the
            // host LLM (the very waste the ledger summarizer exists to
            // remove). P1 = structural retention (on-disk row + head80
            // stub render); the tagger may still demote a true P2 — the
            // demote keeps the row's original_text (SetTier touches only
            // the tier field), so coverage stays intact.
            tier: "P1",
            prov: "model",
            kind: "segment",
            // Session isolation stamp: the Go host reader stamps each segment
            // with ITS OWN session (per-file sessionOfPath). Using it keeps
            // the cwd-dir read (ALL sessions under this cwd) from leaking
            // other sessions' model text into THIS session's ledger/recall.
            // The fallback (no stamp = the live-splice face) = the current
            // agent's session.
            session: seg?.session || agent?.session?.id || agent?.session?.header?.id || "",
          });
          handle = got?.segment_id;
          ingested++;
        } catch (err) {
          log.warn?.(`supercompress tiering face: ingest degraded: ${err.message}`);
          continue;
        }
        if (!handle) continue;
        try {
          // LLM resolver bound to THIS segment's text (the deterministic floor
          // short-circuits monologues / user text before ever calling the LLM).
          const llmResolver = hasLlm ? (r, t) => tierLlmResolver(cctx, r, text) : undefined;
          const d = await classifyTier(text, "model", llmResolver, route);
          await cli.tag(handle, d.tier);
          log.debug?.(
            `supercompress tiering: ${handle.slice(0, 12)} -> ${d.tier} (${d.reason})`,
          );
        } catch (err) {
          // 宁漏勿错: a tiering miss keeps the ingest-time tier (never a drop).
          log.warn?.(`supercompress tiering degraded for ${handle.slice(0, 12)}: ${err.message}`);
        }
      }
      // Durable flush (crash durability): P1/P2 ingests above sit in the
      // daemon's lazy batch until a cap hit or clean exit — a host kill
      // (systemd stop) in between would lose them and regress coverage on
      // every restart. Persist the batch now; fail-open on error.
      if (ingested > 0) {
        try {
          await cli.flush();
        } catch (err) {
          log.warn?.(`supercompress tiering flush degraded: ${err.message}`);
        }
      }
      return ingested;
    }
  }

  // Register the engine as ctx.compaction (replacing the default backend).
  // The Cordis Service DI resolves BasicCompactionEngine's static `inject`
  // (tokenMeter etc.) — we inherit it by subclassing, so `new Engine(ctx, cfg)`
  // gets the same injected deps.
  const engine = new SupercompressCompactionEngine(ctx, config.basicConfig);
  return engine;
}

// ── digest face (aux ≡ main-model-endpoint, zero new provider) ──
// One-shot ctx.llm.stream() call reusing the host's configured endpoint — the
// dsh adaptation of the reference AuxProvider's main_endpoint.call(
// COMPRESSION_TASK, DIGEST_INSTRUCTION + segment). Same strict-JSON contract;
// the balanced-JSON extractor tolerates a code-fenced or prose-wrapped reply.
const DIGEST_INSTRUCTION =
  "Compress the conversation segment below into strict JSON (no code fence, no extra text):\n" +
  '{\"key_fact\": \"<=60 chars: the single most important fact/decision\", ' +
  '\"summary\": \"<=200 chars: 2-4 sentence digest\"}\n' +
  "--- segment ---\n";

function digestMaxTokens() {
  return Number(globalThis.__DSHSC_DIGEST_MAX_TOKENS ?? 400);
}

// ③ tiering face: the LLM resolver the tagger gate consumes. aux ≡ host
// main-model endpoint, zero new provider (same oneShotText path as the digest
// face). It builds the tiering prompt (TIERING_INSTRUCTION + the segment, the
// same contract classifyTier uses internally) and returns the raw LLM reply;
// classifyTier parses it via the shared extractBalancedJson + boundary-bump
// rules. A transient miss throws and the gate lands 宁漏勿错 P0 structural
// (never a P2 drop).
export async function tierLlmResolver(cctx, route, segmentText) {
  const TIERING_INSTRUCTION =
    'Score the relevance of the conversation segment below for long-term recall. ' +
    'Reply strict JSON only (no code fence): {"tier":"P0"|"P1"|"P2","score":<0-10>,' +
    '"settled_signal":<0|1|2>} — P0 = durable decision/fact, P1 = useful context, ' +
    'P2 = transient. --- segment ---\n';
  return await oneShotText(cctx, {
    route,
    messages: [textUserMessage(TIERING_INSTRUCTION + String(segmentText ?? "").slice(0, 4096))],
    purpose: "tier",
    maxTokens: 200,
    signal: undefined,
  });
}


