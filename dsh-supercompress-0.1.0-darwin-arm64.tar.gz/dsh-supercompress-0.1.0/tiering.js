// tiering.js — the model-segment tiering face, extracted so BOTH the (unwired)
// compaction.js path and the MOUNTED engine-core path drive the same logic:
// source model segments from the host's native zstd V4 session log, ingest them
// into the data-plane store (dedup by content hash), run the tagger gate
// (deterministic floor + optional LLM resolver, aux ≡ host main-model
// endpoint, zero new provider), and write the decided tier back. 宁漏勿错: a
// tiering miss keeps the ingest-time tier (never a P2 drop).

import { resolveHostDir, resolveHostSessionBySessionId } from "./host-session.js";
import { oneShotText, routeFromAgent, textUserMessage } from "./llm-one-shot.js";
import { classifyTier } from "./tagger.js";

// The LLM resolver the tagger gate consumes (same oneShotText path as the
// digest face). Builds the tiering prompt + the segment, returns the raw LLM
// reply; classifyTier parses it (extractBalancedJson + boundary-bump rules).
// A transient miss throws and the gate lands 宁漏勿错 P0 structural (never a
// P2 drop).
// `signal` (the 2026-11-23 residual ②): the compact-window bound on ONE
// one-shot call (AbortSignal.timeout raced with the face's total budget via
// AbortSignal.any — the host LLM contract's fail-soft item-6 pattern). A
// timeout/abort makes oneShotText throw -> classifyTier's catch -> the P0
// structural floor (a bounded wait, never an unbounded compact window).
export async function tierLlmResolver(cctx, route, segmentText, signal) {
  const TIERING_INSTRUCTION =
    'Score the relevance of the conversation segment below for long-term recall. ' +
    'Reply strict JSON only (no code fence): {"tier":"P0"|"P1"|"P2","score":<0-10>,' +
    '"settled_signal":<0|1|2>} — P0 = durable decision/fact, P1 = useful context, ' +
    'P2 = transient. --- segment ---\n';
  return await oneShotText(cctx, {
    route,
    messages: [textUserMessage(TIERING_INSTRUCTION + String(segmentText ?? "").slice(0, 4096))],
    purpose: "tier",
    maxTokens: 200,
    ...(signal ? { signal } : {}),
  });
}

/**
 * Drive the model-segment tiering face for one compaction gate.
 * @param {object} o
 * @param {object} o.client data-plane client (`hostModelSegmentsDir` /
 *   `ingest` / `tag`).
 * @param {object} o.ctx service ctx (`.llm`, `.logger`; `.session`/`.agent`
 *   for the cwd when the agent's header is not passed).
 * @param {object} o.agent host Agent (`.session.header.cwd`, `.session.id`).
 * @param {object} o.cfg config (`enableTiering` opt-out, `dshRoot`).
 * @deprecated 2026-11-25 (4-band redesign step 3): the model-segment tiering
 *   LLM face is superseded by the unified 40% pre-digest face (predigest.js /
 *   `enable40PreDigest`). This module stays as the legacy fallback leg
 *   (`enableTiering` still resolves in the `_resolveEnable40PreDigest` chain).
 * @returns {number} the number of model segments ingested.
 */
/**
 * Deterministic first/middle/last spread over `arr` (at most `n` picks) —
 * the F2 verify sample: a few ingested probes whose durable presence proves
 * the whole batch survived (a daemon death loses the batch wholesale, so a
 * clean sample == a clean batch).
 * @param {Array} arr the ingested segment indices (or entries)
 * @param {number} n the sample size (<=1 = just the first entry)
 * @returns {Array} the picked entries (unique, spread across `arr`)
 */
function pickSamples(arr, n) {
  if (n <= 1 || arr.length <= 1) return arr.slice(0, Math.max(1, n));
  if (arr.length <= n) return arr.slice();
  const idx = new Set();
  for (let i = 0; i < n; i++) idx.add(Math.round((i * (arr.length - 1)) / (n - 1)));
  return [...idx];
}

export async function tierModelSegments({ client, ctx, agent, cfg = {} }) {
  const log = ctx?.logger || { debug() {}, warn() {} };
  // The 2026-11-23 P1 observability leg: the face's skip/success reasons land
  // in the ledger audit trail (the SILENT no-op that hid the chronic
  // coverage-gap for a day is now a readable line — no restart needed to SEE
  // which leg died).
  const audit = typeof cfg.audit === "function" ? cfg.audit : null;
  if (cfg.enableTiering === false) return 0; // opt-out; default on
  const cwd =
    agent?.session?.header?.cwd ||
    ctx?.session?.header?.cwd ||
    ctx?.agent?.session?.header?.cwd ||
    "";
  const dshRoot = cfg.dshRoot || `${process.env.HOME || "/root"}/.dsh`;
  // LLM resolver (aux ≡ host main-model endpoint). No route / no ctx.llm ->
  // resolver undefined -> the tagger gate falls to the deterministic floor
  // (宁漏勿错: undecided model text -> P0 structural, NEVER a P2 drop).
  const route = routeFromAgent(agent);
  const hasLlm = Boolean(route && ctx?.llm);
  const session = agent?.session?.id || agent?.session?.header?.id || "";
  // ── SOURCE RESOLUTION (the 2026-11-23 P1 hardening) ──────────────────────
  // Leg 1: this session's OWN host log file, via the header cwd (the scheme
  // A-2 dir + the per-session subdir). Leg 2 (last resort, cwd-INDEPENDENT):
  // the session id is tree-unique across <dshRoot>/sessions/ — the walk
  // finds the own file even when the live session header carries no cwd
  // (the header field is optional on host-created sessions; its absence
  // used to silently zero the whole face -> 0 ingested model segments ->
  // the chronic ledger coverage-gap -> the P2 fallback on EVERY compact).
  let ownFile = "";
  if (cwd) {
    const dir = resolveHostDir({ dshRoot, cwd });
    if (dir && session) {
      const { join: joinP } = await import("node:path");
      ownFile = joinP(dir, session, "session.v4.jsonl.zstd");
    }
  }
  if (!ownFile && session) {
    ownFile = resolveHostSessionBySessionId({ dshRoot, sessionId: session });
  }
  let res;
  try {
    const { existsSync } = await import("node:fs");
    // SESSION-SCOPED source (first): this session's own host log file —
    // the cwd-wide dir read floods the gate with OTHER sessions' model
    // text (cross-session contamination + the gate budget burns on
    // foreign files before reaching this session's own turns). The
    // dir-wide scheme A-2 backfill is the FALLBACK only.
    if (ownFile && existsSync(ownFile)) {
      res = await client.hostModelSegments(ownFile);
    } else if (cwd) {
      const dir = resolveHostDir({ dshRoot, cwd });
      if (dir) {
        res = await client.hostModelSegmentsDir(dir);
      } else {
        res = null;
      }
    }
    if (!res) {
      // No source at all: neither the own-file (cwd or id-walk) nor the
      // dir-wide read resolved. AUDIT the skip (the silent no-op is gone).
      audit?.(
        "tiering-skip",
        JSON.stringify({ reason: "no-source", hasCwd: Boolean(cwd), session: session || "" }),
      );
      log.debug?.("supercompress tiering face: no host log source (cwd header leg + session-id walk both missed); model segments not sourced");
      return 0;
    }
  } catch (err) {
    audit?.("tiering-skip", `host-read: ${err.message}`);
    log.warn?.(`supercompress tiering face degraded (host read): ${err.message}`);
    return 0;
  }
  const segs = res?.segments ?? [];
  if (segs.length === 0) {
    // A source that reads 0 segments is still a DIAGNOSTIC (a torn/torn-tail
    // miss, a session log the reader cannot parse) — audit it so the
    // coverage-gap post-mortem has the row (the silent-0 day is over).
    audit?.("tiering-skip", "0-segments");
    log.debug?.("supercompress tiering face: 0 model segments in host log; nothing to tier");
    return 0;
  }
  let ingested = 0;
  let llmCalls = 0;
  // ── F2 durability knobs (2026-11-24, the 00:06 chronic-gap loss chain) ───
  // The lazy P1/P2 batch is in-memory only until a flush; a daemon death
  // between the ingest burst and the single final flush loses EVERY row
  // (the observed scd ~5-min turnover -> the disk-only covers view -> the
  // chronic coverage-gap). `chunkFlush` bounds the loss to one chunk
  // (default 20; 0 = the legacy single-final-flush); `verifySamples` proves
  // the batch actually survived via the global covers view after the final
  // flush and re-ingests the lost texts (dedup-safe) + re-flushes, bounded
  // 2 retries. Both 0/undefined = the defaults below (ON — the fix must be
  // the behavior, not an opt-in).
  const chunkFlush = Number.isFinite(cfg.chunkFlush) ? cfg.chunkFlush : 20;
  const verifySamples = Number.isFinite(cfg.verifySamples) ? cfg.verifySamples : 5;
  let sinceChunkFlush = 0;
  let flushFailed = false;
  let flushReport = null;
  // The ingested segment INDICES (into `segs`) the verify-retry re-drives on
  // a lost batch (the texts + stamps live in `segs` itself — no duplication).
  const ingestedIdx = [];
  // Per-call timeout + a compact-window TOTAL LLM budget (residual ②,
  // 2026-11-23): the compact-window LLM faces ran with signal:undefined —
  // NO bound, so a degraded endpoint could hold the compact indefinitely
  // (the 118s+ windows). Now each one-shot call races
  // AbortSignal.timeout(llmTimeoutMs) against the face's total budget
  // (llmBudgetMs counted from face start; 0 = no budget) — the earliest
  // wins (the host LLM contract's fail-soft item-6 pattern). A timeout /
  // abort / budget expiry makes the call throw -> classifyTier's catch ->
  // the P0 structural floor (宁漏勿错: a bound never drops data, it only
  // stops the wait). 0/undefined both = the legacy unbounded behavior.
  const llmTimeoutMs = Number.isFinite(cfg.llmTimeoutMs) ? cfg.llmTimeoutMs : 0;
  const llmBudgetMs = Number.isFinite(cfg.llmBudgetMs) ? cfg.llmBudgetMs : 0;
  const budgetCtrl = llmBudgetMs > 0 ? new AbortController() : null;
  if (budgetCtrl) {
    const budgetTimer = setTimeout(() => budgetCtrl.abort(), llmBudgetMs);
    budgetTimer.unref?.(); // the compact must not be kept alive by the budget timer
  }
  let segIdx = 0;
  for (const seg of segs) {
    const text = seg?.text;
    const myIdx = segIdx++;
    if (!text || !text.trim()) continue;
    let handle;
    try {
      const got = await client.ingest(text, {
        // P1 PRE-TAG (the tagger below refines it): P2 rows are NOT
        // appended to the durable jsonl (low-value fold), so a P2
        // pre-tag makes model turns invisible to the ledger
        // summarizer's probe-contains coverage — a chronic gap that
        // forces the compact to fall back to the host LLM. P1 =
        // structural retention; the tagger may still demote a true
        // P2 (the demote keeps the row's original_text, coverage
        // stays intact).
        tier: "P1",
        prov: "model",
        kind: "segment",
        // Session isolation stamp: the Go host reader stamps each
        // segment with ITS OWN session (per-file sessionOfPath) —
        // keeping the fallback dir-wide read from leaking other
        // sessions' model text into THIS session's ledger. The
        // agent session id is the fallback (the live-splice face).
        session: seg?.session || session,
      });
      handle = got?.segment_id;
      ingested++;
      ingestedIdx.push(myIdx);
      if (chunkFlush > 0) sinceChunkFlush++;
    } catch (err) {
      log.warn?.(`supercompress tiering face: ingest degraded: ${err.message}`);
      continue;
    }
    if (!handle) continue;
    try {
      // Per-compact LLM cap (the 2026-11-23 O(N) one-shot burst that
      // dominated the compact windows — 94 calls ≈ 118s on one session):
      // only the FIRST `llmCap` undecided segments get a one-shot LLM call;
      // beyond the cap they fall to the deterministic P0 structural floor
      // (classifyTier with no resolver = floorDecision — 宁漏勿错: a cap
      // never drops data, it only stops the burst). `llmCap` 0/undefined =
      // uncapped (the legacy behavior).
      const llmCap = Number.isFinite(cfg.llmCap) ? cfg.llmCap : 0;
      const canLlm =
        hasLlm && (llmCap === 0 || llmCalls < llmCap) && !budgetCtrl?.signal.aborted;
      if (canLlm) llmCalls++;
      // The one-shot call's bound: the per-call timeout raced with the face's
      // remaining total budget (the earliest abort wins). Neither set ->
      // undefined = the legacy unbounded call.
      let callSignal;
      if (canLlm) {
        const sigs = [];
        if (llmTimeoutMs > 0) sigs.push(AbortSignal.timeout(llmTimeoutMs));
        if (budgetCtrl) sigs.push(budgetCtrl.signal);
        callSignal = sigs.length === 1 ? sigs[0] : sigs.length > 1 ? AbortSignal.any(sigs) : undefined;
      }
      const llmResolver = canLlm ? (r, t) => tierLlmResolver(ctx, r, text, callSignal) : undefined;
      const d = await classifyTier(text, "model", llmResolver, route);
      await client.tag(handle, d.tier);
      log.debug?.(`supercompress tiering: ${handle.slice(0, 12)} -> ${d.tier} (${d.reason})`);
    } catch (err) {
      // 宁漏勿错: a tiering miss keeps the ingest-time tier (never a drop).
      log.warn?.(`supercompress tiering degraded for ${handle.slice(0, 12)}: ${err.message}`);
    }
    // F2 chunk flush: every `chunkFlush` ingests land the in-memory batch
    // NOW — the loss bound on a mid-loop daemon death is ONE chunk (the
    // legacy single-final-flush lost the whole batch: the 00:06 chronic
    // gap). The flush runs AFTER the tag, so the flushed rows carry the
    // LLM-decided tier (a pre-tag flush would leave stale P1 bytes).
    if (chunkFlush > 0 && sinceChunkFlush >= chunkFlush) {
      sinceChunkFlush = 0;
      try {
        await client.flush();
      } catch (err) {
        flushFailed = true;
        log.warn?.(`supercompress tiering chunk-flush degraded: ${err.message}`);
      }
    }
  }
  // Durable flush (crash durability): the P1/P2 ingests above sit in
  // the daemon's lazy batch until cap (256KB) or a clean exit — a
  // systemd SIGKILL of the host would lose them, and the ledger
  // summarizer's coverage check (a FRESH daemon) would miss this
  // session's own model turns -> the chronic LLM-fallback gap. The
  // flush face lands the batch on disk NOW. Fail-open: a flush miss
  // logs; the compact never blocks on durability.
  if (ingested > 0) {
    try {
      flushReport = (await client.flush()) ?? null;
    } catch (err) {
      flushFailed = true;
      log.warn?.(`supercompress tiering flush degraded: ${err.message}`);
    }
    // F2 verify-retry: even a SUCCESSFUL flush can have raced a daemon
    // death (the batch died un-flushed; the next call's crash recovery
    // re-spawns a DISK-ONLY daemon — the 00:06 chain). Sample
    // `verifySamples` ingested probes through the global covers view:
    // a miss means the batch (or its tail) was lost — re-ingest the lost
    // texts (dedup-safe: durable rows no-op) + flush again, bounded 2
    // retries. A residual miss is AUDITED (the chronic gap is no longer
    // silent — the tiering-flush line carries it with the exact count).
    let missing = 0;
    let retries = 0;
    if (verifySamples > 0 && ingestedIdx.length > 0) {
      const sample = pickSamples(ingestedIdx, verifySamples);
      for (let attempt = 0; attempt <= 2; attempt++) {
        const probeOf = (i) => String(segs[i].text).trim().slice(0, 40);
        let cov;
        try {
          cov = await client.covers(session, sample.map(probeOf));
        } catch (err) {
          // The covers face itself is unavailable (daemon down): nothing
          // to verify against — the chunk flushes already bounded the loss.
          log.warn?.(`supercompress tiering verify degraded: ${err.message}`);
          break;
        }
        const missSet = new Set(Array.isArray(cov?.missing) ? cov.missing : []);
        const lost = sample.filter((i) => missSet.has(probeOf(i)));
        missing = lost.length;
        if (lost.length === 0 || attempt === 2) break;
        retries++;
        for (const i of lost) {
          try {
            await client.ingest(segs[i].text, {
              tier: "P1",
              prov: "model",
              kind: "segment",
              session: segs[i]?.session || session,
            });
          } catch (err) {
            log.warn?.(`supercompress tiering verify re-ingest degraded: ${err.message}`);
          }
        }
        try {
          await client.flush();
        } catch (err) {
          flushFailed = true;
          log.warn?.(`supercompress tiering verify flush degraded: ${err.message}`);
        }
      }
    }
    // The success line: the acceptance path reads THIS row to confirm the
    // backfill actually landed (a 0-line tiering face is the chronic gap).
    audit?.("tiering", JSON.stringify({ ingested, llmCalls }));
    // F1 audit face: the flush REPORT (flushed_rows/pending_rows from the
    // Go flush face) + the verify outcome — a daemon death between the
    // ingest burst and the flush now shows up as a greppable line
    // (flushedRows < ingested, or missing > 0 after the retries) instead
    // of vanishing into the log.warn the host never routes to a file.
    audit?.(
      "tiering-flush",
      JSON.stringify({
        ingested,
        chunk: chunkFlush,
        flushedRows: flushReport?.flushed_rows ?? null,
        pendingRows: flushReport?.pending_rows ?? null,
        verifySamples,
        missing,
        retries,
        flushOk: !flushFailed,
      }),
    );
  }
  // ── ⑧ stock wash: demote the re-ingested step-tail B-class rows (the
  // pre-③ stock; the 2026-11-26 audit counted 9 P0/user rows of the host's
  // own "[supercompress recall — step-tail]" injection envelope) to the P2
  // archive tier via the daemon's triple-narrowed face (session + prov +
  // prefix; a scope-less wash is the daemon's wipe red line). The
  // double-check discipline: the dry-run leg FIRST, the execute leg only
  // inside the 50-row safety bound (beyond it: an operator decision, the
  // hold line is AUDITED, not executed). Already-washed sessions re-run a
  // zero-match dry-run per gate (idempotent: a P2 row is excluded by the
  // tier filter). The E-class rows (compact checkpoints / the kb outlines)
  // stay P0 — the session-digest ladder + the ledger covers face depend on
  // them. Fail-open: a wash miss never blocks the gate.
  try {
    const washPrefix = "[supercompress recall";
    const dry = await client.demote({ session, prefix: washPrefix, prov: "user", toTier: "P2", execute: false });
    const n = Number(dry?.count) || 0;
    if (dry?.refused) {
      log.warn?.(`supercompress stock wash refused (the daemon's wipe red line): ${dry?.note}`);
    } else if (n > 0) {
      if (n <= 50) {
        const ex = await client.demote({ session, prefix: washPrefix, prov: "user", toTier: "P2", execute: true });
        audit?.("stock-wash", JSON.stringify({ matched: n, applied: ex?.applied ?? null, skipped: ex?.skipped ?? [] }));
      } else {
        audit?.("stock-wash-hold", JSON.stringify({ matched: n, note: "beyond the 50-row safety bound — dry-run only; the owner executes by hand" }));
      }
    }
  } catch (err) {
    log.warn?.(`supercompress stock wash degraded: ${err.message}`);
  }
  return ingested;
}
