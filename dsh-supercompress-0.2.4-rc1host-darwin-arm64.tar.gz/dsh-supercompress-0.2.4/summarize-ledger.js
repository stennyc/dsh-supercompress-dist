// summarize-ledger.js — the ledger-backed summarizer (the P5 full-replacement
// of the host LLM checkpoint, decision 2026-11-23).
//
// summarizeFromLedger() composes the compaction checkpoint from the
// supercompress ledger INSTEAD of the official ctx.llm 8-section call:
//   1. COVERAGE — every shadowed user/assistant message text must have a
//      durable ledger row (content-hash point check, session-scoped; the
//      daemon's `covers` face). Tool messages are OUT of scope: their
//      pruned head/tail is composed directly from the region (§3), and the
//      ledger never ingests tool results.
//   2. DIGEST — the session's live rows rendered paged by the daemon
//      (`session_digest`: structural P0 first, digest-or-head80 per row).
//   3. REGION extras — the shadowed tool-result text (already pruned to a
//      bounded head+tail by the host pruner) + the latest user intent.
//   4. SHRINK pre-guard — the composed text must be clearly smaller than the
//      shadowed region (the region transaction's authoritative shrink check
//      then still runs; a miss here falls back BEFORE burning the attempt).
//
// Any miss (coverage gap, empty render, daemon down, oversize composition)
// throws LedgerSummarizeMiss — the CALLER (engine-core summarize()) catches
// it and falls back to the official host LLM summarizer (fail-open: the
// worst case is today's behavior, never a broken compact).
//
// The returned SummaryResult is the contract's UNMARKED variant (summarizer
// that does not identify a ctx.llm.stream() call): rawOutput optional, no
// llmStreamCall — the compaction/summary event then carries
// provider "supercompress" / model "ledger" as the durable "who wrote this
// summary" answer.
//
// Zero deps (node stdlib only), per the repo rule.

import { createHash } from "node:crypto";

/** The ledger summarizer could not serve this region (caller falls back). */
export class LedgerSummarizeMiss extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "LedgerSummarizeMiss";
    // Error() only extracts `cause` from options — the P2/P1 routing fields
    // must be mounted explicitly (err.reason / err.uncovered / err.allUncovered).
    this.reason = options?.reason;
    this.uncovered = options?.uncovered;
    this.allUncovered = options?.allUncovered;
    this.digest = options?.digest;
  }
}

/**
 * P1 — the deterministic fallbacks could not shrink the region: the compact
 * is REFUSED (the host's region transaction rolls back, the session
 * continues un-compacted; the next trigger retries). NO host-LLM
 * participation (owner ruling 2026-11-23 decision_1795433034): a compact
 * fires exactly when the window is AT/NEAR the model's context limit — the
 * moment the LLM fallback's own input may exceed that limit and the
 * provider refuses. The only fallback that survives the overflow corner
 * is a deterministic one; when even it cannot shrink, declining the
 * compact is strictly better than an unreliable LLM call.
 */
export class CompactionRefused extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "CompactionRefused";
  }
}

// P2 — the bounded verbatim budget for the deterministic fallback
// composition (per uncovered message: head N + tail N chars; the region's
// text is the source, truncation is the only loss and it is marked).
const FALLBACK_VERBATIM = { head: 400, tail: 400 };

/**
 * Mirror of the Go data plane's SHA256NFC (scdata.go): full 64-hex digest of
 * the NFC-normalized text. VERIFY-1: keep byte-identical with the ingest
 * side — the cross-language parity test pins both.
 */
export function ledgerHash(text) {
  return createHash("sha256").update(String(text).normalize("NFC")).digest("hex");
}

/** One shadowed message's text-block views (the candidate fingerprints). */
function messageBlockViews(msg) {
  const blocks = Array.isArray(msg?.content)
    ? msg.content.map((b) => (b?.type === "text" ? String(b.text ?? "") : "")).filter(Boolean)
    : [];
  return blocks;
}

/**
 * The coverage probe for one message: the first ~40 chars of its LEADING
 * text block after TRIM (the ingest faces' leading-whitespace trims would
 * otherwise offset the contains-match; the interior of the prefix is the
 * raw text — no NFC — so the host log and every ingest face share it). The
 * leading prefix is invariant to the ingest faces' normalizations
 * (block-join, trim, segmentation), unlike a full-text hash. A message
 * with no (or all-whitespace) text block probes as "" (nothing to
 * remember — the caller treats a missing probe as uncovered, and such
 * messages are excluded from the check).
 * @returns {string}
 */
export function probeOf(blocks, size = 40) {
  const first = blocks?.[0];
  if (!first) return "";
  const p = String(first).trim().slice(0, size);
  return p;
}

/** Host-injected boilerplate (re-provisioned by the next assemble; not
 *  session memory, never ingested into the ledger): the knowledge-base
 *  reference preamble, the system-reminder injections, the per-turn
 *  harness context lines ("Time sampled ...", the approval-policy change
 *  notice), the filemem reference lane, and code_map notices. The ledger
 *  only remembers USER INTENT + MODEL OUTPUT; this is the re-provisioned
 *  side. */
const INJECTED_PREFIXES = [
  "## 知识库参考",
  "<system-reminder>",
  "Time sampled",
  "The user changed the approval policy",
  "[filemem 参考道",
  "[code_map]",
  // user-envelope boilerplate: host-injected per-turn reference blocks that
  // the P0 splice ingests WITHOUT (it records the raw user utterance, not
  // the envelope) — skipping them lets the probe fall through to the
  // substantive block (【用户原话】 or the raw text), which the P0 row
  // actually carries.
  "【msg-optimizer",
  "【engineering",
  "[未决草稿]",
  // ── the 2026-11-26 53bf diagnosis (the preingest face's envelope leak):
  // the host checkpoint / recall / goal / error envelopes this face used to
  // ingest RAW as P0/user rows (the 53bf shard's seq 25-32/70-73/83-90
  // noise — a checkpoint preamble even surfaced in a later recall tail as
  // hit #2). Aligned with the live persist face's looksLikeHostNoise
  // (bundle.js) + the Go backfill face's isNoiseLine (hostsession.go):
  // every entry below is host re-provisioned boilerplate, never session
  // memory.
  "This is an automatically generated checkpoint",
  "<compacted-summary>",
  "[supercompress recall",
  "[supercompress compact-ledger",
  "<goal_round>",
  "⚠️ 错误重复",
  "You are repeating the exact same tool call",
  "background job ",
];
export function isInjectedBlock(block) {
  const s = String(block ?? "").trimStart();
  return INJECTED_PREFIXES.some((p) => s.startsWith(p));
}

/**
 * Compose the ledger-backed checkpoint for one shadowed region.
 * @param {object} args
 * @param {object} args.client daemon client (covers/sessionDigest faces)
 * @param {object} args.input host SummarizationInput ({ tools?, messages })
 * @param {object} args.agent host Agent (agent.session.id = the recall scope)
 * @param {AbortSignal} [args.signal]
 * @returns {Promise<object>} the UNMARKED SummaryResult (no llmStreamCall)
 * @throws {LedgerSummarizeMiss} when the region cannot be served from the ledger
 */
export async function summarizeFromLedger({ client, input, agent, signal, ladder }) {
  signal?.throwIfAborted?.();
  // Dual-form session key (id || header.id) — the host's runtime session
  // object carries the id in the header; the single-form `agent.session.id`
  // was undefined on the compact path, so the bind key fell to "" = the
  // GLOBAL empty-stamp pool: cross-session rows mixed into the checkpoint
  // AND every session-stamped rich digest (the B marker rows, applied at
  // replay) excluded from the render — the write side was live but the
  // read side bypassed it (owner ruling 2026-11-26: "写盘 ≠ 用上").
  // Mirrors sessionKeyOf (bundle.js) / tiering.js / compaction.js /
  // recall-inject.js.
  const sessionKey = String(agent?.session?.id || agent?.session?.header?.id || "");

  // ── Split the shadowed messages by face ─────────────────────────────────
  // The system head (messages[0], when present) is outside the shadowed
  // region (the host never compacts the surface node 0 system head) and is
  // excluded from coverage/composition.
  const msgs = [...(input?.messages ?? [])].filter((m) => m?.role !== "system");
  const userOrModel = msgs.filter((m) => m.role === "user" || m.role === "assistant");
  const toolMsgs = msgs.filter((m) => m.role === "tool");

  // ── 1) COVERAGE (session-scoped PREFIX-PROBE contains checks) ──────────
  // A message is covered when SOME durable row for this session carries its
  // leading prefix inside its original_text/digest. The leading prefix is
  // invariant across the ingest faces' normalizations (block-join, trim,
  // segmentation), unlike full-text hashes.
  //
  // PRE-INGEST (fixing the chronic coverage-gap): the host's compact fires
  // in the SAME turn that produces the shadowed region — the pre-step tiering
  // face ingested the PREVIOUS turn's model segments, so the CURRENT
  // region's user + model segments are not yet in the ledger. Before the
  // coverage probe, ingest every shadowed user/model segment (user → P0
  // structural floor; model → P2 durable floor) so their probes carry
  // through. The ingest is idempotent (the ledger's content-hash dedup
  // absorbs re-ingest of an already-durable segment), so a re-compact of
  // the same region is a no-op.
  const views = userOrModel.map((m) => {
    const blocks = messageBlockViews(m);
    const text = blocks.join("\n");
    // ENVELOPE-AWARE probe: host-injected boilerplate (knowledge-base
    // reference blocks, <system-reminder> injections) is re-provisioned by
    // the host's next assemble — it is NOT session memory, and the ledger
    // (which ingests the raw user utterance, not the envelope) never
    // carries it. Probe the first SUBSTANTIVE block; a purely-injected
    // message probes as "" (trivially covered — nothing to remember).
    //
    // ENVELOPE-AWARE INGEST PAYLOAD (the 2026-11-26 preingest leak fix):
    // the same substantive-block filter now governs WHAT the preingest
    // face ingests for a USER view — the 53bf diagnosis caught this face
    // ingesting v.text RAW (the whole envelope: KB reference,
    // system-reminder, Time sampled, the compact-checkpoint preamble, even
    // our own [supercompress recall] tail landed as P0/user rows). A mixed
    // user message (host preamble + the user's actual words) ingests the
    // user's words only; a pure-envelope user message ingests NOTHING
    // (its probe is "" — the coverage check already treats it as
    // trivially covered). Model views keep their raw text: assistant
    // output IS session memory.
    const substantive = m.role === "user" ? blocks.filter((b) => !isInjectedBlock(b)) : blocks;
    const probe = probeOf(substantive);
    return { role: m.role, text, probe, ingest: substantive.join("\n") };
  });
  // PRE-INGEST the shadowed user/model segments into the ledger so the
  // coverage probe below carries through (the chronic gap: the compact's
  // own region was not yet ingested when the compact fired). Idempotent
  // (content-hash dedup); a fail-open miss (daemon down / ingest error)
  // leaves the coverage probe to report the gap and fall back — NEVER blocks
  // the compact (the pre-ingest is a best-effort enhancement, not a gate).
  // ③ observability (the 2026-11-26 coverage-gap triage): per-item
  // resilience (one wedged daemon call no longer aborts the remaining
  // items — the all-or-nothing catch hid the partial state for a day) +
  // the durable audit line (the preingest branch: what landed, what
  // failed, of what) so the NEXT incident reads its own data instead of
  // being diagnosed by static analysis.
  const ingestItem = async (v) => {
    const isUser = v.role === "user";
    // ③ the envelope filter's ingest leg: a USER view ingests its
    // substantive blocks ONLY (v.ingest — the host re-provisions the
    // envelope on the next assemble; the 53bf diagnosis caught this face
    // ingesting v.text RAW and landing the whole envelope as P0/user
    // rows). A pure-envelope user view (v.ingest === "") ingests nothing
    // (its probe is "" — the coverage check treats it as trivially
    // covered). Model views keep the raw text: assistant output IS
    // session memory.
    const payload = isUser ? v.ingest : v.text;
    if (!payload.trim()) return false; // a pure-envelope view: nothing lands
    await client.ingest(payload, {
      tier: isUser ? "P0" : "P2",
      prov: isUser ? "user" : "model",
      kind: "segment",
      structuralP0: isUser,
      session: sessionKey,
    });
    return true;
  };
  let preIngested = 0;
  const preIngestFailedItems = []; // the items that failed the first pass — the
  // retry leg's worklist (the wedge class: a transiently unresponsive daemon
  // recovers on the next call; the idempotent content-hash dedup makes the
  // retry safe: a row that DID land returns its existing duplicate, not an
  // error, so a false-negative first pass self-heals)
  let preIngestFirstError = ""; // the FIRST failure's message (truncated): the
  // wedge-class discriminator (daemon-down vs fused-store vs flock contention)
  for (const v of views) {
    // the daemon's acceptance gate rejects whitespace-only text as
    // `empty_segment` (the 21:15 live evidence: 36/104 permanent rejections,
    // firstError 'empty_segment' — a DURABLE reject, not a transient wedge;
    // the retry pass correctly healed 0). Align the shell skip: never send
    // what the gate will refuse (the covers probe still reports them if
    // their text actually exists on-disk in another form).
    if (!v.text || !v.text.trim()) continue;
    try {
      if (await ingestItem(v)) preIngested++; // false = a pure-envelope view (nothing lands)
    } catch (err) {
      preIngestFailedItems.push(v);
      if (!preIngestFirstError) preIngestFirstError = String(err?.message ?? err).slice(0, 120);
    }
  }
  // the RETRY pass (one attempt, 300ms backoff — the wedge window is the
  // daemon's transient unresponsive stretch; the 15s IPC timeout + the
  // watchdog's F3 re-issue is the recovery path, this is the cheap early
  // one). Only the first-pass failures ride it; a clean first pass costs
  // nothing (the live 20:55 shape: 46 failures would get ONE more chance).
  let preIngestRetried = 0;
  if (preIngestFailedItems.length > 0) {
    await new Promise((r) => setTimeout(r, 300));
    for (const v of preIngestFailedItems) {
      try {
        if (await ingestItem(v)) {
          preIngested++;
          preIngestRetried++;
        }
      } catch {
        // still failed: the coverage probe below reports it (the global
        // contains-probe often lands on previously-ingested duplicates —
        // the 20:55 evidence: 46 fast-fails yet the strict path composed).
      }
    }
  }
  agent?._scAudit?.(agent, "preingest", JSON.stringify({ ingested: preIngested, firstPassFailed: preIngestFailedItems.length, retried: preIngestRetried, stillFailed: preIngestFailedItems.length - preIngestRetried, of: views.length, session: sessionKey || "", firstError: preIngestFirstError }));
  const probes = [...new Set(views.map((v) => v.probe).filter(Boolean))];
  let cov;
  try {
    cov = await client.covers(sessionKey, probes);
  } catch (err) {
    // Daemon down: coverage is UNKNOWN — the P2 composer treats every
    // user/model message as uncovered (the region's verbatim text is the
    // source; nothing is lost, the daemon is not needed).
    throw new LedgerSummarizeMiss(`daemon covers miss: ${err.message}`, {
      cause: err, reason: "daemon-down", allUncovered: views,
    });
  }
  const missingSet = new Set(Array.isArray(cov?.missing) ? cov.missing : (probes.length ? [null] : []));
  // A message whose probe is "" (purely host-injected envelope — no
  // substantive block) is TRIVIALLY COVERED: nothing of it is session
  // memory, and the host re-provisions the boilerplate on the next
  // assemble. Only substantive messages with a MISSING probe are uncovered.
  const uncovered = views.filter((v) => v.probe !== "" && missingSet.has(v.probe));
  if (uncovered.length > 0) {
    throw new LedgerSummarizeMiss(
      `ledger coverage gap: ${uncovered.length}/${views.length} shadowed user/model ` +
        `messages have no ledger row (roles: ${[...new Set(uncovered.map((u) => u.role))].join("/")})`,
      { reason: "coverage-gap", uncovered, allUncovered: views },
    );
  }

  // ── 2) DIGEST (the session's paged ledger, bounded by the region size) ───
  const shadowChars = views.reduce((n, v) => n + v.text.length, 0)
    + toolMsgs.reduce((n, m) => n + (Array.isArray(m.content) ? m.content.length * 64 : 0), 0);
  let digestText;
  if (ladder?.on && typeof client.sessionDigestLadder === "function") {
    // RENDER_FIX_PROPOSAL §2.1: the form-ladder render face (the Python
    // choose_forms semantics — over-budget rows DOWNGRADE to the L0 pointer
    // floor, they are never dropped out of the window; P0 rows keep the
    // push-cap L3 exemption; the anti-drift anchors are L3-exempt). The
    // total cap = min(the owner's renderLadderTotalCap knob, the 0.6×shadow
    // region-scaled floor); the host's shrink check is the final arbiter.
    const totalCap = Math.min(ladder.totalCap ?? 16384, Math.max(2048, Math.floor(Math.max(shadowChars, 0) * 0.6)));
    let sd;
    try {
      sd = await client.sessionDigestLadder(sessionKey, {
        p0CapBytes: ladder.p0Cap ?? 8192,
        indexPoolBytes: ladder.indexPool ?? 4096,
        l3CapBytes: ladder.l3Cap ?? 512,
        totalCapBytes: totalCap,
        // the L1/L0 dual-end 路标 window (owner ruling 2026-11-27); 0/absent
        // = the renderer's 24/24 defaults.
        landmarkHeadChars: ladder.landmarkHead ?? 0,
        landmarkTailChars: ladder.landmarkTail ?? 0,
      });
    } catch (err) {
      throw new LedgerSummarizeMiss(`daemon session_digest_ladder miss: ${err.message}`, {
        cause: err, reason: "daemon-down", allUncovered: views,
      });
    }
    // R1: the stats header line (the Python staged-block header, DSH shape)
    // rides above the paged body — the provider-attribution closure.
    digestText = [String(sd?.header ?? ""), String(sd?.text ?? "")].filter(Boolean).join("\n").trim();
  } else {
    // The legacy paged face (structural-first + head80 + tail-truncate) —
    // the byte-stable default (renderLadder OFF = zero behavior change).
    const budget = Math.max(2048, Math.floor(Math.max(shadowChars, 0) * 0.6));
    let sd;
    try {
      sd = await client.sessionDigest(sessionKey, budget);
    } catch (err) {
      throw new LedgerSummarizeMiss(`daemon session_digest miss: ${err.message}`, {
        cause: err, reason: "daemon-down", allUncovered: views,
      });
    }
    digestText = String(sd?.text ?? "").trim();
  }
  if (!digestText) {
    // No session rows at all (fresh session / store emptied): the P2
    // composer falls back to the full verbatim view.
    throw new LedgerSummarizeMiss("ledger digest rendered empty (no session rows)", {
      reason: "empty-ledger", allUncovered: views,
    });
  }

  // ── 3) CHECKPOINT = the PURE paged ledger digest ─────────────────────────
  // Owner ruling 2026-11-23 (the post-compact window structure):
  //   [system head] + supercompress pages (the c#N paged digest) + the
  //   host's retained recent tail. The checkpoint is the paged digest ITSELF
  // (every c#N row the budget admits — "全部分页页", no page cap): no header
  // line, no "## Tool outputs" section, no "## Latest user intent" section
  // (the latest intent rides in the retained tail; pruned tool content is in
  // the checkpoint only when it is a P0 ledger row — otherwise low-value).
  const composed = digestText;

  // ── 4) SHRINK pre-guard (the region transaction re-checks in tokens) ────
  if (shadowChars > 0 && composed.length >= shadowChars) {
    // P2 cannot help a no-shrink P0 digest (adding verbatim only grows the
    // checkpoint) — the refusal decision is made by the CALLER (P1).
    throw new LedgerSummarizeMiss(
      `composed checkpoint not smaller than the shadowed region ` +
        `(${composed.length} >= ${shadowChars} chars)`,
      { reason: "no-shrink", digest: composed },
    );
  }
  signal?.throwIfAborted?.();

  const blocks = [{ type: "text", text: composed }];
  return {
    summary: blocks,
    // Durable "who wrote this summary": the ledger composition engine.
    provider: "supercompress",
    model: "ledger",
    // Unmarked template output (audit); NO llmStreamCall (no ctx.llm call).
    rawOutput: blocks,
  };
}

/**
 * P2 — the deterministic fallback composition (owner ruling 2026-11-23
 * "兜底不要 DSH 参与"): when the strict ledger path misses, compose the
 * checkpoint from what the host's OWN region already carries — the ledger
 * digest (when one exists) + each UNCOVERED message's verbatim head/tail
 * (bounded, marked) + the pruned tool extras. Zero LLM, zero host
 * template; reuses the Python "[no digest]" bounded-stub philosophy lifted
 * to the checkpoint level. Pure JS (no daemon): the region is the source.
 *
 * @param {object} args
 * @param {object} args.input host SummarizationInput ({ messages })
 * @param {Array<{role:string,text:string}>} [args.uncovered] the uncovered
 *   user/model message views (all of them when the daemon was down / the
 *   ledger empty — the caller decides from the miss reason).
 * @param {string} [args.digest] the ledger digest text when one WAS
 *   rendered (strict path's composed checkpoint body), else "".
 * @returns {{composed:string, shrink:boolean, shadowChars:number}}
 */
/**
 * composeDeterministicFallback — the P2 deterministic self-composition (0 LLM).
 * @param {number} [args.uncoveredCapBytes] the RENDER_FIX_PROPOSAL R4 leg:
 *   when set (the ladder-ON composition), the "## Uncovered messages" section
 *   is capped at this byte total — over-cap entries are dropped OLDEST-first
 *   (the newest uncovered messages carry the "how far it got" signal; the
 *   dropped count rides a deterministic marker line). UNSET = the legacy
 *   unbounded leg (byte-stable default behavior — the cap is a ladder-face
 *   semantic, never the legacy face's).
 */
export function composeDeterministicFallback({ input, uncovered, digest, uncoveredCapBytes }) {
  const msgs = [...(input?.messages ?? [])].filter((m) => m?.role !== "system");
  const userOrModel = msgs.filter((m) => m.role === "user" || m.role === "assistant");
  const toolMsgs = msgs.filter((m) => m.role === "tool");

  const views = userOrModel.map((m) => {
    const blocks = messageBlockViews(m);
    return { role: m.role, text: blocks.join("\n") };
  });
  const unb = (t) => {
    const s = String(t ?? "");
    if (s.length <= FALLBACK_VERBATIM.head + FALLBACK_VERBATIM.tail) return s;
    return s.slice(0, FALLBACK_VERBATIM.head) + "\n…[truncated]…\n" + s.slice(-FALLBACK_VERBATIM.tail);
  };
  const shadowChars = views.reduce((n, v) => n + v.text.length, 0)
    + toolMsgs.reduce((n, m) => n + (Array.isArray(m.content) ? m.content.length * 64 : 0), 0);
  const toolText = toolMsgs
    .map((m) => messageBlockViews(m).join(" "))
    .filter(Boolean)
    .join("\n");
  const lastUser = [...views].reverse().find((v) => v.role === "user")?.text ?? "";
  const unc = uncovered ?? views;
  const sections = [
    "[supercompress ledger fallback checkpoint — deterministic, 0 LLM]",
    String(digest ?? "").trim() || "",
    unc.length
      ? `## Uncovered messages (verbatim ${FALLBACK_VERBATIM.head}+${FALLBACK_VERBATIM.tail} head/tail, marked truncation)\n`
        + unc.map((v) => `[${v.role}] ${unb(v.text)}`).join("\n")
      : "",
    toolText ? `## Tool outputs (trimmed)\n${toolText.slice(0, 8192)}` : "",
    lastUser ? `## Latest user intent\n${lastUser.slice(0, 2048)}` : "",
  ].filter(Boolean);
  let composed = sections.join("\n");
  // R4: the ladder-ON uncovered-leg cap (oldest-first drop, the count marker
  // keeps the 账本不丢 accounting visible — the dropped entries stay durable
  // in the ledger + the region's own history; only the FALLBACK section's
  // byte total is bounded). Legacy (cap unset) = byte-identical.
  if (typeof uncoveredCapBytes === "number" && uncovered && uncovered.length > 0) {
    const sectionHead = `## Uncovered messages (verbatim ${FALLBACK_VERBATIM.head}+${FALLBACK_VERBATIM.tail} head/tail, marked truncation)\n`;
    const entries = unc.map((v) => `[${v.role}] ${unb(v.text)}`);
    const fit = (list) => sectionHead.length + list.join("\n").length;
    if (fit(entries) > uncoveredCapBytes) {
      let kept = entries.length;
      while (kept > 1 && fit(entries.slice(entries.length - kept)) > uncoveredCapBytes) kept--;
      const droppedCount = entries.length - kept;
      const cappedList = droppedCount > 0 ? [`[+${droppedCount} older uncovered entries omitted (ladder cap)]`, ...entries.slice(entries.length - kept)] : entries;
      composed = composed.replace(sectionHead + entries.join("\n"), sectionHead + cappedList.join("\n"));
    }
  }
  return {
    composed,
    shrink: shadowChars <= 0 || composed.length < shadowChars,
    shadowChars,
  };
}
