// turn-persist.js — the per-turn model-record persistence face (the port of
// the Python model-store's `on_turn_complete` ingest hook onto DSH's
// `agent/turn-stopping` serial point).
//
// Python reference (sc/model_store.py, `model_store_enabled: true`): at each
// turn end, every assistant message that passes the deterministic zero-LLM
// gate (length >= model_min_chars OR a meaningful marker hit; the
// reasoning-monologue open is skipped — the R5 repeat-reading fix; dedup by
// content hash) is persisted as a TEMPORARY P0 row (append + fsync + readback,
// the "persist-then-refine" invariant: the on-disk tier is ALWAYS P0, so the
// P1/P2 lazy batch stays effectively empty and model records SURVIVE host
// crashes / restarts).
//
// DSH port (this face): at `agent/turn-stopping`, this turn's
// `assistant/message` events are read off the host's OWN session ledger
// (`payload.agent.session.ownEvents()` — the dispatch carrier's agent, the
// live.settle ordering guarantees the just-finished assistant events are in
// the ledger before this dispatch; the kbs-dsh 2026-11-23 field-verified
// pattern). Survivors of the same gate are ingested as P0/model into the
// session shard (the Go store's append+fsync+readback — the same crash
// durable property; the store's structural content-hash dedup absorbs
// repeats across turns, so no in-process by_hash set is needed). LLM tier
// refinement is deliberately NOT added here: the compact-time tiering face
// owns refinement, and its dedup is idempotent over already-stored rows.
//
// WHY this face exists (the 2026-11-23 session-e2cdfd44 incident): the port
// sourced model records ONLY at compact time, from the host zstd session log
// (the tiering face). A live read that raced the host's in-flight append —
// or a torn tail frame left by a crash before its open-time repair — lost
// the whole read (0 segments ingested); the P1 pre-tag rows that DID land
// sat in the daemon's in-memory lazy batch, which every host restart
// (pkill scd) dropped. Result: the session shard carried 0 model rows -> a
// chronic ledger coverage-gap -> the P2 deterministic fallback on EVERY
// compact -> a degraded post-compact context the user sees as the session
// "sticking". Persisting at turn end restores the reference invariant.
//
// Fail-soft: any miss (no carrier, no ledger, daemon down, ingest error) is
// swallowed — the turn close is NEVER blocked (the host awaits this serial
// dispatch).
import { isReasoningMonologue, modelMarkerHit } from "./tagger.js";

// assistantTextOf — one assistant/message event's durable text: the
// concatenation of its type:"text" blocks (NO separator — byte-identical to
// the Go tiering face's modelSegmentOf, so content hashes align across the
// two faces and the store's structural dedup fires). tool-call / reasoning
// blocks are not durable model prose (skipped, reference model-store gate:
// "text empty strip -> skip (tool-call-only)").
function assistantTextOf(ev) {
  const blocks = ev?.data?.message?.content;
  if (!Array.isArray(blocks)) return "";
  let raw = "";
  for (const b of blocks) if (b?.type === "text" && b.text) raw += b.text;
  return raw;
}

// turnAssistantTexts — THIS turn's assistant texts (a multi-step turn logs
// one assistant/message per step; all carry data.turn === the turn number).
// A missing turn number takes the MOST RECENT assistant message only
// (fail-soft, the kbs-dsh last-message convention — never re-scan the whole
// history when the payload is degraded).
function turnAssistantTexts(events, turnNo) {
  if (turnNo === undefined) {
    for (let i = events.length - 1; i >= 0; i--) {
      if (events[i]?.type === "assistant/message") return [assistantTextOf(events[i])];
    }
    return [];
  }
  const out = [];
  for (const e of events) {
    if (e?.type !== "assistant/message") continue;
    if (e.data?.turn !== turnNo) continue;
    const t = assistantTextOf(e);
    if (t) out.push(t);
  }
  return out;
}

// The per-text gate (the Python model-store ingest_assistant gate, the
// deterministic zero-LLM part):
//   - blank (strip) -> skip (tool-call-only / empty);
//   - marker hit (compaction-summary family) -> PERSIST at any length;
//   - reasoning-monologue open -> SKIP (R5: the monologue must not ride the
//     P0 store — it is the repeat-reading fuel; no data loss: the compact-
//     time tiering face still backfills it P1-pre-tagged -> P2-refined, the
//     durable row keeps coverage);
//   - length >= minChars -> PERSIST; below -> skip.
function gateText(t, minChars) {
  const s = String(t ?? "");
  if (!s.trim()) return false; // blank
  if (modelMarkerHit(s)) return true; // marker: any length
  if (isReasoningMonologue(s)) return false; // R5 monologue skip
  return s.length >= minChars; // the length gate
}

/**
 * makeTurnPersistListener — the `agent/turn-stopping` handler factory.
 * @param {object} deps { client, logger?, enabled?: () => boolean, minChars?: () => number }
 * @returns {(payload: object) => Promise<number>} the persisted segment count.
 */
export function makeTurnPersistListener({ client, logger, enabled, minChars }) {
  // Double-delivery guard (the host-ctx leg + the per-agent ctx leg both
  // fire on some activations): a (session, turn) pair persists at most once.
  const seen = new Set();
  return async (payload) => {
    if (typeof enabled === "function" && enabled() === false) return 0; // live: off
    if (!payload || typeof payload !== "object") return 0;
    const agent = payload.agent;
    const sid = String(agent?.session?.id || agent?.session?.header?.id || ""); // dual-form key (the header carries the id on the runtime session object)
    if (!sid) return 0; // no carrier -> fail-soft
    const turnNo = payload.turn;
    const key = `${sid}:${turnNo ?? "?"}`;
    if (seen.has(key)) return 0;
    seen.add(key);
    if (seen.size > 256) seen.clear();
    const session = agent?.session;
    if (typeof session?.ownEvents !== "function") return 0;
    let events;
    try {
      events = session.ownEvents.call(session) ?? [];
    } catch {
      return 0; // a ledger miss must never block the turn close
    }
    const limit = typeof minChars === "function" ? minChars() : minChars ?? 200;
    const texts = turnAssistantTexts(events, turnNo);
    let n = 0;
    let bypass = 0;
    for (const text of texts) {
      if (!gateText(text, limit)) continue;
      try {
        // P0/model = append + fsync + readback in the Go store (the
        // Python "磁盘 tier 恒 P0" invariant: crash-durable; the lazy batch
        // never carries these rows, so a host restart cannot lose them).
        const got = await client.ingest(String(text), { tier: "P0", prov: "model", kind: "segment", session: sid });
        n++;
        // B-card model bypass dual-write: the main shard row (P0, crash-
        // durable) is the single source of truth; the model sidecar
        // (`<sid>.model.jsonl`, the Go ModelStore) is an INDEPENDENT READ-
        // ONLY RECALL SOURCE that the Go recall face unions into its window
        // and the point-fetch face resolves through (main-first, model-
        // second — Python engine._recall_union_window + point_fetch). The
        // sidecar's disk tier is ALWAYS P0 (the "persist-then-refine"
        // invariant: P1/P2 refinement lives only in-memory and is NEVER
        // re-tiered on replay — a cold restart replays P0 and the shell's
        // tiering face re-refines, the documented trade-off). The dual-
        // write is dedup-safe: the Go ModelStore.Append structural key
        // (content_hash = SHA256NFC) absorbs repeats; the main shard's
        // P0 row is NOT visible to the sidecar (the two stores are
        // disjoint — the cross-store dedup is the caller's job, the
        // ingest gate's marker-hit / monologue-skip / length gate is the
        // zero-LLM face, and the sidecar's replay torn-tail stop is the
        // backstop that a corrupt byte never poisons the live pool).
        const handle = got?.segment_id;
        // B-card model bypass dual-write: the main shard row (P0, crash-
        // durable) is the single source of truth; the model sidecar
        // (`<sid>.model.jsonl`, the Go ModelStore) is an INDEPENDENT READ-
        // ONLY RECALL SOURCE that the Go recall face unions into its window
        // and the point-fetch face resolves through (main-first, model-
        // second — Python engine._recall_union_window + point_fetch). The
        // sidecar's disk tier is ALWAYS P0 (the "persist-then-refine"
        // invariant: P1/P2 refinement lives only in-memory and is NEVER
        // re-tiered on replay — a cold restart replays P0 and the shell's
        // tiering face re-refines, the documented trade-off). The dual-
        // write is dedup-safe: the Go ModelStore.Append structural key
        // (content_hash = SHA256NFC) absorbs repeats; the main shard's
        // P0 row is NOT visible to the sidecar (the two stores are
        // disjoint — the cross-store dedup is the caller's job, the
        // ingest gate's marker-hit / monologue-skip / length gate is the
        // zero-LLM face, and the sidecar's replay torn-tail stop is the
        // backstop that a corrupt byte never poisons the live pool).
        // The client's `ingestModel` is a NEW daemon cmd that appends to
        // the session's ModelStore (the shell's `client` facade is the
        // DaemonClient; `ingestModel` is added alongside `ingest` in
        // ipc.js, driving the daemon's `ingest_model` face — the Go
        // daemon's ModelStore.Append is the P0-floor write, the recall
        // union + point-fetch are the read faces).
        if (handle && typeof client.ingestModel === "function") {
          try {
            await client.ingestModel(String(text), { session: sid });
            bypass++;
          } catch {
            /* fail-open: a sidecar miss must not block the turn close */
          }
        }
      } catch {
        /* fail-open: a daemon miss must not block the turn close */
      }
    }
    if (n > 0) {
      logger?.debug?.(
        `dsh-supercompress: turn ${String(turnNo ?? "?")} persisted ${n} model segment(s) for ${sid.slice(0, 16)}…` +
          (bypass > 0 ? ` (${bypass} bypass)` : ""),
      );
    }
    return n;
  };
}
