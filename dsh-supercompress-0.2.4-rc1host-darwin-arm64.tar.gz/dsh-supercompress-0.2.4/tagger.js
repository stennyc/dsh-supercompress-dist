// tagger.js — ③ tiering face (P0/P1/P2 段分级), ported from sc/tagger.py.
//
// Two layers, exactly like the reference:
//   1) DETERMINISTIC floor (zero LLM, pure rules): user short-instruction P0
//      structural, user long noise/summary markers, model reasoning-monologue -> P2.
//   2) LLM tiering (only for model-sourced text the floor didn't decide): one-shot
//      host ctx.llm call -> machine-parseable JSON { tier, score, settled_signal };
//      boundary ±1 (score 6-8) bumps one tier conservatively; unparseable / unknown
//      tier / transient fail -> conservative P0 structural (never a P2 drop).
//
// The LLM call is injected (classifyTier takes a `llm` resolver) so this module
// stays pure + testable; the compaction gate wires in the host route + ctx.llm.
//
// "宁漏勿错" (better miss than wrong): every fail-safe path lands P0 structural —
// a mis-tiered P2 would silently drop data out of the inject face; P0 only costs
// push-cap pressure, never loss.

export const TIERS = ["P0", "P1", "P2"];
const TIER_INDEX = { P0: 0, P1: 1, P2: 2 };
const USER_STRUCTURAL_LEN = 100;
// system noise markers -> P2; compaction summary marker -> P1 (reference tables).
const P2_MARKERS = [
  "Traceback (most recent call last)",
  "console.log(",
  "console.error(",
  "console.warn(",
];
const P1_MARKERS = ["<compaction-summary>"];
// R4 open-line reasoning-monologue cues (model self-narration, not conclusions).
const REASONING_MONOLOGUE_CUES = [
  "let me",
  "i need to",
  "i'm ",
  "i see",
  "the user",
  "i started",
];
const MONOLOGUE_WINDOW = 60;
// i'm is a monologue cue UNLESS a conclusion word co-occurs in the window.
const IAMS_CONCLUSION_CUES = [
  "sure",
  "confirm",
  "found",
  "discovered",
  "done",
  "complete",
  "verified",
  "finished",
  "resolved",
];

const TIERING_INSTRUCTION =
  'Score the relevance of the conversation segment below for long-term recall. ' +
  'Reply strict JSON only (no code fence): {\"tier\":\"P0\"|\"P1\"|\"P2\",\"score\":<0-10>,' +
  '\"settled_signal\":<0|1|2>} — P0 = durable decision/fact, P1 = useful context, ' +
  'P2 = transient. --- segment ---\n';

// Layer 1: deterministic floor for user-sourced text (single source, shared with
// any future re-tag). Returns { tier, structural }.
export function classifyUser(text) {
  const t = String(text ?? "");
  // Marker checks run BEFORE the structural-length gate: a <100-char user
  // segment that is a compaction-summary / system-noise marker still floors to
  // its marker tier (P1/P2), not blanket P0. (旧顺序下短 marker 被长度闸盖成 P0
  // —— 保守无数据丢失，但违背 marker 意图。)
  if (P2_MARKERS.some((m) => t.includes(m))) return { tier: "P2", structural: false };
  if (P1_MARKERS.some((m) => t.includes(m))) return { tier: "P1", structural: false };
  if (t.length < USER_STRUCTURAL_LEN) return { tier: "P0", structural: true };
  return { tier: "P0", structural: false };
}

// modelMarkerHit — port of the reference `model_marker_hit` (sc/model_store.py):
// a meaningful P1/P2 marker anywhere in the text persists the segment at ANY
// length (the marker gate runs BEFORE the length gate; a compaction-summary /
// system-noise marker is a durable record, not noise).
export function modelMarkerHit(text) {
  const t = String(text ?? "");
  return P1_MARKERS.some((m) => t.includes(m)) || P2_MARKERS.some((m) => t.includes(m));
}

// R4: model open-line reasoning monologue -> P2 (deterministic, pre-LLM short-circuit).
export function isReasoningMonologue(text) {
  const t = String(text ?? "").trim().toLowerCase();
  if (!t) return false;
  const head = t.slice(0, MONOLOGUE_WINDOW);
  for (const cue of REASONING_MONOLOGUE_CUES) {
    if (head.includes(cue)) {
      if (cue === "i'm " && IAMS_CONCLUSION_CUES.some((c) => head.includes(c))) return false;
      return true;
    }
  }
  return false;
}

// Layer 1 only (no LLM): the deterministic classification the reference runs
// before any aux call. model-sourced text not hit by the monologue floor is
// "undecided" (needs the LLM face).
export function deterministicTier(text, provenance) {
  if (provenance === "user") {
    const r = classifyUser(text);
    return { ...r, regime: "normal", decided: true };
  }
  // model: R4 monologue short-circuit -> P2; otherwise undecided (LLM decides).
  if (isReasoningMonologue(text)) {
    return { tier: "P2", structural: false, regime: "normal", decided: true };
  }
  return { decided: false };
}

/**
 * Full tiering: deterministic floor first, then LLM (injected) for undecided
 * model text. The `llm` resolver is `async (route, text) => string` — the
 * compaction gate supplies one bound to the host ctx.llm + route.
 *
 * @returns { tier, structural, regime, reason, settledSignal? }
 *   settledSignal (0/1/2) only on the LLM success path; 0 otherwise.
 */
export async function classifyTier(text, provenance, llm, route) {
  const det = deterministicTier(text, provenance);
  if (det.decided) {
    return {
      tier: det.tier,
      structural: det.structural,
      regime: "normal",
      reason: `deterministic floor: ${det.tier}`,
    };
  }
  // LLM tiering face (model-sourced, not a monologue).
  if (typeof llm !== "function") {
    return floorDecision("no llm resolver -> conservative P0 structural");
  }
  let obj;
  try {
    const raw = await llm(route, TIERING_INSTRUCTION + String(text).slice(0, 4096));
    obj = extractBalancedJson(raw);
  } catch {
    return {
      tier: "P0",
      structural: true,
      regime: "transient_fail",
      reason: "tagging endpoint transient failure -> floor P0",
    };
  }
  if (!obj || typeof obj !== "object") {
    return floorDecision("non-JSON tagging output -> conservative P0");
  }
  let tier = obj.tier ?? "P1";
  if (!(tier in TIER_INDEX)) return floorDecision(`unknown tier ${JSON.stringify(tier)} -> P0`);
  let score;
  try {
    score = Number.parseInt(obj.score, 10);
  } catch {
    score = NaN;
  }
  if (Number.isNaN(score)) score = 5;
  // boundary ±1 (6-8) -> bump one tier conservative (P2->P1, P1->P0; P0 held).
  if (score >= 6 && score <= 8) {
    tier = TIERS[Math.max(0, TIER_INDEX[tier] - 1)];
  }
  return {
    tier,
    structural: false,
    regime: "normal",
    reason: `llm tiering: ${tier} (score ${score})`,
    settledSignal: Number(obj.settled_signal) || 0,
  };
}

function floorDecision(reason) {
  return { tier: "P0", structural: true, regime: "normal", reason };
}

/**
 * parseDigestResponse — port of reference sc/aux_provider.parse_digest_response.
 *
 * The LLM digest reply is strict JSON `{"key_fact","summary"}` but may arrive
 * wrapped in a code fence, surrounded by prose, or (reasoning models) carrying
 * a leading `<thinking>`/`<reasoning>` block that itself contains braces. This
 * parser strips the thinking blocks FIRST (so their braces don't swallow the
 * real JSON), tries the fenced body, then balanced-brace candidates, and caps
 * the captured fields (key_fact ≤80, summary ≤400) so a runaway LLM body never
 * pollutes the durable digest. Empty / unparseable -> ("","") — the caller
 * falls back to the head-80 placeholder (bench empty-response invariant).
 *
 * @returns {{ keyFact: string, summary: string }}
 */
export function parseDigestResponse(text) {
  if (!text || !String(text).trim()) return { keyFact: "", summary: "" };
  let t = String(text).trim();
  // Strip thinking/reasoning blocks BEFORE any JSON extraction: a <thinking>
  // block containing { or } would otherwise swallow the real JSON into one
  // giant invalid string (reference behavior, agnes-2.5-flash reasoning models).
  t = t.replace(/<thinking[^>]*>.*?<\/thinking>/gs, "").trim();
  t = t.replace(/<reasoning[^>]*>.*?<\/reasoning>/gs, "").trim();
  const candidates = [t];
  const fence = t.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fence) candidates.unshift(fence[1].trim());
  const obj = candidates
    .map((c) => {
      try {
        const d = JSON.parse(c);
        return d && typeof d === "object" ? d : null;
      } catch {
        return null;
      }
    })
    .find(Boolean) ?? extractBalancedJson(t);
  if (obj && typeof obj === "object") {
    const kf = String(obj.key_fact ?? "").trim().slice(0, 80);
    const sm = String(obj.summary ?? "").trim().slice(0, 400);
    if (kf || sm) return { keyFact: kf, summary: sm };
  }
  // Pure-text fallback: whole body as summary, head as key_fact (still better
  // than nothing; reference "纯文本回退" 口径).
  return { keyFact: t.slice(0, 60), summary: t.slice(0, 400) };
}

// Shared with the digest face — first brace-balanced JSON object in possibly-fenced prose.
export function extractBalancedJson(s) {
  const str = String(s ?? "");
  let i = 0;
  const n = str.length;
  while (i < n) {
    if (str[i] !== "{") {
      i++;
      continue;
    }
    let depth = 0;
    let inStr = false;
    let esc = false;
    let j = i;
    for (; j < n; j++) {
      const ch = str[j];
      if (inStr) {
        if (esc) esc = false;
        else if (ch === "\\") esc = true;
        else if (ch === '"') inStr = false;
      } else if (ch === '"') inStr = true;
      else if (ch === "{") depth++;
      else if (ch === "}") {
        depth--;
        if (depth === 0) {
          try {
            return JSON.parse(str.slice(i, j + 1));
          } catch {
            i = j + 1;
            break;
          }
        }
      }
    }
    i = j < n ? j + 1 : n;
  }
  return null;
}
