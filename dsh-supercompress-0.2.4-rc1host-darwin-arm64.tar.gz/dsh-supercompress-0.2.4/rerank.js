// rerank.js — the P3 two-step LLM rerank face (ported from Python
// sc/rerank.py `rerank_hits`): on the high-uncertainty recall surface (the R4
// gate fired: weak / empty / explicit-search), the shell reorders the top-k
// candidates through the host's ctx.llm (aux ≡ host main-model endpoint, zero
// new provider), caching the result by (sha256(query), window_version) so a
// repeated gate on an unchanged window is a pure replay (zero LLM call).
//
// fail-safe (Python 原样返回): the LLM is unavailable / times out / the
// response is unparseable -> the INPUT hits are returned UNCHANGED (no
// degrade, no crash); a parse failure is NOT cached (the next gate retries).
// The deterministic core (gate verdict + cache key + R4 drop-on-gate) lives in
// the Go data plane (rerank.go); this module is the LLM-injected step.

import { oneShotText, routeFromAgent, textUserMessage } from "./llm-one-shot.js";
import { safeLlm } from "./llm-guard.js";
import { extractBalancedJson } from "./tagger.js";

// K_RERANK — the number of top-k candidates handed to the LLM reorder step.
export const K_RERANK = 3;

// The in-process rerank cache (key -> the full order: top-k LLM order + the
// remaining original order). A window_version bump invalidates it naturally
// (a new key). Python's `_rerank_cache` is ALSO pure in-memory (a multi-key
// dict, cleared on compact/reopen) — there is NO rerank sidecar in Python;
// only the R1 recall cache has a sidecar (engine.py:910/3046/3143). The
// in-memory face keeps the alignment (the cache is a zero-LLM optimization,
// not a correctness surface — a miss just re-calls the LLM).
const rerankCache = new Map();

export function rerankCacheClear() {
  rerankCache.clear();
}

const RERANK_INSTRUCTION =
  "You are a retrieval reranker. Reorder the candidate memory segments by relevance " +
  'to the query (most relevant first). Use ONLY the given candidate ids, each exactly once. ' +
  'Reply with strict JSON only (no code fence, no extra text): {"order": ["<id>", ...]}\n' +
  "--- query ---\n";

function rerankPrompt(query, hits) {
  const lines = [RERANK_INSTRUCTION, String(query ?? "").trim(), "--- candidates ---"];
  for (let i = 0; i < hits.slice(0, K_RERANK).length; i++) {
    const h = hits[i];
    lines.push(
      `[${i}] id=${h.segment_id} tier=${h.tier} score=${Number(h.score).toFixed(3)}: ` +
        String(h.text ?? "").slice(0, 512),
    );
  }
  return lines.join("\n");
}

// parseRerankResponse — LLM reply -> the reorder id list (a STRICT permutation
// of validIds); null on any fail (the caller returns the input hits unchanged
// = fail-safe). Tolerates a bare {"order":[…]} / a bare array / a code fence /
// the thinking-model index face (["0","2","1"] or [2,0,1] -> candidate order).
export function parseRerankResponse(text, validIds) {
  if (!text || !String(text).trim()) return null;
  let t = String(text).trim();
  t = t.replace(/<thinking[^>]*>[\s\S]*?<\/thinking>/g, "").trim();
  t = t.replace(/<reasoning[^>]*>[\s\S]*?<\/reasoning>/g, "").trim();
  const candidates = [t];
  const fenced = t.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenced) candidates.unshift(fenced[1].trim());
  const balanced = extractBalancedJson(t);
  if (balanced) candidates.splice(1, 0, balanced);
  for (const c of candidates) {
    let d;
    try {
      d = JSON.parse(c);
    } catch {
      continue;
    }
    if (d && typeof d === "object" && !Array.isArray(d) && "order" in d) d = d.order;
    if (Array.isArray(d) && d.every((x) => typeof x === "string")) {
      if (JSON.stringify([...d].sort()) === JSON.stringify([...validIds].sort())) {
        return d; // strict permutation: no missing, no dup, no extra
      }
    }
    // index face: thinking-model replies with candidate indices.
    if (Array.isArray(d) && d.length > 0 && d.length === validIds.length) {
      const idx = [];
      let ok = true;
      for (const x of d) {
        if (typeof x === "number" && Number.isInteger(x) && !(typeof x === "boolean")) idx.push(x);
        else if (typeof x === "string" && /^\d+$/.test(x)) idx.push(Number(x));
        else {
          ok = false;
          break;
        }
      }
      if (ok && JSON.stringify([...idx].sort()) === JSON.stringify(validIds.map((_, i) => i))) {
        return idx.map((i) => validIds[i]);
      }
    }
  }
  return null;
}

/**
 * The LLM two-step reorder (only called when the Go gate fired). Fail-safe:
 * any miss returns the input `hits` unchanged.
 * @returns {Promise<Array>} the (possibly reordered) hits.
 */
export async function rerankRecall({ ctx, agent, query, hits, windowVersion, cacheKey }) {
  if (!Array.isArray(hits) || hits.length === 0) return hits; // nothing to reorder
  const key = `${cacheKey}:${windowVersion ?? 0}`;
  const cached = rerankCache.get(key);
  if (cached) {
    // Cache hit -> pure replay, zero LLM call.
    const byId = new Map(hits.map((h) => [h.segment_id, h]));
    const cachedSet = new Set(cached);
    const out = cached.map((id) => byId.get(id)).filter(Boolean);
    for (const h of hits) if (!cachedSet.has(h.segment_id)) out.push(h);
    return out;
  }
  // Cache miss: the LLM reorder step (aux ≡ host main-model endpoint).
  const route = routeFromAgent(agent);
  if (!route || !safeLlm(ctx)) return hits; // no route / no llm -> fail-safe unchanged
  const topk = hits.slice(0, K_RERANK);
  const validIds = topk.map((h) => h.segment_id);
  let response;
  try {
    response = await oneShotText(ctx, {
      route,
      messages: [textUserMessage(rerankPrompt(query, topk))],
      purpose: "rerank",
      maxTokens: 200,
      signal: undefined,
    });
  } catch {
    return hits; // LLM unavailable / timeout -> fail-safe (unchanged, logged by caller)
  }
  const order = parseRerankResponse(response, validIds);
  if (!order) return hits; // unparseable -> fail-safe (unchanged; NOT cached)
  const byId = new Map(topk.map((h) => [h.segment_id, h]));
  const rest = hits.filter((h) => !validIds.includes(h.segment_id));
  const out = order.map((id) => byId.get(id)).filter(Boolean).concat(rest);
  rerankCache.set(key, [...order, ...rest.map((h) => h.segment_id)]); // cache the full order
  return out;
}
