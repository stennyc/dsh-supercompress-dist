// host-session.js — read the dsh NATIVE session log (zstd V4 jsonl) as the
// user-turn data source (scheme A: reuse the host's durable session instead of
// re-ingesting a parallel copy).
//
// Layout (verified on-disk, dsh 0.2.2-rc.5):
//   <dshRoot>/sessions/<cwdHash>/<sessionId>/session.v4.jsonl.zstd
//   cwdHash = "-" + cwd.replace(/\//g, "-") + "--"     (e.g. /root -> --root--)
// The native log is the host's authoritative append-only event stream; we only
// READ it (zstd-decompress + parse V4 events), never write it (host owns it).
//
// The shell itself NEVER decompresses: all zstd decoding lives in the Go
// daemon (klauspost/compress — multi-frame, the 2026-11-20 design ruling:
// node:zlib's zstdDecompressSync reads only the FIRST frame of the host's
// multi-frame stream — 180B of a whole log — so it was rejected at creation
// and never shipped). This file only RESOLVES the log path/dir and hands it
// to the daemon's read faces (client.hostUserSegments / hostModelSegments).
//
// Extracted user segments are fed to the Go daemon (which owns tier/digest/
// eviction derived state) — the native log has none of those; it's just the
// raw conversation history.

import { existsSync, readdirSync } from "node:fs";
import path from "node:path";

// cwd -> host session-dir name (verified: /root -> "--root--").
export function cwdHash(cwd) {
  return "-" + String(cwd).replace(/\//g, "-") + "--";
}

// Resolve the host session file path for (dshRoot, cwd, sessionId).
export function hostSessionPath(dshRoot, cwd, sessionId) {
  return path.join(dshRoot, "sessions", cwdHash(cwd), sessionId, "session.v4.jsonl.zstd");
}

// NOTE: multi-frame zstd reading is done by the Go daemon (klauspost/compress),
// NOT here — node:zlib.zstdDecompressSync only reads the FIRST frame, and the
// host appends one zstd frame per flush (a session file is a multi-frame stream).
// The shell's job is just to resolve the host session file path and hand it to
// the daemon (client.hostUserSegments). These helpers keep that path logic testable.

// Resolve the host session file for a (dshRoot, cwd, sessionId) triple. Returns
// "" when the file does not exist (caller falls back to its own ingest).
export function resolveHostSession({ dshRoot, cwd, sessionId }) {
  const file = hostSessionPath(dshRoot, cwd, sessionId);
  return existsSync(file) ? file : "";
}

// Resolve the host session DIR for a cwd (scheme A-2 backfill source): the dir
// holding every session file under that cwd (<dshRoot>/sessions/<cwdHash>/).
// Returns "" when the dir does not exist.
export function resolveHostDir({ dshRoot, cwd }) {
  const dir = path.join(dshRoot, "sessions", cwdHash(cwd));
  return existsSync(dir) ? dir : "";
}

// resolveHostSessionBySessionId — the cwd-INDEPENDENT locator (the 2026-11-23
// last-resort leg): the session id is UNIQUE across the whole
// <dshRoot>/sessions/<cwdHash>/<sessionId>/ tree, so a two-level walk (every
// cwdHash dir, then the session dir by id) finds THIS session's own log file
// even when the live session header carries no cwd (the header field is
// optional on host-created sessions — its absence silently zeroed the
// compact-time model backfill for a day: 0 ingested segments -> the chronic
// ledger coverage-gap -> the P2 fallback on EVERY compact).
// A walk miss / unreadable root / empty id returns "" (the caller fails open
// exactly as a missing host file does today).
export function resolveHostSessionBySessionId({ dshRoot, sessionId }) {
  const sid = String(sessionId ?? "");
  if (!sid) return "";
  const root = path.join(dshRoot, "sessions");
  let cwdHashes = [];
  try {
    cwdHashes = readdirSync(root);
  } catch {
    return ""; // no sessions tree (a fresh host root) — nothing to walk
  }
  for (const h of cwdHashes) {
    const file = path.join(root, h, sid, "session.v4.jsonl.zstd");
    if (existsSync(file)) return file;
  }
  return "";
}

// The host surfaces user turns as `agent/inbox/spliced` (target next-turn,
// source.kind === "user"); keep a user/message fallback for direct-emitting
// surfaces. Skip our own recall-injected step-tail (source.dshsc === "recall").
