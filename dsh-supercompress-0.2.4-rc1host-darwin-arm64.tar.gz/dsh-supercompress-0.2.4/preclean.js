// preclean.js — the 40% 预打扫 face (C tier, "打扫房间" five-band waterline).
//
// Deterministic, 0-LLM: two middle-trim passes over the session surface,
// reusing the host's shadow-event + in-place-replacement + old-node-retained
// mechanism (the exact event shape the host's own ToolResultPruner uses, so
// replay stays deterministic and the shadowed original stays durable):
//
//   1. tool-result middle trim — mirrors the host's ToolResultPruner face
//      (head4096 + marker + tail1024, threshold8192 — the host defaults; the
//      same knobs, configurable via the engine row / card). Each pruned node
//      is shadowed by a `compaction/prune` shadow-price event FIRST, then
//      replaced in place (surfaceOp replace on the single node; the old
//      node stays in the log — the host pruner's exact mechanism).
//   2. user long-paste trim — a single user message whose joined text
//      exceeds `userThresholdChars` (default = the pruner threshold 8192)
//      gets its MIDDLE trimmed to head+marker+tail (the user HEAD+TAIL
//      defaults: 4096/1024, same type as the pruner knobs). Only the middle
//      of long pastes/echoes is cut — the user's instruction head and tail
//      survive, and NO semantic de-dup happens (contract: 40% 档 0 LLM,
//      只做确定性裁中间). Host-generated checkpoint / recall / filemem
//      envelopes are NOT trimmed (they are host re-provisioned boilerplate,
//      never session memory — trimming them would corrupt the host's own
//      checkpoint framing).
//
// Prefix-cache red lines honored: both passes only touch [start,end] = a
// single node (surfaceOp replace startSeq=endSeq=seq); the system node0
// bytes, the tools block, and every node BEFORE the touched node are never
// rewritten. The shadow events are appended AFTER the touched node, so the
// durable log order stays append-only.
//
// Zero deps: node stdlib only (the repo rule).

// Host pruner defaults (dsh-compaction-tool-result-pruner 0.2.2-rc.5):
// thresholdChars 8192, headChars 4096, tailChars 1024, one fixed marker.
const TOOL_THRESHOLD_CHARS = 8192;
const TOOL_HEAD_CHARS = 4096;
const TOOL_TAIL_CHARS = 1024;
const TOOL_PRUNE_MARKER = "\n\n[... tool result middle pruned ...]\n\n";

// User long-paste defaults (same knob type as the pruner): threshold =
// the pruner threshold (8192); head/tail = the pruner head/tail (4096/1024).
const USER_THRESHOLD_CHARS = 8192;
const USER_HEAD_CHARS = 4096;
const USER_TAIL_CHARS = 1024;
const USER_PRUNE_MARKER = "\n\n[... user message middle trimmed (supercompress 40% preclean) ...]\n\n";

// Host-generated content that MUST survive byte-for-byte (trimming it would
// break the host's checkpoint framing / recall loop / filemem lane): the
// compacted-summary checkpoint, our own recall tail, the filemem lane, and
// the system-reminder envelopes.
const PROTECTED_PREFIXES = [
  "This is an automatically generated checkpoint",
  "<compacted-summary>",
  "[supercompress recall",
  "[filemem ",
  "<system-reminder>",
];

/** Total text code points across the content's text blocks. */
export function contentChars(content) {
  if (content == null) return 0;
  if (typeof content === "string") return Array.from(content).length;
  if (Array.isArray(content)) {
    let n = 0;
    for (const b of content) if (b?.type === "text") n += Array.from(String(b.text ?? "")).length;
    return n;
  }
  return Array.from(String(content)).length;
}

/**
 * The pruner-shaped middle trim over a message's content blocks: text blocks
 * over budget keep head + marker + tail (code-point slicing, the host
 * pruner's exact semantics so a boundary never splits a surrogate pair);
 * non-text blocks pass through in order.
 * @param {Array|undefined} blocks the message content.
 * @param {object} opts { head, tail, marker } budgets.
 * @returns {Array} the new content (or the original array when nothing was
 *   cut — the caller compares cheaply and skips the append).
 */
export function trimMiddle(blocks, { head, tail, marker }) {
  if (!Array.isArray(blocks)) return blocks;
  const points = blocks.map((b) => {
    const text = b?.type === "text" ? String(b.text ?? "") : "";
    return { b, len: Array.from(text).length, text };
  });
  const total = points.reduce((n, p) => n + p.len, 0);
  // The pruner's skip rule: the post-trim emission (head + marker + tail)
  // must actually SHRINK the node — the host's own pruner returns null
  // (no-op) when there is no removable middle: the head reaches the tail
  // (`total - tail <= head`, i.e. total <= head+tail; an oversized marker
  // budget is a host-side config error that the pruner rejects upfront).
  if (total - tail <= head) return blocks; // nothing to cut (no removable middle)
  const out = [];
  let consumed = 0;
  let markerUsed = false;
  for (const { b, len, text } of points) {
    if (b.type !== "text") {
      out.push(b);
      consumed += len;
      continue;
    }
    const start = consumed;
    const end = start + len;
    const headEnd = Math.min(len, Math.max(0, head - start));
    const tailStart = Math.min(len, Math.max(0, total - tail - start));
    // The marker lands in the FIRST block that crosses the removed span
    // (the host pruner's exact semantics: `blockStart < removedEnd &&
    // blockEnd > removedStart` — a single insertion at the boundary
    // crossing; when head+tail reach INTO the block, the cut keeps the
    // head + marker + tail in that one block).
    const crossesRemoved = start < total - tail && end > head;
    const m = crossesRemoved && !markerUsed ? marker : "";
    if (m) markerUsed = true;
    const cut = text.slice(0, headEnd) + m + text.slice(tailStart);
    out.push({ ...b, text: cut });
    consumed += len;
  }
  return out;
}

/** Whether a user message's text is host-generated boilerplate (never trim). */
export function isProtectedUserText(text) {
  const s = String(text ?? "").trimStart();
  return PROTECTED_PREFIXES.some((p) => s.startsWith(p));
}

/**
 * Pass 1 — the tool-result middle trim (the host pruner face, re-runnable):
 * every current-surface `tool/result` node over the threshold is shadowed
 * (`compaction/prune` shadow-price event, the host's own shadow type) and
 * replaced in place with its head+marker+tail content. The old node stays
 * in the durable log (the shadow event cites it) — replay-deterministic.
 * The system node0 / tools / earlier-prefix bytes are never touched: the
 * replacement is a single-node surfaceOp replace (startSeq=endSeq=seq).
 * @returns {{pruned: number, charsRemoved: number}}
 */
export function precleanToolResults(session, { thresholdChars = TOOL_THRESHOLD_CHARS, headChars = TOOL_HEAD_CHARS, tailChars = TOOL_TAIL_CHARS } = {}) {
  const pruned = [];
  let charsRemoved = 0;
  let prunedCount = 0;
  for (const seq of [...session.surface.nodes]) {
    const event = session.eventAt(seq);
    if (event?.type !== "tool/result") continue;
    const original = session.deriveEventMessage(event);
    if (!original || !Array.isArray(original.content)) continue;
    // A1 uniformity (belt-and-suspenders): the exemption is MARKER-based, not
    // type-based — a tool node carrying the recall marker is exempted the
    // same way (tool nodes are not currently recall-stamped; the guard makes
    // the A1 ruling "dshsc==='recall' 节点一律豁免" hold in BOTH passes).
    if ((original?.source ?? event?.data?.message?.source ?? event?.data?.source)?.dshsc === "recall") continue;
    const charsBefore = contentChars(original.content);
    if (charsBefore <= thresholdChars) continue;
    const content = trimMiddle(original.content, { head: headChars, tail: tailChars, marker: TOOL_PRUNE_MARKER });
    const charsAfter = contentChars(content);
    if (charsAfter >= charsBefore) continue; // no real savings -> skip
    const message = { ...original, content };
    // The host's V4 transcript layout: the `tool/result` event carries its
    // message in `data.message` (the seam's eventDelta reads it); the
    // shadow event cites the original node (the replay-deterministic face).
    session.append("compaction/prune", {
      shadowedRange: { start: seq, end: seq },
      shadowedSeqs: [seq],
      shadowedTokenCount: shadowTokenEstimator?.() ?? 0,
    });
    session.append("tool/result", { ...event.data, message }, {
      surfaceOp: { op: "replace", startSeq: seq, endSeq: seq },
      sourceEventSeqs: [seq],
    });
    pruned.push({ originalSeq: seq, charsBefore, charsAfter });
    prunedCount++;
    charsRemoved += charsBefore - charsAfter;
  }
  return { pruned: prunedCount, prunedDetails: pruned, charsRemoved };
}

// Optional shadow-token estimator (the host pruner prices the shadowed node
// through the injected token meter; a plain-function preclean has no ctx —
// the caller may install one so the shadow event carries a real price).
let shadowTokenEstimator = undefined;
export function setShadowTokenEstimator(fn) {
  shadowTokenEstimator = typeof fn === "function" ? fn : undefined;
}

/**
 * Pass 2 — the user long-paste middle trim: a user/message surface node
 * whose joined text exceeds the threshold is replaced with head+marker+tail
 * (the user's instruction head survives; only the middle of long
 * pastes/echoes is cut). Host-generated checkpoints / recall tails /
 * filemem lanes / system-reminders are PROTECTED (byte-for-byte, red line:
 * 不碰语义, 前缀固定). Same single-node shadow + replace mechanism as pass 1.
 *
 * `sinceSeq` (default 0): process only surface nodes with seq > sinceSeq —
 * the live trim-at-production face (engine-core's `_liveUserTrimPass`) passes
 * the last-processed surface tail so each pre-step pass is O(delta) and
 * already-trimmed history is never re-scanned. The 40% band's user pass
 * (runPreclean) passes nothing -> sinceSeq 0 -> the full scan, byte-identical
 * to the pre-live behavior. Idempotent either way: a trimmed node is
 * head+marker+tail (~5150 chars < the threshold) -> skipped on re-scan.
 * @returns {{trimmed: number, trimmedDetails: Array, charsRemoved: number}}
 */
export function precleanUserMessages(session, { thresholdChars = USER_THRESHOLD_CHARS, headChars = USER_HEAD_CHARS, tailChars = USER_TAIL_CHARS, sinceSeq = 0 } = {}) {
  const trimmed = [];
  let charsRemoved = 0;
  let trimmedCount = 0;
  for (const seq of [...session.surface.nodes]) {
    if (seq <= sinceSeq) continue; // live face: only nodes newer than the last pass
    const event = session.eventAt(seq);
    if (event?.type !== "user/message") continue;
    const original = session.deriveEventMessage(event);
    if (!original || original.role !== "user") continue;
    // A1 (the recall exemption): a node our own recall-inject face injected
    // (source.dshsc === "recall" — recallUserMessage's frozen shape, kind
    // "dshsc-recall" and the legacy "user"-kind belt-and-suspenders variant
    // alike) is EXEMPT from the 40% cleanup uniformly, whatever its content
    // shape: the text heuristic below only knows the known prefixes, and a
    // recall tail that carries a long pasted block would otherwise be trimmed
    // mid-loop, breaking the recall feedback. The marker read is the
    // dual-shape source (nested data.message.source / flat data.source).
    const a1src = original?.source ?? event?.data?.message?.source ?? event?.data?.source;
    if (a1src?.dshsc === "recall") continue;
    const text = original.content
      ? Array.isArray(original.content)
        ? original.content.map((b) => (b?.type === "text" ? String(b.text ?? "") : "")).join("\n")
        : String(original.content)
      : "";
    if (isProtectedUserText(text)) continue; // host boilerplate: never trim
    const charsBefore = Array.from(text).length;
    if (charsBefore <= thresholdChars) continue;
    const content = trimMiddle(
      [{ type: "text", text }],
      { head: headChars, tail: tailChars, marker: USER_PRUNE_MARKER },
    );
    const charsAfter = contentChars(content);
    if (charsAfter >= charsBefore) continue;
    const message = { ...original, content };
    session.append("compaction/prune", {
      shadowedRange: { start: seq, end: seq },
      shadowedSeqs: [seq],
      shadowedTokenCount: shadowTokenEstimator?.() ?? 0,
    });
    session.append("user/message", { ...event.data, message }, {
      surfaceOp: { op: "replace", startSeq: seq, endSeq: seq },
      sourceEventSeqs: [seq],
    });
    trimmed.push({ originalSeq: seq, charsBefore, charsAfter });
    trimmedCount++;
    charsRemoved += charsBefore - charsAfter;
  }
  return { trimmed: trimmedCount, trimmedDetails: trimmed, charsRemoved };
}

/**
 * Run both deterministic passes (tool results first — the cheaper, host-
 * aligned face — then the user long-paste face).
 * @returns {{pruned: number, charsRemoved: number, trimmed: number, userCharsRemoved: number}}
 */
export function runPreclean(session, toolOpts = {}, userOpts = {}) {
  const t = precleanToolResults(session, toolOpts);
  const u = precleanUserMessages(session, userOpts);
  return {
    pruned: t.pruned,
    charsRemoved: t.charsRemoved,
    trimmed: u.trimmed,
    userCharsRemoved: u.charsRemoved,
  };
}
