// engine.js — the mountable compaction-engine entry (the "P5 engine
// replacement", now the REAL mount path).
//
// A composition row points its `name` at this module:
//
//   - id: compaction-basic
//     name: '@stennyc/dsh-supercompress/engine'
//     config:
//       auto: true
//
// The loader imports the row's `name` (a plain module specifier resolved by
// the profile's node_modules) and instantiates it as a CLASS PLUGIN
// (`new plugin(ctx, rowConfig)`). The default export below is the
// SupercompressCompactionEngine subclass:
//   - it registers itself as the `compaction` DI service (inherited
//     CompactionEngine/Service base), exactly where the host's
//     BasicCompactionEngine row used to register it;
//   - with `auto: true` in the row config the inherited constructor
//     registers the engine's own pressure / model-switch / overflow-
//     recovery listeners, so the host's context window is managed for real
//     (before this mount, the row ran with `auto: false` and NOTHING
//     compacted the host context between manual compacts);
//   - the `summarize()` override runs the supercompress P0 write-before-
//     compress gate through the Go data plane before every official
//     summarize + shadow commit (write-before-compress: P0 user turns are
//     durable on disk BEFORE the host shadows them).
//
// Data-plane wiring: the engine shares the module-resident daemon with the
// bundle's own apply() activation — `sharedDaemonClient` keys on the
// resolved (daemon, store, cap) triple, and both resolve to the same paths,
// so there is ONE scd process per store. Env overrides exist for
// non-default profiles: DASHSC_DAEMON / DASHSC_STORE (paths),
// DASHSC_CAPACITY (the data-plane ledger capacity in ABSOLUTE tokens —
// highest-priority override, read live at each distill), DASHSC_CAPACITY_RATIO
// (the ledger capacity as a fraction of the HOST context window, 0<r<=1,
// default 0.5: when DASHSC_CAPACITY is unset the engine resolves the cap
// live per distill as contextWindow × ratio, fail-open to the static
// fallback of 1000 tokens when no host window signal is available — the cap
// is never 0).
//
// Host-base resolution: B-tier removed the basic-inheritance chain — the base
// is no longer the host's concrete `@deepseek-ai/dsh-compaction-basic`
// `BasicCompactionEngine`. host-base.js now hands back the SELF-WRITTEN bare
// `CompactionEngine` subclass (engine-bare.js) that self-writes every basic
// method + the 0-LLM ledger/deterministic-fallback summarizer. The pure-seam
// named exports it consumes (CompactionEngine / ManualCompactionError /
// compactCheckpointSource / toolPairingBalanced*) are resolved through the
// same fallback chain as before:
//   1. DASHSC_HOST_BASE (explicit override: module path or specifier),
//   2. the bare specifier (host runtime that provides it in scope),
//   3. the nvm-style global dsh install (derived from process.execPath:
//      <node root>/lib/node_modules/@deepseek-ai/dsh/node_modules/...).

import { BareCompactionEngineFallback } from "./host-base.js";
import { sharedDaemonClient, getSharedEnableTiering, getSharedUseLedgerSummarizer, getSharedCapacityRatio, getSharedBandThresholds, getSharedLiveUserTrim, getSharedBandGates, getSharedRenderLadder, writeAuditMarker } from "./ipc.js";
import { withSupercompressGate } from "./engine-core.js";

async function loadBase() {
  // B-tier: the "base" is no longer the host's concrete BasicCompactionEngine.
  // It is the self-written bare CompactionEngine subclass (engine-bare.js) that
  // owns every basic method + the 0-LLM ledger/deterministic-fallback
  // summarizer. host-base.js verifies the host seam resolves and hands back
  // that class.
  return await BareCompactionEngineFallback();
}

function gateOptions() {
  const client = sharedDaemonClient({
    ...(process.env.DASHSC_DAEMON ? { daemonPath: process.env.DASHSC_DAEMON } : {}),
    ...(process.env.DASHSC_STORE ? { storePath: process.env.DASHSC_STORE } : {}),
  });
  // A2: DASHSC_CAPACITY_RATIO (0<r<=1, default 0.5): the data-plane ledger
  // capacity as a fraction of the HOST context window. The env is read at
  // module evaluation (the gateOptions shape) and handed to the engine as a
  // module-level default; the engine's live resolution prefers the row
  // config and the bundle-published shared getter, then this env default.
  const ratio = parseFloat(process.env.DASHSC_CAPACITY_RATIO);
  // C tier: the "打扫房间" 5-band waterline thresholds (the volatile card
  // fields; the env DASHSC_T90..T40 are the module-level defaults the engine
  // uses when neither the row config nor the bundle getter is set).
  const parseBand = (env, dft) => {
    const v = parseFloat(env);
    return Number.isFinite(v) && v > 0 && v <= 100 ? v : dft;
  };
  return {
    client,
    // Static FALLBACK capacity only: the engine resolves the live cap as
    // host contextWindow × capacityRatio (A2) unless the env DASHSC_CAPACITY
    // absolute override is set. No module-level default here — the legacy
    // "always 1000" is the fail-open floor inside the engine, not a pin.
    capacityTokens: 1000,
    capacityRatio: ratio > 0 && ratio <= 1 ? ratio : undefined,
    // C tier: the 4 band thresholds (env module defaults; the row config +
    // the bundle-published shared getter override, live on every call).
    t90: parseBand(process.env.DASHSC_T90, 90),
    t70: parseBand(process.env.DASHSC_T70, 70),
    t50: parseBand(process.env.DASHSC_T50, 50),
    t40: parseBand(process.env.DASHSC_T40, 40),
    resolveSharedEnableTiering: getSharedEnableTiering,
    resolveSharedUseLedgerSummarizer: getSharedUseLedgerSummarizer,
    resolveSharedCapacityRatio: getSharedCapacityRatio,
    resolveSharedBandThresholds: getSharedBandThresholds,
    resolveSharedLiveUserTrim: getSharedLiveUserTrim,
    resolveSharedBandGates: getSharedBandGates,
    resolveSharedRenderLadder: getSharedRenderLadder,
  };
}

// Module evaluation happens once per process (the loader caches the module
// namespace); the shared-client registration is idempotent per key, so
// evaluating this module never spawns a daemon by itself (spawn is lazy,
// on first request).
const BareCompactionEngine = await loadBase();
const SupercompressCompactionEngine = withSupercompressGate(BareCompactionEngine, gateOptions());

// Durable module-load marker: proves THIS module was evaluated inside the
// running host process (row activation reached module evaluation AND the
// host-base fallback chain resolved). Without a line in ledger-audit.jsonl
// after a restart, the composition row's module never loaded in the host.
writeAuditMarker("module-loaded", "engine.js module evaluated (host-base resolved + subclass built)");

export default SupercompressCompactionEngine;
export { withSupercompressGate };
