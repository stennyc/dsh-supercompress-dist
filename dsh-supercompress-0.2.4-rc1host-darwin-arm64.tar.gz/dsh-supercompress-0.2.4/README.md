# @stennyc/dsh-supercompress (installed package, 0.1.0)

Reversible session-context compression + on-demand BM25 recall for the DSH
agent. Closed-source distribution: this directory is the installable package
(built JS runtime + the platform-matched `bin/scd` daemon). No source.

## First run

The tarball already carries the right platform's daemon in `bin/scd` (the
path the shell's `ipc.js` resolves first — check with `file bin/scd`).
If you move the directory or run it on another machine:

```sh
node pick-daemon.js      # re-materialize bin/scd from the per-platform releases/ — not needed inside a tarball
```

## Install into your DSH profile

```sh
cd <your-dsh-profile-dir>
pnpm add <this-directory>
# dsh-Go hosts:  dsh plugin --profile <your-app-profile> add <this-directory>
# then reload the plugin (desktop: restart the DSH host process)
```

The `file:` install prints a peer-resolution warning — expected and
harmless (the `@deepseek-ai/*` peers come from the host install).

## Configure

Knobs: `docs/DETAIL.md` (en) / `docs/DETAIL.zh.md` (zh) — the settings card
on the Web GUI's Plugins page edits the volatile fields live (no restart).
The shipped `cordis.patch.yml` mounts the bundle with schema-default
config; restatement semantics = patch replaces whole config, no merge.
`daemonPath` / `storePath` are patch-row fields (defaults `./bin/scd`,
`~/.dsh-supercompress/session.jsonl`).

## Uninstall

`pnpm remove @stennyc/dsh-supercompress` (or `dsh plugin remove` on dsh-Go
hosts) + delete `~/.dsh-supercompress` to also drop the local ledger.

## Provenance & license

`release.json` carries the build provenance (source commit, binary
sha256s, the dist-only modifications). License: proprietary, see
`LICENSE`.
