// ipc.js — thin client over the resident Go daemon (stdio JSON-lines).
//
// One daemon process per plugin instance (resident, not one-spawn-per-call —
// owner preference). Multiple commands in-flight: each request line gets a
// correlated response by `id`. Crash recovery: if the child dies mid-session,
// the next call re-spawns + re-`open`s the store (the disk jsonl is the single
// source of truth, so a fresh daemon replays and continues — no in-memory
// state is load-bearing).
//
// Zero deps (node stdlib only), per the owner's local/self-hosted rule.

import { spawn } from "node:child_process";
import { appendFileSync, readFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// P0 fix (2026-11-23, the same silent-stall class as the kbs/filemem
// 14:09 incident): per-request response timeout + a one-shot re-issue.
// The compaction engine awaits these calls on the host's turn path; a
// daemon that is alive but unresponsive (slow cold start, lost first
// request, stuck store op) used to leave the pending Map entry
// unsettled forever — a dead session with zero trace in the journal.
// The timeout rejects with an IpcTimeoutError and, while the daemon is
// still alive, re-issues the request once. Bounded total wait = 2 x
// the timeout. (This client is the filemem ipc.ts ancestor — same
// shape, same fix.)
const DEFAULT_CALL_TIMEOUT_MS = 15000;

// Cordis config values are taken verbatim from the patch row — a tilde or a
// relative daemonPath is NOT expanded by the host. Resolve them here:
//   storePath "~/x" -> /home/.../x  (os.homedir)
//   daemonPath "./bin/scd" -> <this module's __dirname>/bin/scd
// Absolute values pass through unchanged.
function resolveStorePath(p) {
  if (!p) return path.join(os.homedir(), ".dsh-supercompress", "session.jsonl");
  if (p === "~") return os.homedir();
  if (p.startsWith("~/")) return path.join(os.homedir(), p.slice(2));
  return p;
}
function resolveDaemonPath(p) {
  if (!p) return defaultDaemonPath();
  if (p.startsWith("~/")) return path.join(os.homedir(), p.slice(2));
  if (!path.isAbsolute(p)) return path.join(__dirname, p);
  return p;
}

// Default daemon binary: shell/bin/scd (built by `npm run build:go`), falling
// back to the repo's go/ build if the prebuilt one is missing.
function defaultDaemonPath() {
  const candidates = [
    path.join(__dirname, "bin", "scd"),
    path.join(__dirname, "..", "..", "go", "bin", "scd"),
    process.env.DASHSC_DAEMON,
  ].filter(Boolean);
  for (const c of candidates) {
    try {
      readFileSync(c);
      return c;
    } catch {}
  }
  return candidates[0] || "scd";
}

// ── Shared client registry (one daemon process per store) ──────────────────
// Multiple bundle activations in one dsh process (session resume, plugin
// re-apply, several agents under dsh web) must reuse ONE DaemonClient per
// (daemon, store, cap) triple. Spawning a second daemon for the same store
// is a concurrent-write race on the jsonl (both daemons fsync-read the same
// file) and, with two recall listeners, the source of the double injection.
const sharedClients = new Map(); // key -> { client, refs }

/** Return the module-shared DaemonClient for the given options (creating it
 *  on first use). Use this — not `new DaemonClient` — from plugin apply()
 *  so every activation shares one resident daemon. */
export function sharedDaemonClient(opts = {}) {
  const key = [
    resolveDaemonPath(opts.daemonPath),
    resolveStorePath(opts.storePath),
    String(opts.lazyBatchCap || 256 * 1024),
  ].join("\u0000");
  let entry = sharedClients.get(key);
  if (!entry) {
    entry = {
      client: new DaemonClient({
        daemonPath: opts.daemonPath,
        storePath: opts.storePath,
        lazyBatchCap: opts.lazyBatchCap,
      }),
      refs: 0,
    };
    sharedClients.set(key, entry);
  }
  entry.refs++;
  return entry.client;
}

/** Drop one reference to a shared client (called from apply() teardown).
 *  The daemon stops only when the LAST activation releases it; while other
 *  activations still hold a reference it keeps running. A client that was
 *  never shared (DI `config.client`) is stopped outright. */
export function releaseSharedClient(client) {
  for (const [key, entry] of sharedClients) {
    if (entry.client === client) {
      entry.refs = Math.max(0, entry.refs - 1);
      if (entry.refs === 0) {
        client.stop();
        sharedClients.delete(key);
      }
      return;
    }
  }
  // Not shared (a DI-provided client): stop it directly.
  client.stop();
}

// ── Shared capacity-ratio fraction (bundle config -> engine, one process) ──
// A2: the data-plane ledger capacity budget follows the HOST context window
// (capacity = contextWindow × capacityRatio, live-read at each distill). The
// bundle publishes its `capacityRatio` here (`.volatile()` dsh-settings: the
// engine row re-reads it on every distill, no restart on edit); the mounted
// engine (a separate cordis activation) reads it through the shared getter.
// Resolution inside the engine: row config > this shared getter > the
// env-derived module default. 0 / out-of-range normalizes to unset (the
// engine then falls back to the static capacityTokens — fail-open).
let sharedCapacityRatioGetter; // () => number|undefined

/** Publish a LIVE getter for the capacity-ratio fraction (the volatile path). */
export function setSharedCapacityRatioGetter(fn) {
  sharedCapacityRatioGetter = typeof fn === "function" ? fn : undefined;
}

/** Read the current capacity-ratio fraction (undefined when unset). */
export function getSharedCapacityRatio() {
  const v = sharedCapacityRatioGetter ? sharedCapacityRatioGetter() : undefined;
  return typeof v === "number" && v > 0 && v <= 1 ? v : undefined;
}

/** Release the capacity-ratio getter on activation teardown (the single-
 *  activation host re-publishes it on the next apply). */
export function clearSharedCapacityRatioGetter() {
  sharedCapacityRatioGetter = undefined;
}

// ── Live getter for the tiering face (the volatile `enableTiering` knob) ──
// The bundle field is `.volatile()` (dsh-settings): apply() publishes a LIVE
// getter (reads the current value on each call, no restart on edit). The
// tiering face runs when the value !== false (default ON, opt-out semantics),
// so an unset getter resolves to true (drives the face).
let sharedEnableTieringGetter; // () => boolean

/** Publish a LIVE getter for the tiering on/off state (the volatile path). */
export function setSharedEnableTieringGetter(fn) {
  sharedEnableTieringGetter = typeof fn === "function" ? fn : undefined;
}

/** Publish a CONSTANT tiering state (true/false); wraps it as a live getter. */
export function setSharedEnableTiering(v) {
  sharedEnableTieringGetter = () => v !== false;
}

/** Read the current tiering state (default ON: true when unset). */
export function getSharedEnableTiering() {
  const v = sharedEnableTieringGetter ? sharedEnableTieringGetter() : undefined;
  return v !== false;
}

// Release the shared getters on activation teardown (the single-activation
// host re-publishes them on the next apply; a stale getter from a previous
// activation in the same process must not leak into the next one).
export function clearSharedEnableTieringGetter() {
  sharedEnableTieringGetter = undefined;
}

// ── Live getter for the ledger-backed summarizer face (volatile) ────────────
// The bundle field `useLedgerSummarizer` is `.volatile()` (dsh-settings):
// apply() publishes a LIVE getter (reads the current value on each call, no
// restart on edit). Default OFF (the host LLM summarizer stays the path);
// when on, the MOUNTED engine composes the checkpoint from the ledger
// (0 LLM calls in the compact window) and falls back to the host LLM path on
// a coverage/shrink miss.
let sharedUseLedgerSummarizerGetter; // () => boolean
/** Publish a LIVE getter for the ledger-summarizer on/off state. */
export function setSharedUseLedgerSummarizerGetter(fn) {
  sharedUseLedgerSummarizerGetter = typeof fn === "function" ? fn : undefined;
}
/** Read the current state (default OFF: false when unset). */
export function getSharedUseLedgerSummarizer() {
  const v = sharedUseLedgerSummarizerGetter ? sharedUseLedgerSummarizerGetter() : undefined;
  return v === true;
}
export function clearSharedUseLedgerSummarizerGetter() {
  sharedUseLedgerSummarizerGetter = undefined;
}

// ── Shared form-ladder render face (bundle config -> engine, one process) ──
// The RENDER_FIX_PROPOSAL §2.1 knob set (the owner-tunable pools): the
// bundle publishes ONE live getter that yields { on, p0Cap, indexPool,
// l3Cap, totalCap }; the mounted engine re-reads it on every summarize()
// call (the exact volatile-getter pattern the tiering / ledger knobs use).
// Default OFF = the legacy session_digest face (zero behavior change).
let sharedRenderLadderGetter = undefined;
export function setSharedRenderLadderGetter(fn) {
  sharedRenderLadderGetter = typeof fn === "function" ? fn : undefined;
}
/** Read the current state (default OFF: { on: false } when unset). */
export function getSharedRenderLadder() {
  const v = sharedRenderLadderGetter ? sharedRenderLadderGetter() : undefined;
  return v && typeof v === "object" ? v : { on: false };
}
export function clearSharedRenderLadderGetter() {
  sharedRenderLadderGetter = undefined;
}

// ── Shared C-band waterline thresholds (bundle config -> engine, one process)
// The "打扫房间" five-band waterline (C tier): the 4 thresholds are the
// bundle's `.volatile()` card fields, published here as ONE live getter that
// yields the resolved threshold object. The mounted engine (a separate
// cordis activation) re-reads it on every compactIfNeeded call — the exact
// pattern the capacity-ratio / tiering knobs use.
//
// Each threshold resolves row config > this shared getter > the env-derived
// module default (90/70/50/40, the contract v4 defaults). 0 / out-of-range
// normalizes to unset (the engine falls back to its module default).
let sharedBandThresholdsGetter; // () => {t90?:number,t70?:number,t50?:number,t40?:number}

/** Publish a LIVE getter for the four band thresholds (the volatile path). */
export function setSharedBandThresholdsGetter(fn) {
  sharedBandThresholdsGetter = typeof fn === "function" ? fn : undefined;
}

/** Read the current band thresholds ({ } when unset; the engine's module
 *  defaults (90/70/50/40) fill in the missing keys). */
export function getSharedBandThresholds() {
  const v = sharedBandThresholdsGetter ? sharedBandThresholdsGetter() : undefined;
  if (typeof v !== "object" || v === null || Array.isArray(v)) return {};
  const out = {};
  for (const k of ["t90", "t70", "t50", "t40"]) {
    const n = v[k];
    if (typeof n === "number" && Number.isFinite(n) && n > 0 && n <= 100) out[k] = n;
  }
  return out;
}

/** Release the band-thresholds getter on activation teardown (the
 *  single-activation host re-publishes it on the next apply). */
export function clearSharedBandThresholdsGetter() {
  sharedBandThresholdsGetter = undefined;
}

// The live user-paste trim-at-production face on/off (the settings card's
// `.volatile()` toggle; the mounted engine's pre-step live pass re-reads it
// every tick — the card toggle applies WITHOUT a restart). Precedence: the
// card value (boolean) OVERRIDES the engine row config's `liveUserTrim`;
// UNSET (undefined) lets the row config speak — deliberately no default
// here (a default would shadow the row value).
let sharedLiveUserTrimGetter; // () => boolean|undefined

/** Publish a LIVE getter for the live user-trim face (the volatile path). */
export function setSharedLiveUserTrimGetter(fn) {
  sharedLiveUserTrimGetter = typeof fn === "function" ? fn : undefined;
}

/** Read the current card value (undefined = the engine row config speaks). */
export function getSharedLiveUserTrim() {
  const v = sharedLiveUserTrimGetter ? sharedLiveUserTrimGetter() : undefined;
  return typeof v === "boolean" ? v : undefined;
}

/** Release the live user-trim getter on activation teardown. */
export function clearSharedLiveUserTrimGetter() {
  sharedLiveUserTrimGetter = undefined;
}

// ── The C-tier band GATES shared channel (card refactor 2026-11-26) ───────
// The bundle row's four per-band enable switches (enableBand90/70/50/40, all
// .volatile(), NO schema defaults — an untouched card field yields undefined)
// publish ONE live getter here; the mounted engine's band switch re-reads it
// on every compactIfNeeded call, so a card toggle applies without a restart.
// UNSET entries (undefined) = the band stays ENABLED (the module default);
// only an explicit false disables a band (fail-open, the thresholds' own
// "a broken card value must never disable a band" rule).
let sharedBandGatesGetter;

/** Publish the live band-gates getter (bundle apply; fn() -> {b90?, b70?, b50?, b40?}). */
export function setSharedBandGatesGetter(fn) {
  sharedBandGatesGetter = typeof fn === "function" ? fn : undefined;
}

/** Read the current card band-gate values (null = no live getter / all enabled). */
export function getSharedBandGates() {
  const v = sharedBandGatesGetter ? sharedBandGatesGetter() : undefined;
  return v ?? null;
}

/** Clear the published getter (bundle teardown). */
export function clearSharedBandGatesGetter() {
  sharedBandGatesGetter = undefined;
}

// ── Durable audit marker (the logger-independent trail) ─────────────────────
// The 16:51 LLM-path compact left ZERO observable trail (the host logger
// routing of a mounted plugin is deployment-dependent). These one-line JSONL
// markers land in <storeDir>/ledger-audit.jsonl — the SAME file
// engine-core's branch audit writes — and are best-effort: they never throw,
// and they use the same store-path default as sharedDaemonClient, so a
// marker from a module that was never wired to a client still lands next to
// the real store.
/**
 * Append one audit marker line (branch/reason) to the ledger-audit.jsonl
 * beside the resolved store. Fire-and-forget safe: every failure is
 * swallowed (a marker must never break module load or a compact).
 * @param {string} branch marker branch tag (e.g. "module-loaded")
 * @param {string} [reason] human-readable context
 */
export function writeAuditMarker(branch, reason = "") {
  try {
    const p = path.join(
      path.dirname(resolveStorePath(process.env.DASHSC_STORE)),
      "ledger-audit.jsonl",
    );
    appendFileSync(p, JSON.stringify({ ts: Date.now(), pid: process.pid, branch, reason }) + "\n");
  } catch {
    /* best-effort: markers are observability, never a failure path */
  }
}

export class DaemonClient {
  /**
   * @param {object} [opts]
   * @param {string} [opts.daemonPath]
   * @param {string} [opts.storePath] default jsonl location
   * @param {number} [opts.lazyBatchCap]
   */
  constructor(opts = {}) {
    // Resolve config-supplied paths (tilde / CWD-relative) against this module;
    // fall back to sensible absolute defaults when unset.
    this.daemonPath = resolveDaemonPath(opts.daemonPath);
    this.storePath = resolveStorePath(opts.storePath);
    this.lazyBatchCap = opts.lazyBatchCap || 256 * 1024;
    this.child = null;
    this.stdout = null;
    this.buf = "";
    this.pending = new Map(); // id -> {resolve, reject}
    this.nextId = 1;
    this.opened = false;
    this.exited = null;
    this.callTimeoutMs = opts.callTimeoutMs ?? DEFAULT_CALL_TIMEOUT_MS;
    this.retryOnTimeout = opts.retryOnTimeout !== false;
    // F5 (2026-11-24): the unresponsive-daemon watchdog. A WEDGED daemon
    // (alive, request loop parked — e.g. the tag/digest re-entrant-lock
    // abort left the pipe unread) times out face after face forever: every
    // compact degrades to the P2 fallback and the ledger-strict P1/P2
    // digest never fires. Consecutive final timeouts (each already
    // retry-once + 15s + caller fail-open) trip the kill; the next call's
    // ensure() re-spawns + re-opens from the disk jsonl (the single source
    // of truth), re-issuing the faces. 0 = off (the legacy behavior:
    // a wedged daemon persists until the whole host restarts).
    this.consecTimeouts = 0;
    this.watchdogAfter = Number.isInteger(opts.watchdogAfter) ? opts.watchdogAfter : 3;
    this.log = opts.log ?? null;
  }

  ensure() {
    if (this.child && this.child.exitCode === null) return; // alive
    this._spawn();
  }

  _spawn() {
    this.child = spawn(this.daemonPath, [], { stdio: ["pipe", "pipe", "inherit"] });
    this.stdout = this.child.stdout;
    this.buf = "";
    this.pending = new Map();
    this.opened = false;
    this.stdout.on("data", (chunk) => this._onData(chunk));
    // Instance-identity guards (the 2026-11-24 watchdog race): these handlers
    // belong to THIS child only. A stale 'exit'/'error' from an OLD child
    // (e.g. the watchdog just killed child N, the next call spawned child
    // N+1, and N's exit event lands AFTERWARD) must not clobber the NEW
    // child — without the guard it nulled the fresh child and rejected the
    // in-flight call with "daemon exited (null)".
    const child = this.child;
    child.on("exit", (code) => {
      if (this.child !== child) return; // the client has moved on; the new child owns the state
      this._failChild(new Error(`daemon exited (${code})`), code);
    });
    child.on("error", (err) => {
      if (this.child !== child) return;
      this._failChild(err);
    });
    // A dying daemon's stdin PIPEs: an unguarded 'error' there surfaced as an
    // UNCAUGHT exception that took the whole HOST process down (the 2026-11-23
    // crash wave: "fatal uncaught exception: write EPIPE" at _call's
    // stdin.write, systemd restart-loop). Guard it: fail the in-flight calls,
    // and the next ensure() re-spawns + re-opens the store (the disk jsonl is
    // the single source of truth, so re-spawn is always safe).
    child.stdin.on("error", (err) => {
      if (this.child !== child) return; // the exit path already moved on
      this._failChild(new Error(`daemon stdin broken: ${err.message}`));
    });
  }

  /** Fail the child's state once (exit / spawn-error / stdin-error paths). */
  _failChild(err, exitCode) {
    if (this.child === null && this.pending.size === 0) return; // already failed
    if (exitCode !== undefined) this.exited = exitCode;
    this.child = null;
    this.opened = false; // the next open() re-opens the store on the fresh child
    for (const [, p] of this.pending) p.reject(err);
    this.pending.clear();
  }

  /** F5: kill a wedged (alive-but-unresponsive) child so the next call's
   * ensure() re-spawns + re-opens from the disk jsonl. The in-memory lazy
   * P1/P2 batch dies with the child (documented: a wedged daemon's batch
   * is unrecoverable — the disk rows already flushed are the source of
   * truth, and the next compact's tiering re-ingests what is missing,
   * dedup-safe). A SIGTERM leaves the F3 scd-crash.jsonl marker
   * (cause=signal:terminated + pending_rows) for the post-mortem. */
  _killWedged() {
    const n = this.consecTimeouts;
    this.consecTimeouts = 0;
    const c = this.child;
    if (!c || c.exitCode !== null) return; // already dead: ensure() handles it
    writeAuditMarker(
      "watchdog-kill",
      JSON.stringify({ consecTimeouts: n, callTimeoutMs: this.callTimeoutMs }),
    );
    this.log?.warn?.(`supercompress scd watchdog: ${n} consecutive response timeouts against a live daemon — killing the wedged child, the next face re-spawns + re-opens from disk`);
    try {
      c.kill();
    } catch {
      /* a kill failure just means the exit path below still cleans up */
    }
    this._failChild(new Error(`daemon wedged: killed by the unresponsive-watchdog after ${n} consecutive timeouts`));
  }

  _onData(chunk) {
    this.buf += chunk.toString("utf8");
    let idx;
    while ((idx = this.buf.indexOf("\n")) >= 0) {
      const line = this.buf.slice(0, idx);
      this.buf = this.buf.slice(idx + 1);
      if (!line.trim()) continue;
      let resp;
      try {
        resp = JSON.parse(line);
      } catch {
        continue;
      }
      const p = this.pending.get(resp.id);
      if (!p) continue;
      this.pending.delete(resp.id);
      // F5: ANY answered request proves the request loop is live — reset
      // the consecutive-timeout counter (only un-answered faces count).
      this.consecTimeouts = 0;
      if (resp.ok) p.resolve(resp.data ?? {});
      else p.reject(new Error(resp.error || "daemon error"));
    }
  }

  /** Open (or re-open) the store. Idempotent; re-spawn replays the jsonl. */
  async open() {
    this.ensure();
    if (this.opened) return;
    await this._call({
      cmd: "open",
      payload: { path: this.storePath, cap: this.lazyBatchCap },
    });
    this.opened = true;
  }

  async ingest(text, { tier = "P2", prov = "model", kind = "segment", structuralP0 = false, session = "" } = {}) {
    await this.open();
    return this._call({
      cmd: "ingest",
      payload: { text, tier, prov, kind, structural_p0: structuralP0, session },
    });
  }

  /** B-card model bypass dual-write: append one P0-floor model row to the
   *  session's model sidecar (`<sid>.model.jsonl`, the Go ModelStore).
   *  The main shard row (the `ingest` cmd's P0 append) is the single
   *  source of truth; the sidecar is an INDEPENDENT READ-ONLY RECALL
   *  SOURCE that the recall face unions into its window and the point-
   *  fetch face resolves through (main-first, model-second — Python
   *  engine._recall_union_window + point_fetch). The sidecar's disk tier
   *  is ALWAYS P0 (the "persist-then-refine" invariant: P1/P2 refinement
   *  lives only in-memory and is NEVER re-tiered on replay — a cold
   *  restart replays P0 and the shell's tiering face re-refines, the
   *  documented trade-off). Fail-open: a missing sidecar / fused pool /
   *  write error -> the row is reported, not fatal (the main shard row
   *  is the source of truth; a sidecar miss is a degraded recall source,
   *  not a data loss). The caller (the turn-persist face) gates on the
   *  deterministic zero-LLM gate (marker-hit / monologue-skip / length)
   *  BEFORE calling this face; the daemon's structural content-hash
   *  dedup is the backstop that a repeat never double-writes.
   */
  async ingestModel(text, { session = "" } = {}) {
    await this.open();
    return this._call({
      cmd: "ingest_model",
      payload: { text, session },
    });
  }

  /** Drive the live-ledger state machine (Block ③, ported from Python
   *  sc/ledger.py): `op` = "instruction" (a user instruction supersedes the
   *  current phase + writes a P0 ledger row) | "done" (book a task's DONE
   *  evidence: verified/declared/missed) | "checkpoint" (on-delta P0
   *  checkpoint) | "resident" (read the resident open-task set). `goal` /
   *  `topic` / `checkpointEvery` seed the lazily-created per-store Ledger on
   *  first use. Fail-open: a miss must not break the session.
   */
  async ledger(op, { text = "", taskID = "", evidence = "", goal = "", topic = "", checkpointEvery = 0, taskDesc = "", maxResident = 0 } = {}) {
    await this.open();
    return this._call({
      cmd: "ledger",
      payload: {
        ledger_op: op,
        text,
        task_id: taskID,
        task_desc: taskDesc,
        evidence,
        ledger_goal: goal,
        ledger_topic: topic,
        ledger_checkpoint_every: checkpointEvery,
        ledger_max_resident: maxResident,
      },
    });
  }

  /** Run one distill pass.
   *  - `endpointDegraded` (R3 健康探测读面): signals the host LLM endpoint is
   *    in a fail-streak — the core distiller releases the P0 pending
   *    escape-hatch (head80 placeholder) instead of holding the window
   *    over-store. Defaults false (normal path).
   *  - `cooldown` (G2 R3 backoff): the shell-injected fail-streak state; the
   *    data plane computes the effective remaining cooldown. The retired 55%
   *    waterline (the `enable_band_55` 3rd arg, Go `EnableBand55`) was removed
   *    at the 2026-11-27 cleanup — the 55% band's deterministic eviction now
   *    falls to the 50% band. Defaults {}. */
  async distill(capacityTokens, endpointDegraded = false, cooldown = {}) {
    await this.open();
    return this._call({
      cmd: "distill",
      payload: {
        capacity_tokens: capacityTokens,
        endpoint_degraded: endpointDegraded,
        // G2: R3 cooldown backoff window (shell-injected fail-streak state).
        // The data plane computes the effective remaining cooldown (base ×
        // [1,5,30] ladder) and HOLDS the P0 pending escape while the degraded
        // endpoint is still inside it. All-zero = no cooldown (pre-G2).
        cooldown_level: cooldown.level || 0,
        cooldown_since: cooldown.since || 0,
        cooldown_now: cooldown.now || 0,
        cooldown_base: cooldown.base || 0,
      },
    });
  }

  /** sc_drill point-fetch (owner ruling 2026-11-27: the pull leg of the
   *  ② 路标 design — the model drills the ledger row it needs instead of a
   *  push face re-injecting top-k). Pass EXACTLY ONE locator: `sha16`
   *  (the L0 pointer's 16-hex hash prefix, most precise), `cIndex` (the
   *  c#N ledger-row number as rendered in the checkpoint = the segment's
   *  global seq), or `text` (a distinctive landmark fragment, last resort).
   *  The daemon resolves through the session's shard + model sidecar,
   *  fail-soft: an unknown locator returns {found: false, note} — never an
   *  error (the model falls back to a plain re-ask). */
  async drill({ session = "", cIndex = 0, useSeq = false, sha16 = "", text = "" } = {}) {
    await this.open();
    return this._call({
      cmd: "drill",
      payload: {
        session,
        // null = the seq locator is NOT offered (the store's counter starts
        // at 0 — a plain 0-default would conflate the c#0 row with "no
        // locator"; useSeq = "the caller offered the c_index locator").
        drill_seq: useSeq ? (cIndex | 0) : null,
        drill_hash: sha16,
        drill_text: text,
      },
    });
  }

  /** The compact-ledger face (ported from Python sc/compact_ledger.py): the
   *  append-only cumulative block layout over a <sid>.compact.json sidecar.
   *  `op` = append|reset|settle|unsettle|untrim|evict_page|discard|text. */
  async compactLedger(op, opts = {}) {
    await this.open();
    return this._call({
      cmd: "compact_ledger",
      payload: {
        cl_op: op,
        cl_text: opts.text ?? "",
        cl_settled: opts.settled ?? false,
        cl_kind: opts.kind ?? "adhoc",
        cl_trimmable: opts.trimmable ?? false,
        cl_seq: opts.seq ?? 0,
        cl_anchor_ids: opts.anchorIDs ?? "",
        cl_seqs: opts.seqs ?? [],
      },
    });
  }

  /** Ledger-backed summarizer coverage face: which PREFIX PROBES (the first
   *  ~40 chars of a shadowed message's leading text block) have NO durable
   *  row containing them for `sessionKey` ("" = the legacy/unstamped view).
   *  Probe-contains is robust to the ingest faces' differing text
   *  normalization (a leading prefix is invariant). `missing` empty = full
   *  coverage (compose the checkpoint from the ledger); non-empty (or a
   *  daemon miss) = fall back to the host LLM. */
  async covers(sessionKey, probes) {
    await this.open();
    return this._call({
      cmd: "covers",
      payload: { session: sessionKey, probes },
    });
  }

  /** Paged digest render of `sessionKey`'s live rows (structural P0 first,
   *  then log order; digest-or-head80 per row; `maxChars` caps the text,
   *  0 = uncapped). The checkpoint composition source. */
  async sessionDigest(sessionKey, maxChars = 0) {
    await this.open();
    return this._call({
      cmd: "session_digest",
      payload: { session: sessionKey, max_chars: maxChars },
    });
  }

  /** Form-ladder render of `sessionKey`'s live rows (RENDER_FIX_PROPOSAL
   *  §2.1 — the Python choose_forms alignment: L3/L2/L1/L0 per-row forms,
   *  P0 push cap + index pool + total cap, the anti-drift anchor exemption,
   *  log display order). Deterministic (a function of durable state + opts
   *  only — byte-stable across restarts; the ii ruling). `opts` = {
   *  p0CapBytes, indexPoolBytes, l3CapBytes, totalCapBytes, highPressure };
   *  absent/zero = the face's defaults. The result carries the paged
   *  `text` + the stats `header` line + the `forms` counts + the anchor
   *  seqs. */
  async sessionDigestLadder(sessionKey, opts = {}) {
    await this.open();
    return this._call({
      cmd: "session_digest_ladder",
      payload: {
        session: sessionKey,
        ladder: {
          p0_cap_bytes: opts.p0CapBytes ?? 0,
          index_pool_bytes: opts.indexPoolBytes ?? 0,
          l3_cap_bytes: opts.l3CapBytes ?? 0,
          total_cap_bytes: opts.totalCapBytes ?? 0,
          high_pressure: opts.highPressure === true,
          landmark_head_chars: opts.landmarkHeadChars ?? 0,
          landmark_tail_chars: opts.landmarkTailChars ?? 0,
        },
      },
    });
  }

  /** Write an LLM-generated digest back onto an evicted segment (handle =
   *  content_hash = SegmentID). The LLM call itself is made by the CALLER via
   *  the host ctx.llm (aux ≡ main-model-endpoint, zero new provider); this is
   *  just the durable write-back into the data plane. */
  async digest(segmentId, digestText, digestRef = "") {
    await this.open();
    return this._call({
      cmd: "digest",
      payload: { segment_id: segmentId, digest_text: digestText, digest_ref: digestRef },
    });
  }

  /** ③ tiering write-back: store an LLM-decided tier on a segment (handle =
   *  content_hash). The classifyTier decision (deterministic floor + LLM) is
   *  made by the caller; this is just the durable tier update. */
  async tag(segmentId, tier) {
    await this.open();
    return this._call({
      cmd: "tag",
      payload: { segment_id: segmentId, tier },
    });
  }

  /** ⑧ stock wash: demote the session's rows matching the triple-narrowed
   *  predicate (session + prov + text prefix) to the archive tier via the
   *  durable SetTier P0-demotion leg. `execute` false (the default) = the
   *  dry-run leg: the matches + count, NOTHING changed (the delete face's
   *  double-check discipline). A scope-less call (no session/prefix) is
   *  refused by the daemon (the wipe red line — reported in `refused`). */
  async demote(opts = {}) {
    await this.open();
    return this._call({
      cmd: "demote",
      payload: {
        session: opts.session ?? "",
        prefix: opts.prefix ?? "",
        prov: opts.prov ?? "user",
        to_tier: opts.toTier ?? "P2",
        execute: Boolean(opts.execute),
      },
    });
  }

  /** Scheme A: read user-turn segments from the host's native session log
   *  (zstd-framed V4). The daemon decompresses ALL frames (node:zlib can't)
   *  and returns the deduped user turns. `path` is the host session file
   *  (shell resolves it from dshRoot + cwd + sessionId). */
  async hostUserSegments(path) {
    await this.open();
    return this._call({ cmd: "host", payload: { host_session: path } });
  }

  /** Scheme A-2: read user-turn segments from EVERY session file under a cwd
   *  session dir (the host history). The daemon decompresses all multi-frame
   *  zstd logs + dedupes. Returns { segments, count }. */
  async hostUserSegmentsDir(dir) {
    await this.open();
    return this._call({ cmd: "host-dir", payload: { host_dir: dir } });
  }

  /** Scheme A (model face): read model-turn text segments from EVERY session
   *  file under a cwd session dir. The daemon decompresses all multi-frame
   *  zstd logs, extracts type:"text" blocks of model-sourced assistant
   *  messages, dedupes. Returns { segments, count }. */
  async hostModelSegmentsDir(dir) {
    await this.open();
    return this._call({ cmd: "host-model-dir", payload: { host_dir: dir } });
  }

  /** Scheme A (model face): read model-turn text segments from a single host
   *  session file. Symmetric to hostUserSegments. */
  async hostModelSegments(path) {
    await this.open();
    return this._call({ cmd: "host-model", payload: { host_session: path } });
  }

  /** Durable flush of the lazy P1/P2 batch (crash durability: the gate calls
   *  it after tiering ingest so a host kill cannot lose the batch). */
  async flush() {
    await this.open();
    return this._call({ cmd: "flush", payload: {} });
  }

  async sessionEnd() {
    await this.open();
    return this._call({ cmd: "session_end", payload: {} });
  }

  /** Cross-period reopen (G1): byte-stable-copy an archive jsonl into the
   *  active store (or cold-reopen the current file in place) and stale-mark the
   *  reopened P1 middle-reasoning IN MEMORY (file bytes untouched). `archive`
   *  empty = cold-reopen in place. Fail-open: a miss must not break the
   *  session; the host's own replay still runs.
   */
  async reopen({ archive = "", active = "", session = "" } = {}) {
    await this.open();
    return this._call({
      cmd: "reopen",
      payload: { archive, reopen_active: active, reopen_session: session },
    });
  }

  _call(req, retried = false) {
    this.ensure();
    const id = this.nextId++;
    req.id = id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      // P0 (2026-11-23): the response timeout — an ALIVE-but-unresponsive
      // daemon must not hang the caller forever (the compaction faces await
      // on the host's turn path; an un-settled pending = the silent
      // session death of the 14:09 incident). The timer is unref'd
      // (never keeps the host alive); a fire against an already-settled
      // entry is a no-op via the pending miss (_failChild clears on exit).
      if (this.callTimeoutMs > 0) {
        const timer = setTimeout(() => {
          const p = this.pending.get(id);
          if (!p) return; // settled before the deadline
          this.pending.delete(id);
          const alive = this.child && this.child.exitCode === null;
          if (!retried && this.retryOnTimeout && alive) {
            // P1-lite: re-issue once on a fresh id (a late answer to the
            // stale id is dropped by the pending-miss path in _onData).
            // The caller's settle is handed to the retry attempt.
            void this._call(req, true).then(p.resolve, p.reject);
            return;
          }
          const err = new Error(`scd daemon response timeout after ${this.callTimeoutMs}ms (the daemon is alive but unresponsive; the call fails open, the next face re-issues)`);
          err.name = "IpcTimeoutError";
          p.reject(err);
          // F5: count CONSECUTIVE final timeouts (a face that eventually
          // answers resets the counter in _onData); N in a row against an
          // ALIVE child = the request loop is wedged, not slow — kill it
          // so the next call's ensure() re-spawns a fresh disk-only daemon.
          this.consecTimeouts++;
          if (this.watchdogAfter > 0 && this.consecTimeouts >= this.watchdogAfter && alive) {
            this._killWedged();
          }
        }, this.callTimeoutMs);
        timer.unref?.();
      }
      try {
        this.child.stdin.write(JSON.stringify(req) + "\n");
      } catch (err) {
        // Synchronous write failure (stream destroyed under the race): reject
        // this call; the stdin 'error' guard fails the rest.
        this.pending.delete(id);
        reject(err);
      }
    });
  }

  stop() {
    if (this.child && this.child.exitCode === null) this.child.kill();
  }
}

export { defaultDaemonPath };
