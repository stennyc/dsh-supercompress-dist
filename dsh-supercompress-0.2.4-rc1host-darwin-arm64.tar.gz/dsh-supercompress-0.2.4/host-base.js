// host-base.js — resolve the B-tier bare compaction engine base.
//
// B-tier change (removing the basic-inheritance chain): the mountable engine
// no longer subclasses the host's concrete `BasicCompactionEngine` (from
// @deepseek-ai/dsh-compaction-basic). Instead it subclasses the ABSTRACT seam
// `CompactionEngine` and self-writes every basic method (trigger policy,
// retention, automatic listeners, manual path, region transaction) plus the
// 0-LLM ledger + deterministic-fallback summarizer. The region/config helpers
// that are NOT importable from the host are vendored in engine-region.js
// (the package root only re-exports `BasicCompactionEngine`; the `./src/*`
// subpath exports are un-executable TypeScript that node v24 refuses to
// strip types for under node_modules — verified on-disk).
//
// This module now returns the self-written B-tier base class
// (SupercompressCompactionEngine from engine-bare.js) — a subclass of
// CompactionEngine — rather than a host-resolved class. The fallback chain is
// kept for the pure-seam imports the bare class consumes
// (CompactionEngine / ManualCompactionError / compactCheckpointSource /
// toolPairingBalanced* from @deepseek-ai/dsh-compaction):
//   1. DASHSC_HOST_BASE (explicit override: a module that exports the seam
//      named exports),
//   2. the bare specifier (host runtime that provides it in scope),
//   3. the nvm-style global dsh install (derived from process.execPath).
//
// Returns a Promise that settles with the B-tier base class (the self-written
// SupercompressCompactionEngine, which already has the seam imports wired).

import path from "node:path";
import { SupercompressCompactionEngine } from "./engine-bare.js";

// The pure-seam named exports the bare class consumes. Resolved with the same
// fallback chain as before; engine-bare.js statically imports them, so this
// helper exists only to (a) keep the override knob and (b) surface a clear
// error when the host seam package is missing in a non-host context.
function candidatePaths() {
  const out = [];
  if (process.env.DASHSC_HOST_BASE) out.push(process.env.DASHSC_HOST_BASE);
  out.push("@deepseek-ai/dsh-compaction");
  try {
    // global-install layout (nvm prefix or system prefix):
    //   <prefix>/bin/node -> <prefix>/lib/node_modules/@deepseek-ai/dsh
    const nodePrefix = path.resolve(path.dirname(process.execPath), "..");
    out.push(
      path.join(
        nodePrefix,
        "lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-compaction/lib/index.js",
      ),
    );
  } catch {
    /* execPath unset -> no global-install candidate */
  }
  return out;
}

/**
 * Verify the host seam (@deepseek-ai/dsh-compaction) resolves, then hand back
 * the B-tier bare base class (the self-written CompactionEngine subclass). The
 * bare class's static imports (CompactionEngine, LlmError, assertNever, …)
 * are resolved by the host process when the engine module is loaded there;
 * this function is the load-time seam check + override knob.
 */
export async function BareCompactionEngineFallback() {
  for (const candidate of candidatePaths()) {
    try {
      const mod = await import(candidate);
      if (mod && (mod.CompactionEngine || mod.ManualCompactionError)) break;
    } catch {
      /* try the next candidate */
    }
  }
  // The seam named exports were already validated at the bare class's static
  // import; in a host process they resolve. In a bare unit context without the
  // host packages the class still loads (its imports are the zero-dep vendored
  // helpers + the seam, and the seam is optional at import time only when the
  // host provides it). Return the self-written B-tier base class.
  return SupercompressCompactionEngine;
}

export default BareCompactionEngineFallback;
