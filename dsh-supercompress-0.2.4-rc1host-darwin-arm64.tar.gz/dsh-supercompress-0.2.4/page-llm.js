// page-llm.js — the 70% band face: the ONLY LLM tier of the "打扫房间"
// four-band waterline (90/70/50/40; the 55% band was folded into the 40%
// pre-digest at the 4-band redesign step 3).
//
// When the window is at/above the 70% band, the engine keeps the host's
// retained tail (the `retainTokens` protect-tail strategy, T1) and compresses
// the FIRST N shadowed pages of it through a self-packaged one-shot LLM
// call (the 端点 RIWAY30 reuse: the host's single ctx.llm runtime IS the
// gateway's main-model endpoint — zero new provider, zero new HTTP face).
//
// Prompt shape = the host's warm-prefix structure ([system head] + the
// compressed span) — byte-identical framing to the host's own
// summarizeWithLlm checkpoint call, so the gateway-side KV warm prefix
// cache is REUSED, not cold-started (red line 3: the 70% LLM prompt must
// be [system(head)+被压段], never a bare cold prompt). The system head is
// REUSED byte-for-byte from the session surface's node0 via the host's own
// `systemHead()`-equivalent read (never rebuilt / re-formatted — red lines
// 1/2/7: system node0 bytes + the pre-range prefix stay untouched).
//
// The backfill is the host's compaction transaction on this self-call face
// (the same lock / event / result contract as the B-tier region face —
// compactSurfaceRegion's event sequence, re-emitted here, NOT rewritten):
//
//   compaction/start (the durable lock) -> compaction/summary (the event
//   face: the frameSummary blocks + the shadowed range/seqs/token count +
//   the provider/model) -> ONE user/message surfaceOp replace over [start,end]
//   (the host's frameSummary() <compacted-summary> frame +
//   compactCheckpointSource — byte-identical to a host compact) ->
//   compaction/end (the lock release; a crash mid-operation leaves the
//   unmatched start detectable by the host's entry-state scan).
//
// The return is the host's fixed CompactionResult shape (the B-tier
// compactSurfaceRegion result: compactionId / startSeq / summarySeq /
// endSeq / summary / shadowedRange / shadowedSeqs / shadowedTokenCount)
// + the self-call extras { ok: true, body }.
//
// The pre-range prefix bytes and the system node0 are never rewritten
// (red lines 1/2/7 — the replace range is [start,end] only).
//
// Every miss (no route / no ctx.llm / empty reply / shrink failure) is
// fail-open: the caller falls through to the next-lower band (50%
// distill+ledger, 0 LLM) — the LLM tier is a BOOST, never a hard
// dependency (宁漏勿错, same posture as the 55-band digest upgrade).

import { oneShotText, routeFromAgent, textUserMessage } from "./llm-one-shot.js";
import { safeLlm } from "./llm-guard.js";
import { frameSummary } from "./engine-region.js";
import { compactCheckpointSource } from "@deepseek-ai/dsh-compaction";
import { randomUUID } from "node:crypto";

/**
 * The warm-prefix compression prompt (the host's checkpoint shape):
 * [system head] + the compressed span text + the strict-JSON digest
 * instruction. The host's warm prefix (the same system head + the earlier
 * conversation) stays the LLM call's prefix — the gateway's KV cache hits.
 */
export const PAGE_COMPRESS_INSTRUCTION =
  "Summarize the earlier span of the conversation below into strict JSON (no code fence, no extra text):\n" +
  '{"key_fact": "<=60 chars: the single most important fact/decision", ' +
  '"summary": "<=300 chars: 3-6 sentence digest of the span"}\n' +
  "--- compressed span ---\n";

/**
 * Compose the 70% band LLM call's messages: the warm-prefix system head
 * (REUSED, not rebuilt) + one user message carrying the compressed span +
 * the instruction. `systemText` is the host's node0 system prompt bytes as
 * the host assembled them — passed through verbatim.
 * @returns {{system: string, messages: Array}}
 */
export function pageCompressPrompt({ systemText, spanText }) {
  return {
    system: String(systemText ?? ""),
    messages: [textUserMessage(PAGE_COMPRESS_INSTRUCTION + String(spanText ?? ""))],
  };
}

/**
 * Run the 70% band one-shot page compression.
 * @param {object} args
 * @param {object} args.ctx the host plugin ctx (ctx.llm runtime).
 * @param {string} args.systemText the host's node0 system head bytes (reuse,
 *   never rebuild).
 * @param {string} args.spanText the shadowed span's rendered text (the
 *   compressed pages, head + mid — the host's retained tail stays AFTER it).
 * @param {object} args.agent the host Agent (route source).
 * @param {AbortSignal} [args.signal]
 * @param {number} [args.maxTokens]
 * @returns {Promise<{ok: boolean, body?: string, reason?: string}>} — the
 *   `body` is the strict-JSON digest text ("" when the call missed; the
 *   caller degrades to the 50% band).
 */
export async function compressPage({ ctx, systemText, spanText, agent, signal, maxTokens = 512 } = {}) {
  if (!safeLlm(ctx)) return { ok: false, reason: "no ctx.llm runtime" };
  const route = routeFromAgent(agent);
  if (!route) return { ok: false, reason: "no resolvable LLM route" };
  const { system, messages } = pageCompressPrompt({ systemText, spanText });
  let text;
  try {
    text = await oneShotText(ctx, { route, system, messages, purpose: "page-compress", maxTokens, signal });
  } catch (err) {
    return { ok: false, reason: `one-shot miss: ${err?.message ?? err}` };
  }
  if (!text) return { ok: false, reason: "empty LLM reply" };
  const { parseDigestResponse } = await import("./tagger.js");
  const { keyFact, summary } = parseDigestResponse(text);
  const body = keyFact || summary ? `${keyFact}\n${summary}`.trim() : text.trim();
  if (!body) return { ok: false, reason: "unparseable LLM reply (kept verbatim, empty after trim)" };
  return { ok: true, body };
}

/**
 * Backfill the 70% band compressed page into the session surface: the
 * host's compaction transaction on this self-call face —
 *   compaction/start (the durable lock) -> compaction/summary (the event
 * face: the frameSummary blocks + the shadowed range/seqs/token count +
 * the provider/model "supercompress"/"ledger-page") -> ONE user/message
 * surfaceOp replace over [start,end] (the host's frameSummary +
 * compactCheckpointSource — byte-identical to a host compact's checkpoint
 * message) -> compaction/end (the lock release; a crash mid-operation
 * leaves the unmatched start detectable).
 * The system node0 + the pre-range prefix are never rewritten (the
 * replace range is [start,end] only — red lines 1/2/7).
 * @returns {object} the host's fixed CompactionResult shape (the B-tier
 *   compactSurfaceRegion result): { compactionId, startSeq, summarySeq,
 *   endSeq, summary, shadowedRange: {start,end}, shadowedSeqs,
 *   shadowedTokenCount } + the self-call extras { ok: true, body }.
 */
export function backfillCompressedPage(session, start, end, body, meter) {
  const summary = frameSummary([{ type: "text", text: String(body ?? "") }]);
  const compactionId = compactCheckpointSource(`page-compress-${start}-${end}`).compactionId;
  const message = {
    role: "user",
    content: summary,
    source: compactCheckpointSource(`page-compress-${start}-${end}`),
    // v4 open-time admission requires a non-empty id on every user/message
    // (the host's createUserMessage stamps randomUUID()); without it the
    // persisted checkpoint row fails validation and the session is corrupt.
    id: randomUUID(),
  };
  // The shadowed span + its priced token count (the host's prepareCompaction
  // faces on this self-call face: the surface nodes over [start,end] + the
  // O(1) meter's heuristic pricing when a meter is handed in; the engine
  // passes its ctx tokenMeter — a test session without one degrades to 0,
  // the shape holds).
  const shadowedSeqs = [];
  {
    const nodes = session.surface.nodes;
    const sIdx = nodes.indexOf(start);
    const eIdx = nodes.indexOf(end);
    if (sIdx !== -1 && eIdx !== -1 && sIdx <= eIdx) shadowedSeqs.push(...nodes.slice(sIdx, eIdx + 1));
  }
  let shadowedTokenCount = 0;
  if (meter?.measure) {
    try {
      const measurement = meter.measure(session);
      for (const node of measurement?.nodes ?? []) {
        if (node.seq >= start && node.seq <= end) shadowedTokenCount += node.heuristicTokens ?? node.tokens ?? 0;
      }
    } catch {
      /* pricing unavailable -> 0 (the shape holds; the host's meter is the source of truth) */
    }
  }
  // ── the host's compaction transaction shape (the B-tier lock/event face,
  // re-emitted on this self-call face — same event types + same data shapes) ──
  // 1. the durable lock (start FIRST: a mid-operation crash leaves the
  //    unmatched start detectable by the host's entry-state scan). The
  //    lifecycle data is the host's compactSurfaceRegion shape (the C-band
  //    self-call face runs between turns: `turn` is omitted — the host's
  //    lock scan matches on the event type + the compactionId, and an
  //    unmatched start still reads as the active lock).
  const lifecycle = { compactionId };
  const startEvent = session.append("compaction/start", lifecycle);
  // 2. the summary event (the host's `compaction/summary` contract: the
  //    summary blocks + the shadowed range/seqs/token count + provider/model
  //    — the host's session/event observer sees the 70% band's summary).
  const summaryEvent = session.append("compaction/summary", {
    compactionId,
    summary,
    shadowedRange: { start, end },
    shadowedSeqs: [...shadowedSeqs],
    shadowedTokenCount,
    provider: "supercompress",
    model: "ledger-page",
  });
  // 3. the checkpoint body: ONE user/message surfaceOp replace over [start,end]
  // (the host's V4 transcript layout: `data.message` carries the UserMessage;
  // the surfaceOp replace swaps [start,end] for this node — the old nodes
  // stay in the durable log; sourceEventSeqs cite the start + summary + the
  // shadowed originals, the host's commitCompactionBody shape).
  const event = session.append("user/message", { message }, {
    surfaceOp: { op: "replace", startSeq: start, endSeq: end },
    sourceEventSeqs: [startEvent.seq, summaryEvent.seq, ...shadowedSeqs],
  });
  // 4. the lock release (the same lifecycle data as the start; the body
  // append above is the last durable step).
  const endEvent = session.append("compaction/end", lifecycle);
  // The host's append() returns the event object (its .seq is the new
  // surface position); a test-fake returning a bare seq number is
  // tolerated (the number IS the seq).
  const seq = typeof event?.seq === "number" ? event.seq : event;
  // 5. the host's fixed CompactionResult shape + the self-call extras.
  return {
    ok: true,
    body: String(body ?? ""),
    compactionId,
    startSeq: startEvent.seq,
    summarySeq: summaryEvent.seq,
    endSeq: endEvent.seq,
    messageSeq: seq,
    summary,
    shadowedRange: { start, end },
    shadowedSeqs: [...shadowedSeqs],
    shadowedTokenCount,
  };
}
