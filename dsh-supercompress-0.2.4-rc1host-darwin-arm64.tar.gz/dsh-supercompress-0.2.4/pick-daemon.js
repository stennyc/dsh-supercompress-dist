#!/usr/bin/env node
// pick-daemon.js — materialize the platform-matched `scd` daemon binary into
// bin/scd (the path the shell's ipc.js defaultDaemonPath resolves first).
//
// Usage:
//   node pick-daemon.js            # detect this machine, copy the matching binary
//   node pick-daemon.js --check   # verify bin/scd matches the current platform, exit 0/1
//
// Supported targets (see release.json): linux-amd64, linux-arm64, darwin-amd64,
// darwin-arm64. Windows is NOT supported: the Go daemon uses syscall.Flock
// (Unix-only file locking) — a Windows build requires porting the locking layer.
//
// The script is idempotent: re-running it re-copies the binary (cheap, ~4MB).
// It exits 0 on success and 1 with a clear message on an unsupported
// platform or a missing release binary. postinstall in package.json runs
// this automatically for npm-style installs; run it by hand for git-clone
// installs.

import { cpSync, existsSync, chmodSync, statSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));

// node arch name -> go target suffix
const ARCH = { x64: "amd64", arm64: "arm64" };
// node platform -> go GOOS
const OS = { linux: "linux", darwin: "darwin" };

function targetName() {
  const os = OS[process.platform];
  const arch = ARCH[process.arch];
  if (!os || !arch) return null;
  return `scd-${os}-${arch}`;
}

function fail(msg) {
  process.stderr.write(`[pick-daemon] ${msg}\n`);
  process.exit(1);
}

const binDir = join(here, "bin");
const releasesDir = join(here, "releases");

if (!existsSync(releasesDir)) fail(`releases/ not found next to pick-daemon.js (run from the dist root)`);

const target = targetName();
if (!target) {
  fail(
    `unsupported platform: ${process.platform}/${process.arch}. ` +
      `Supported: linux(x64|arm64), darwin(x64|arm64). ` +
      `Windows is unsupported (the daemon uses syscall.Flock, Unix-only). ` +
      `If you are on an unsupported platform, point the "daemonPath" config knob at a daemon you built yourself.`
  );
}

const src = join(releasesDir, target);
if (!existsSync(src)) fail(`releases/${target} not present — is the dist tree complete? (release.json lists the shipped targets)`);

const dst = join(binDir, "scd");
cpSync(src, dst, { force: true });
try { chmodSync(dst, 0o755); } catch { /* windows/immutable fs: the copy still works for launch via the daemonPath knob */ }

if (process.argv.includes("--check")) {
  if (existsSync(dst) && statSync(dst).size > 0) {
    process.stdout.write(`[pick-daemon] ok: bin/scd <- releases/${target}\n`);
    process.exit(0);
  }
  fail("--check: bin/scd missing or empty — run without --check first");
}

process.stdout.write(`[pick-daemon] ok: bin/scd <- releases/${target} (platform ${process.platform}/${process.arch})\n`);
