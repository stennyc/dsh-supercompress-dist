// handoff-gen.js — the 90% 主动 handoff face (C tier, "打扫房间" four-band
// waterline; the filemem-dsh handoff.go replica, 0-LLM deterministic
// concatenation, llm_used=false auditable).
//
// When the window is at/above the 90% band, the engine does NOT wait for the
// host's pressure/overflow compaction: it proactively composes a handoff
// checkpoint from the three filemem material sources and backfills it into
// the session surface as ONE user/message replace over the [start,end]
// range — the host's frameSummary() + compactCheckpointSource() framing, so
// the durable checkpoint is byte-identical to a host compact:
//
//   handoff page =
//     [system head]  — NEVER rebuilt. The replace range starts at the FIRST
//       non-system node (selectCompactableRange's firstIdx rule); the host's
//       region transaction re-prepends node0 bytes on the next assemble
//       (buildSummarizationInput keeps the system message OUT of the
//       shadowed region — the red line "system node0 字节永不动").
//     + [distill 台账段]  — the compact-ledger c#N blocks (P0/P1/P2 digests
//       the data plane has already folded; read through the daemon's
//       `compact_ledger` text face) + the session's paged ledger digest
//       (P0 structural floor; `session_digest`), deterministic page render.
//     + [filemem 台账行]  — this session's CONFIRMED ledger rows read from
//       <storeDir>/sessions/<sid>.jsonl (the per-session shard, the same
//       corpus the Go data plane owns), rendered as
//       `[filemem/<type>] <content>` lines (the filemem handoff.go row
//       format — replicated, NOT imported).
//     + [宿主 session 段]  — the host zstd session events (the scheme A-2
//       read face: user + model turns from the host's own native log, the
//       pure-dsh R2 source; no supercompress dependency).
//
// One live handoff per source (REPLACE, never append — the filemem
// writeHandoffRow rule, surface-level: a previous handoff checkpoint message
// for this session is DROPPED from the surface range selection by starting
// the range after the latest host checkpoint; re-handoff replaces the page,
// it does not stack into a log).
//
// The backfill is the host's compaction transaction shape (the same lock /
// event / result contract as the B-tier region face — compactSurfaceRegion's
// event sequence, re-emitted on this self-call face, NOT rewritten):
//
//   compaction/start  ->  compaction/summary  ->  user/message replace
//   -> compaction/end
//
// The start is appended FIRST (the durable lock — a mid-operation crash leaves
// the unmatched start detectable by the host's inspectCompactionEntryState
// scan); the summary event carries the frameSummary() blocks + the shadowed
// range / seqs / token count + the provider/model face (the host's
// `compaction/summary` event contract — the host's session/event observer sees
// the 90% band's summary exactly like a B-tier region compact). The
// user/message replace (frameSummary + compactCheckpointSource, byte-
// identical to a host compact) and the closing compaction/end (the same
// lifecycle data as the start) complete the transaction.
//
// system node0 bytes, the tools block, and the pre-range prefix are never
// rewritten (red lines 1/2/3/7 — the replace range is [start,end] only).
//
// The return is the host's fixed CompactionResult shape (the B-tier
// compactSurfaceRegion result — the same fields the host's logResult +
// replay faces consume): compactionId / startSeq / summarySeq / endSeq /
// summary / shadowedRange / shadowedSeqs / shadowedTokenCount.
//
// Zero deps: node stdlib only; the zstd host-log read goes through the
// daemon client (the shell never decompresses — the repo rule).

import { readFileSync, existsSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { compactCheckpointSource } from "@deepseek-ai/dsh-compaction";
import { frameSummary, selectCompactableRange } from "./engine-region.js";

// The filemem handoff event whitelist (filemem-dsh dshSessionEventTypes —
// replicated, not imported): dialogue + tool + subagent-injection + title +
// request context. Skeleton/config events carry no human content.
// (The host's SURFACE_EVENT_TYPES is {system,developer,user,assistant,
// tool/result} — this wider whitelist is for the R2 zstd source, not the
// live surface.)
export const HANDOFF_EVENT_TYPES = new Set([
  "user/message",
  "assistant/message",
  "tool/call",
  "tool/result",
  "agent/inbox/spliced",
  "session/title",
  "request/context",
]);

/**
 * Read this session's CONFIRMED filemem ledger rows from the per-session
 * shard file <storeDir>/sessions/<sid>.jsonl (node:fs — the shell owns the
 * store dir; the daemon's read faces serve the SAME file). Missing file /
 * unparseable lines -> [] (a dead session may have no shard; degrade, never
 * fail — the filemem fail-soft posture).
 * @returns {Array<{type:string, content:string}>}
 */
export function readFilememShard(storeDir, sid, maxRows = 200) {
  const out = [];
  if (!storeDir || !sid) return out;
  let raw;
  try {
    const file = `${storeDir}/sessions/${String(sid)}.jsonl`;
    if (!existsSync(file)) return out;
    raw = readFileSync(file, "utf8");
  } catch {
    return out; // unreadable -> degrade (the handoff page still composes)
  }
  for (const line of String(raw).split(/\r?\n/)) {
    const t = line.trim();
    if (!t) continue;
    let row;
    try {
      row = JSON.parse(t);
    } catch {
      continue; // a torn tail frame never fails the face
    }
    // The confirmed-filemem-row shape: the Go ledger's durable row carries
    // `tier` P0 + `provenance`/`kind`; the filemem-style [filemem/<type>]
    // line uses the row's `type` field when present, else its tier/prov
    // combo (the filemem handoff.go default is "fact" for an empty type).
    const content = String(row?.content ?? row?.original_text ?? "").trim();
    if (!content) continue;
    let ty = String(row?.type ?? "").trim();
    if (!ty) ty = row?.tier && row?.provenance ? `${row.provenance}` : "fact";
    if (out.length >= maxRows) break;
    out.push({ type: ty, content });
  }
  return out;
}

/**
 * Render the deterministic handoff page body (the filemem
 * handoffFallbackSummary shape — per-segment \n\n join, llm_used=false
 * auditable): the distill 台账段 (the compact-ledger c#N blocks + the paged
 * ledger digest), then the filemem 台账行 (`[filemem/<type>] content`), then
 * the host session 段 (`[dsh/<event>] text` lines). Empty sections are
// dropped, never left as blank holes.
 * @param {object} parts
 * @param {string[]} [parts.ledgerSegments] the compact-ledger c#N block texts.
 * @param {string} [parts.digestText] the paged session ledger digest.
 * @param {Array<{type:string,content:string}>} [parts.filememRows]
 * @param {string[]} [parts.hostEvents] the host-session event lines.
 * @param {string} sourceSessionId
 * @returns {string} the handoff page body (or "" when every source was empty).
 */
export function renderHandoffPage({ ledgerSegments = [], digestText = "", filememRows = [], hostEvents = [] }, sourceSessionId) {
  const sections = [];
  const dt = String(digestText ?? "").trim();
  if (dt) sections.push(`## 台账段 (distill / paged ledger)\n${dt}`);
  for (const seg of ledgerSegments) if (String(seg ?? "").trim()) sections.push(String(seg).trim());
  for (const row of filememRows) {
    const c = String(row?.content ?? "").trim();
    if (c) sections.push(`[filemem/${row.type || "fact"}] ${c}`);
  }
  for (const ev of hostEvents) if (String(ev ?? "").trim()) sections.push(String(ev).trim());
  // The deterministic segment-concat body (the filemem handoffFallbackSummary
  // shape: the sections \n\n-joined). The [HANDOFF: ...] header + the
  // llm_used=false audit stamp ride the BACKFILL frame (see backfillHandoff)
  // — the page body itself is the raw material (a header-only body is an
  // empty handoff, refused by the caller).
  return sections.filter(Boolean).join("\n\n");
}

/**
 * Compose + backfill the 90% band handoff page into the session surface.
 * The backfill is the host's compaction transaction on this self-call face:
 *   compaction/start (the durable lock) -> compaction/summary (the event face:
 * the frameSummary blocks + the shadowed range/seqs/token count + the
 * provider/model) -> ONE user/message surfaceOp replace over [start,end] (the
 * host's frameSummary + compactCheckpointSource, byte-identical to a host
 * compact; never a new event type, never an append — one live handoff per
 * source) -> compaction/end (the lock release, the same lifecycle data as the
 * start; a crash mid-operation leaves the unmatched start detectable).
 * The range stays [start,end] only — system node0 bytes, the tools block,
 * and the pre-range prefix are never rewritten (red lines 1/2/3/7).
 * @param {object} args
 * @param {object} args.session host Session (surface append + surfaceOp)
 * @param {number} args.start / args.end the shadowed range (start = the
 *   first non-system node — system node0 is OUTSIDE the range, red line).
 * @param {string} args.sourceSessionId the session being handed off.
 * @param {object} [args.parts] the material sources (see renderHandoffPage).
 * @returns {object} the host's fixed CompactionResult shape (the B-tier
 *   compactSurfaceRegion result): { compactionId, startSeq, summarySeq,
 *   endSeq, summary, shadowedRange: {start,end}, shadowedSeqs,
 *   shadowedTokenCount } + the self-call extras { ok: true, body } — OR
 *   { ok: false, reason } when the page has no material to backfill (the
 *   lock face is entered ONLY after the no-material refusal, so a miss
 *   leaves no orphan start; the caller falls to the 70% band).
 * @param {object} [meter] optional O(1) token meter (the host's ctx
 *   `tokenMeter` face: `measure(session)` prices the shadowed nodes — the
 *   host's prepareCompaction shadowedTokenCount face; absent -> 0, the
 *   shape holds, the value is best-effort).
 */
export function backfillHandoff(session, start, end, sourceSessionId, parts = {}, meter) {
  const body = renderHandoffPage(parts, sourceSessionId);
  if (!body || !body.trim()) {
    return { ok: false, reason: "no handoff materials (all three sources empty)" };
  }
  // The host's durable checkpoint framing (byte-identical to a host compact):
  // frameSummary wraps the summary blocks in the <compacted-summary> frame;
  // compactCheckpointSource stamps the user message's `source` marker. The
  // [HANDOFF: ...] audit header + the llm_used=false stamp ride the frame's
  // preamble (the deterministic-concat posture, auditable on replay).
  const summary = frameSummary([
    { type: "text", text: `[HANDOFF: session ${sourceSessionId} — deterministic segment concatenation, llm_used=false]\n` },
    { type: "text", text: body },
  ]);
  const compactionId = compactCheckpointSource(`handoff-${sourceSessionId}`).compactionId;
  const message = {
    role: "user",
    content: summary,
    source: compactCheckpointSource(`handoff-${sourceSessionId}`),
    // v4 open-time admission requires a non-empty id on every user/message
    // (the host's createUserMessage stamps randomUUID()); without it the
    // persisted checkpoint row fails validation and the session is corrupt.
    id: randomUUID(),
  };
  // The shadowed span + its priced token count (the host's prepareCompaction
  // faces on this self-call face: the surface nodes over [start,end] + the
  // O(1) meter's heuristic pricing; a test session without a meter degrades
  // to 0 — the shape holds, the value is best-effort).
  const shadowedSeqs = [];
  {
    const nodes = session.surface.nodes;
    const sIdx = nodes.indexOf(start);
    const eIdx = nodes.indexOf(end);
    if (sIdx !== -1 && eIdx !== -1 && sIdx <= eIdx) shadowedSeqs.push(...nodes.slice(sIdx, eIdx + 1));
  }
  let shadowedTokenCount = 0;
  if (meter?.measure) {
    try {
      const measurement = meter.measure(session);
      for (const node of measurement?.nodes ?? []) {
        if (node.seq >= start && node.seq <= end) shadowedTokenCount += node.heuristicTokens ?? node.tokens ?? 0;
      }
    } catch {
      /* pricing unavailable -> 0 (the shape holds; the host's meter is the source of truth) */
    }
  }
  // ── the host's compaction transaction shape (the B-tier lock/event face,
  // re-emitted on this self-call face — same event types + same data shapes) ──
  // 1. the durable lock (start FIRST: a mid-operation crash leaves the
  //    unmatched start detectable by the host's entry-state scan). The
  //    lifecycle data is the host's compactSurfaceRegion shape (the C-band
  //    self-call face runs between turns: `turn` is omitted — the host's
  //    lock scan matches on the event type + the compactionId, and an
  //    unmatched start still reads as the active lock).
  const lifecycle = { compactionId };
  const startEvent = session.append("compaction/start", lifecycle);
  // 2. the summary event (the host's `compaction/summary` contract: the
  //    summary blocks + the shadowed range/seqs/token count + provider/model
  //    — the host's session/event observer sees the 90% band's summary).
  const summaryEvent = session.append("compaction/summary", {
    compactionId,
    summary,
    shadowedRange: { start, end },
    shadowedSeqs: [...shadowedSeqs],
    shadowedTokenCount,
    provider: "supercompress",
    model: "handoff",
  });
  // 3. the checkpoint body: ONE user/message surfaceOp replace over [start,end]
  // (the host's commitCompactionBody body append; sourceEventSeqs cite the
  // start + summary + the shadowed originals — the durable log keeps them).
  const event = session.append("user/message", { message }, {
    surfaceOp: { op: "replace", startSeq: start, endSeq: end },
    sourceEventSeqs: [startEvent.seq, summaryEvent.seq, ...shadowedSeqs],
  });
  // 4. the lock release (the same lifecycle data as the start; a failed close
  // is NOT attempted here — the body append above is the last durable step).
  const endEvent = session.append("compaction/end", lifecycle);
  // The host's append() returns the event object (its .seq is the new
  // surface position); a test-fake returning a bare seq number is
  // tolerated (the number IS the seq).
  const seq = typeof event?.seq === "number" ? event.seq : event;
  // 5. the host's fixed CompactionResult shape (the B-tier compactSurfaceRegion
  // result: compactionId / startSeq / summarySeq / endSeq / summary /
  // shadowedRange / shadowedSeqs / shadowedTokenCount) + the self-call extras.
  return {
    ok: true,
    body,
    compactionId,
    startSeq: startEvent.seq,
    summarySeq: summaryEvent.seq,
    endSeq: endEvent.seq,
    messageSeq: seq,
    summary,
    shadowedRange: { start, end },
    shadowedSeqs: [...shadowedSeqs],
    shadowedTokenCount,
  };
}

// ── the 90% band's range selection (the engine's handoff face) ──────────────
/**
 * Resolve the 90% band's shadowed range: the first non-system surface node
 * through the host's retained-tail boundary (the `retainTokens` protect-tail
 * strategy — the tail stays uncompressed for the next turn). Delegates to the
 * host's own selectCompactableRange (the B-tier vendored face — the tool-pair
 * edge check + the system-node skip). Returns null when no safe range
 * exists (the caller degrades to the next band).
 * @returns {{start:number,end:number}|null}
 */
export function selectHandoffRange(session, measurement, retainTokens) {
  return selectCompactableRange(session, measurement, retainTokens);
}
