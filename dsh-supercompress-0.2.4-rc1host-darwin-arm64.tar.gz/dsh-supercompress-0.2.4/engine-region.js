// engine-region.js — self-written vendored region + config helpers for the B-tier
// bare compaction engine (the 0-LLM tier that drops the BasicCompactionEngine
// inheritance chain).
//
// WHY VENDORED, NOT IMPORTED
// --------------------------
// The owner's B-tier ruling: the engine subclasses the ABSTRACT seam
// `CompactionEngine` (@deepseek-ai/dsh-compaction) — NOT the concrete
// `BasicCompactionEngine` — and reuses the region/config helper strategy
// "imported, not rewritten".
//
// On-disk truth (dsh 0.2.2-rc.5, global npm under node v24.20.0) — the import
// specifiers were pinned by reading the host, NOT guessed:
//
//   * `@deepseek-ai/dsh-compaction` package ROOT exports (verified by live
//     import inside the host process):
//         CompactionEngine, CompactionId, ManualCompactionError,
//         compactCheckpointSource, isCompactCheckpointSource,
//         toolPairingBalancedBefore, toolPairingBalancedAfter
//       → the engine shell + checkpoint/lock/pairing helpers ARE reused.
//
//   * `@deepseek-ai/dsh-compaction-basic` package ROOT exports ONLY
//       `BasicCompactionEngine` (its `lib/index.js` last line:
//       `export { BasicCompactionEngine, BasicCompactionEngine as default };`).
//       The region/config/summarizer helpers (compactSurfaceRegion,
//       selectCompactableRange, assertNoActiveCompaction, resolveConfig,
//       resolveTargetPolicy, resolveCompactSpec, TargetPressureConfigError,
//       frameSummary, …) are INLINED into that same compiled file but are
//       NOT re-exported.
//
//   * The `./src/*` subpath exports map in the basic package.json DOES open
//       `"./src/*": "./src/*"`, BUT the shipped `src/` directory contains the
//       TypeScript SOURCE (*.ts), and node v24 REFUSES to strip types for
//       files under node_modules (`--experimental-strip-types` → "Stripping
//       types is currently unsupported for files under node_modules"). Both
//       the bare specifier AND the absolute-path form of the subpath fail to
//       import.
//
// Therefore the four region/config VALUE helpers below are the ones that CANNOT
// be imported in a host process and are self-written here, byte-faithful to
// basic's compiled `lib/index.js` (read in full) so the trigger policy /
// retention math / shrink validation are IDENTICAL. The pure-seam helpers
// (toolPairingBalanced*, compactCheckpointSource, ManualCompactionError,
// CompactionId) ARE imported from the package root — reused, not rewritten.
//
// ZERO deps beyond node stdlib + the host compaction seam (the repo rule: the
// shell only uses node stdlib + host-provided packages).

import {
  CompactionId,
  ManualCompactionError,
  compactCheckpointSource,
  isCompactCheckpointSource,
  toolPairingBalancedBefore,
  toolPairingBalancedAfter,
} from "@deepseek-ai/dsh-compaction";
import { randomUUID } from "node:crypto";
import { isDeepStrictEqual } from "node:util";

// ── config helpers (mirror of basic's compiled config.ts, self-written) ──────
// Reused by the bare engine's `static Config` load-validation: the owner ruled
// the B-tier class writes its OWN schema (not basic's `z.object` load check)
// but borrows basic's fail-fast VALIDATION FACE (the same key set, the same
// default values, the same ratio/retention/integrity checks) so a web row that
// loads against basic also loads against the bare engine.

const DEFAULT_THRESHOLD_RATIO = 0.8;
const DEFAULT_RETAIN_RATIO = 0.16;

const POLICY_CONFIG_KEYS = [
  "thresholdRatio",
  "headroomTokens",
  "retainRatio",
  "retainTokens",
  "summarizationProvider",
  "summarizationModel",
  "maxTokens",
  "compactionRetries",
  "maxOverflowRetries",
];

// Complete public top-level configuration key set (== the web row fields:
// thresholdRatio / headroomTokens / retainRatio / retainTokens /
// summarizationProvider / summarizationModel / maxTokens / compactionRetries /
// maxOverflowRetries / modelPolicies / auto / liveUserTrim /
// userPasteThresholdChars / userPasteHeadChars / userPasteTailChars).
const BASIC_COMPACT_CONFIG_KEYS = new Set([
  ...POLICY_CONFIG_KEYS,
  "modelPolicies",
  "auto",
  // Live user-paste trim-at-production face (top-level only; the per-model
  // policy never carries these — the live face + the 40% band's user pass
  // are engine-global, not per-model):
  "liveUserTrim",
  "userPasteThresholdChars",
  "userPasteHeadChars",
  "userPasteTailChars",
]);

const MODEL_POLICY_KEYS = new Set([
  "provider",
  "model",
  ...POLICY_CONFIG_KEYS,
]);

/** Target-specific pressure configuration failure (the warn-suppress key). */
export class TargetPressureConfigError extends Error {
  targetKey;
  constructor(targetKey, message) {
    super(message);
    this.name = "TargetPressureConfigError";
    this.targetKey = targetKey;
  }
}

function isUnknownRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}
function assertNonEmptyString(name, value) {
  if (typeof value !== "string" || value.length === 0)
    throw new Error(`${name} must be a non-empty string`);
}
function assertPositiveInteger(name, value) {
  if (typeof value !== "number" || !Number.isInteger(value) || value <= 0)
    throw new Error(`${name} (${String(value)}) must be a positive integer`);
}
function assertNonNegativeInteger(name, value) {
  if (typeof value !== "number" || !Number.isInteger(value) || value < 0)
    throw new Error(`${name} (${String(value)}) must be a non-negative integer`);
}
function assertRatio(name, value) {
  if (typeof value !== "number" || !Number.isFinite(value) || value <= 0 || value > 1)
    throw new Error(`${name} (${String(value)}) must be a number in (0, 1]`);
}
function deepFreeze(value) {
  Object.freeze(value);
  for (const key of Object.keys(value)) if (isUnknownRecord(value[key])) deepFreeze(value[key]);
  return value;
}

function validateSummarizationPair(config, name) {
  const provider = config.summarizationProvider;
  const model = config.summarizationModel;
  if (provider !== undefined && typeof provider !== "string")
    throw new Error(`${name}.summarizationProvider must be a string`);
  if (model !== undefined && typeof model !== "string")
    throw new Error(`${name}.summarizationModel must be a string`);
  if (provider === undefined && model === undefined) return;
  if (provider === undefined || model === undefined || provider.length === 0 !== (model.length === 0))
    throw new Error(`${name}: summarizationProvider and summarizationModel must be set together as an empty or non-empty pair`);
}

function validatePolicy(config, name) {
  const thresholdRatio = config.thresholdRatio;
  const headroomTokens = config.headroomTokens;
  const retainRatio = config.retainRatio;
  const retainTokens = config.retainTokens;
  const maxTokens = config.maxTokens;
  const compactionRetries = config.compactionRetries;
  const maxOverflowRetries = config.maxOverflowRetries;
  if (thresholdRatio !== undefined) assertRatio(`${name}.thresholdRatio`, thresholdRatio);
  if (headroomTokens !== undefined) assertNonNegativeInteger(`${name}.headroomTokens`, headroomTokens);
  if (retainRatio !== undefined) assertRatio(`${name}.retainRatio`, retainRatio);
  if (retainTokens !== undefined) assertNonNegativeInteger(`${name}.retainTokens`, retainTokens);
  if (retainRatio !== undefined && retainTokens !== undefined)
    throw new Error(`${name}: retainRatio and retainTokens are mutually exclusive`);
  if (maxTokens !== undefined) assertPositiveInteger(`${name}.maxTokens`, maxTokens);
  if (compactionRetries !== undefined) assertNonNegativeInteger(`${name}.compactionRetries`, compactionRetries);
  if (maxOverflowRetries !== undefined) assertNonNegativeInteger(`${name}.maxOverflowRetries`, maxOverflowRetries);
  validateSummarizationPair(config, name);
}

function validateKeys(config, keys, name) {
  for (const key of Object.keys(config))
    if (!keys.has(key)) throw new Error(`${name}: unknown key "${key}"`);
}

function resolveRetention(config, fallback) {
  if (config.retainTokens !== undefined) return { retainTokens: config.retainTokens };
  if (config.retainRatio !== undefined) return { retainRatio: config.retainRatio };
  return fallback;
}

function validateRatioRetention(thresholdRatio, retention, name) {
  if (retention.retainRatio !== undefined && retention.retainRatio >= thresholdRatio)
    throw new Error(`${name}: retainRatio (${retention.retainRatio}) must be less than the resolved thresholdRatio (${thresholdRatio})`);
}

function resolveModelPolicies(configured) {
  if (configured === undefined) return [];
  if (!Array.isArray(configured)) throw new Error("SupercompressCompactionConfig: modelPolicies must be an array");
  const seen = new Set();
  return configured.map((source, index) => {
    assertModelPolicy(source, `SupercompressCompactionConfig: modelPolicies[${index}]`);
    const key = `${source.provider}\u0000${source.model}`;
    if (seen.has(key))
      throw new Error(`SupercompressCompactionConfig: duplicate model policy for ${source.provider}/${source.model}`);
    seen.add(key);
    return { ...source };
  });
}

function assertModelPolicy(source, name) {
  if (!isUnknownRecord(source)) throw new Error(`${name} must be an object`);
  validateKeys(source, MODEL_POLICY_KEYS, name);
  assertNonEmptyString(`${name}.provider`, source.provider);
  assertNonEmptyString(`${name}.model`, source.model);
  validatePolicy(source, name);
}

/**
 * Unwrap a schemastery Volatile getter (the `value` the host's cordis
 * resolveConfig returns from a plugin `~standard.validate` is a schemastery
 * object whose volatile fields are `.get()`-bearing references, NOT bare
 * values — the host's own dsh-compaction-basic has no `~standard` face so it
 * never hits this; supercompress's schemastery `z.object` does). A plain
 * number/boolean/string/undefined passes through unchanged; a `{ get() }`
 * Volatile reference is unwrapped to its current value.
 * @param {*} v
 * @returns {*} the bare value
 */
function unref(v) {
  return typeof v === "object" && v !== null && typeof v.get === "function" ? v.get() : v;
}

/**
 * Resolve + validate service defaults and exact-target overrides (basic's
 * resolveConfig, self-written; fail-fast + detached-immutable + defaults).
 * @param {object} [config] untrusted plugin configuration (post-Loader). The
 * host's cordis resolveConfig passes the schemastery `value` here, whose
 * volatile fields are `.get()`-bearing references — every read below unwraps
 * them via `unref` so `assertRatio` / `assertNonNegativeInteger` / the
 * `typeof` checks see bare values, not `[object Object]`.
 * @returns {object} detached, frozen resolved config.
 */
export function resolveConfig(config = {}) {
  // Unwrap every top-level + policy field from a schemastery Volatile
  // reference into a bare value BEFORE validation (the host's cordis hands us
  // the schemastery `value`; non-volatile fields are already bare, volatile
  // fields are `.get()` refs). This mirrors the shell's readNum/readBool/readStr
  // unwrap in bundle.js so the vendored resolveConfig sees the same bare
  // values the rest of the engine does.
  const source = { ...config };
  for (const key of Object.keys(source)) source[key] = unref(source[key]);
  if (Array.isArray(source.modelPolicies))
    source.modelPolicies = source.modelPolicies.map((policy) => {
      const p = { ...policy };
      for (const k of Object.keys(p)) p[k] = unref(p[k]);
      return p;
    });
  validateKeys(source, BASIC_COMPACT_CONFIG_KEYS, "SupercompressCompactionConfig");
  validatePolicy(source, "SupercompressCompactionConfig");
  if (source.auto !== undefined && typeof source.auto !== "boolean")
    throw new Error("SupercompressCompactionConfig: auto must be a boolean");
  // Live user-paste trim knobs (top-level only; defaults = the preclean.js
  // USER_* constants — keep in sync): 8192 / 4096 / 1024.
  if (source.liveUserTrim !== undefined && typeof source.liveUserTrim !== "boolean")
    throw new Error("SupercompressCompactionConfig: liveUserTrim must be a boolean");
  if (source.userPasteThresholdChars !== undefined)
    assertPositiveInteger("SupercompressCompactionConfig.userPasteThresholdChars", source.userPasteThresholdChars);
  if (source.userPasteHeadChars !== undefined)
    assertNonNegativeInteger("SupercompressCompactionConfig.userPasteHeadChars", source.userPasteHeadChars);
  if (source.userPasteTailChars !== undefined)
    assertNonNegativeInteger("SupercompressCompactionConfig.userPasteTailChars", source.userPasteTailChars);
  const headroomTokens = source.headroomTokens ?? 65536;
  const maxTokens = source.maxTokens ?? headroomTokens;
  assertPositiveInteger("SupercompressCompactionConfig.maxTokens (explicit or from headroomTokens)", maxTokens);
  const thresholdRatio = source.thresholdRatio ?? DEFAULT_THRESHOLD_RATIO;
  const retention = resolveRetention(source, { retainRatio: DEFAULT_RETAIN_RATIO });
  validateRatioRetention(thresholdRatio, retention, "SupercompressCompactionConfig");
  const modelPolicies = resolveModelPolicies(source.modelPolicies);
  for (const [index, policy] of modelPolicies.entries()) {
    if (policy.maxTokens === undefined && source.maxTokens === undefined && policy.headroomTokens !== undefined)
      policy.maxTokens = policy.headroomTokens;
    assertPositiveInteger(
      `SupercompressCompactionConfig: modelPolicies[${index}].maxTokens (explicit or from headroomTokens)`,
      policy.maxTokens ?? maxTokens,
    );
    validateRatioRetention(
      policy.thresholdRatio ?? thresholdRatio,
      resolveRetention(policy, retention),
      `SupercompressCompactionConfig: modelPolicies[${index}]`,
    );
  }
  return deepFreeze({
    thresholdRatio,
    headroomTokens,
    ...retention,
    summarizationProvider: source.summarizationProvider ?? "",
    summarizationModel: source.summarizationModel ?? "",
    maxTokens,
    compactionRetries: source.compactionRetries ?? 1,
    maxOverflowRetries: source.maxOverflowRetries ?? 1,
    modelPolicies,
    auto: source.auto ?? true,
    // Live user-paste trim-at-production face (default OFF = the 40% band's
    // user pass stays the only user-trim path, the pre-live behavior).
    liveUserTrim: source.liveUserTrim ?? false,
    userPasteThresholdChars: source.userPasteThresholdChars ?? 8192,
    userPasteHeadChars: source.userPasteHeadChars ?? 4096,
    userPasteTailChars: source.userPasteTailChars ?? 1024,
  });
}

/** Merge one exact provider/model override over the validated default policy. */
export function resolveTargetPolicy(config, target) {
  const override = config.modelPolicies.find(
    (policy) => policy.provider === target.provider && policy.model === target.model,
  );
  const inheritedRetention =
    config.retainTokens === undefined ? { retainRatio: config.retainRatio } : { retainTokens: config.retainTokens };
  return deepFreeze({
    target: { provider: target.provider, model: target.model },
    thresholdRatio: override?.thresholdRatio ?? config.thresholdRatio,
    headroomTokens: override?.headroomTokens ?? config.headroomTokens,
    ...resolveRetention(override ?? {}, inheritedRetention),
    summarizationProvider: override?.summarizationProvider ?? config.summarizationProvider,
    summarizationModel: override?.summarizationModel ?? config.summarizationModel,
    maxTokens: override?.maxTokens ?? config.maxTokens,
    compactionRetries: override?.compactionRetries ?? config.compactionRetries,
    maxOverflowRetries: override?.maxOverflowRetries ?? config.maxOverflowRetries,
  });
}

/** Scale one routed policy into concrete token budgets for its model capacity. */
export function resolveCompactSpec(policy, contextWindow, reservedCompletionTokens) {
  const targetKey = `${policy.target.provider}/${policy.target.model}`;
  if (!Number.isInteger(contextWindow) || contextWindow <= 0)
    throw new TargetPressureConfigError(targetKey, `SupercompressCompactionConfig: contextWindow (${contextWindow}) must be a positive integer`);
  if (!Number.isInteger(reservedCompletionTokens) || reservedCompletionTokens < 0)
    throw new TargetPressureConfigError(targetKey, `SupercompressCompactionConfig: reservedCompletionTokens (${reservedCompletionTokens}) must be a non-negative integer`);
  const messageBudgetTokens = contextWindow - reservedCompletionTokens;
  if (messageBudgetTokens <= 0)
    throw new TargetPressureConfigError(
      targetKey,
      `supercompress: ${targetKey} reserves ${reservedCompletionTokens} completion tokens of its ${contextWindow}-token context window, leaving no message budget; configure the adapter model's contextWindow above the effective request maxTokens`,
    );
  const pressureBudgetTokens = messageBudgetTokens - policy.headroomTokens;
  if (pressureBudgetTokens <= 0)
    throw new TargetPressureConfigError(
      targetKey,
      `supercompress: ${targetKey} reserves ${reservedCompletionTokens} completion tokens and ${policy.headroomTokens} headroom tokens of its ${contextWindow}-token context window, leaving no pressure budget; reduce the effective request maxTokens or compaction headroomTokens, or configure a larger adapter model contextWindow`,
    );
  const thresholdTokens = Math.floor(Math.min(contextWindow * policy.thresholdRatio, pressureBudgetTokens));
  const retainTokens =
    policy.retainTokens === undefined ? Math.floor(messageBudgetTokens * policy.retainRatio) : policy.retainTokens;
  if (retainTokens >= thresholdTokens)
    throw new TargetPressureConfigError(
      targetKey,
      `SupercompressCompactionConfig: ${policy.target.provider}/${policy.target.model} retainTokens (${retainTokens}) must be less than threshold tokens ${thresholdTokens}`,
    );
  return deepFreeze({
    target: { ...policy.target },
    contextWindow,
    thresholdRatio: policy.thresholdRatio,
    thresholdTokens,
    retainTokens,
    summarizationProvider: policy.summarizationProvider,
    summarizationModel: policy.summarizationModel,
    maxTokens: policy.maxTokens,
    compactionRetries: policy.compactionRetries,
    maxOverflowRetries: policy.maxOverflowRetries,
  });
}

// ── summarizer framing (mirror of basic's compiled summarizer.ts) ────────────
const SUMMARY_OPEN_TAG = "<compacted-summary>";
const SUMMARY_CLOSE_TAG = "</compacted-summary>";
const CHECKPOINT_PREAMBLE =
  "This is an automatically generated checkpoint condensing an earlier span of the conversation to free up context. " +
  "Treat the captured context as established background and build on it without restating it. " +
  "Continue the task directly from the messages that follow, without acknowledging this checkpoint.";

/**
 * Wrap raw summary blocks in the durable checkpoint framing (basic's frameSummary
 * re-exported; the seam's `compactCheckpointSource` + `ManualCompactionError`
 * are imported, not rewritten).
 * @param {Array} summary safe text-only model output blocks.
 * @returns {Array} content for the synthesized replacement user message.
 */
export function frameSummary(summary) {
  return [
    { type: "text", text: `${CHECKPOINT_PREAMBLE}\n\n${SUMMARY_OPEN_TAG}` },
    ...summary,
    { type: "text", text: SUMMARY_CLOSE_TAG },
  ];
}

// ── region helpers (mirror of basic's compiled region.ts) ────────────────────
/** Rejects a summary whose replacement boundaries no longer match. */
export class SurfaceChangedError extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "SurfaceChangedError";
  }
}

/** The `system/message` at surface node 0, or undefined without one. */
function systemHead(session, headSeq) {
  const head = session.eventAt(headSeq);
  return head.type === "system/message" ? head : undefined;
}

/**
 * Resolve the next range starting at the first non-system surface node while
 * retaining a priced recent tail and never splitting an assistant tool
 * call/result pair. (basic's selectCompactableRange, self-written.)
 *
 * protectMode (the 4-band redesign, optional 4th argument):
 *   - "all"   (the 50% band): start AFTER the LAST compact checkpoint — every
 *             prior bound page is protected; only the NEW tail since the last
 *             checkpoint is shadowed (the incremental 装订; prior pages are
 *             NEVER re-covered/merged).
 *   - "first" (the 70% band): start AFTER the FIRST compact checkpoint — only
 *             the p1 anchor is protected; p2..pn stay in the span as the
 *             LLM-combine inputs.
 *   - undefined/null: the baseline firstIdx rule (byte-identical to the
 *             pre-redesign behavior — the 90% handoff, the 40% preclean, and
 *             the host-native paths keep calling with 3 args).
 * A checkpoint = a surface node whose source is the host's `compact-checkpoint`
 * kind (isCompactCheckpointSource; the durable user/message the region
 * transaction commits at each compact). With no checkpoints on the surface the
 * modes are no-ops (the range is identical to the baseline).
 */
export function selectCompactableRange(session, measurement, retainTokens, protectMode) {
  const pricedNodes = measurement.nodes;
  if (pricedNodes.length === 0) return null;
  const surfaceNodes = session.surface.nodes;
  if (surfaceNodes.length !== pricedNodes.length || surfaceNodes.some((seq, index) => seq !== pricedNodes[index]?.seq))
    throw new Error("compaction: token-meter surface does not match the current session surface");
  let firstIdx = systemHead(session, surfaceNodes[0]) === undefined ? 0 : 1;
  if (protectMode === "all" || protectMode === "first") {
    const cpIdx = [];
    for (let i = 0; i < surfaceNodes.length; i += 1) {
      const ev = session.eventAt(surfaceNodes[i]);
      const d = ev?.data;
      // The in-memory user/message carries the checkpoint source on the
      // message (`data.message.source` — what makeCheckpointMessage stamps);
      // some paths expose the durable flat shape (`data.source`).
      const src = d?.message?.source ?? d?.source;
      // The host predicate is not null-safe (it reads .kind directly) —
      // guard the no-source nodes (the vast majority).
      if (src && isCompactCheckpointSource(src)) cpIdx.push(i);
    }
    if (cpIdx.length > 0) {
      const anchor = protectMode === "all" ? cpIdx[cpIdx.length - 1] : cpIdx[0];
      firstIdx = Math.max(firstIdx, anchor + 1);
    }
    // Defensive: the protected start must be a balanced tool-pair boundary
    // (the compact transaction commits at balanced boundaries, so the
    // checkpoint's successor normally IS one; advance rather than split a
    // pair). The baseline path skips this walk (byte-stable).
    while (firstIdx < pricedNodes.length && !toolPairingBalancedBefore(session, surfaceNodes[firstIdx]))
      firstIdx += 1;
  }
  let accumulated = 0;
  let keepFromIdx = pricedNodes.length;
  for (let index = pricedNodes.length - 1; index >= 0; index -= 1) {
    accumulated += pricedNodes[index].tokens;
    keepFromIdx = index;
    if (accumulated >= retainTokens) break;
  }
  if (keepFromIdx <= firstIdx) return null;
  while (keepFromIdx > firstIdx) {
    if (toolPairingBalancedBefore(session, surfaceNodes[keepFromIdx])) break;
    keepFromIdx -= 1;
  }
  if (keepFromIdx <= firstIdx) return null;
  return { start: surfaceNodes[firstIdx], end: surfaceNodes[keepFromIdx - 1] };
}

/** Recheck the durable compaction lock after an asynchronous policy decision. */
export function assertNoActiveCompaction(session, stage) {
  const entryState = inspectCompactionEntryState(session);
  assertCompactionInactive(entryState.unmatchedCompactionStart, entryState.latestEndSeedSeq, stage);
}

function assertCompactionInactive(unmatchedCompactionStart, latestEndSeedSeq, stage) {
  if (
    unmatchedCompactionStart === undefined ||
    (latestEndSeedSeq !== undefined && latestEndSeedSeq > unmatchedCompactionStart.seq)
  )
    return;
  throw new ManualCompactionError(
    "busy",
    `${stage}: compaction already in progress; the session compaction lock is already active`,
  );
}

/** Validate one requested surface-position span before async work begins. */
function validateSurfaceRegion(session, start, end) {
  const nodes = session.surface.nodes;
  const startIdx = nodes.indexOf(start);
  const endIdx = nodes.indexOf(end);
  if (startIdx === -1) throw new Error(`compactRegion: start seq ${start} not found in surface`);
  if (endIdx === -1) throw new Error(`compactRegion: end seq ${end} not found in surface`);
  if (startIdx > endIdx)
    throw new Error(`compactRegion: start seq ${start} (position ${startIdx}) is after end seq ${end} (position ${endIdx}) on the surface`);
  if (!toolPairingBalancedBefore(session, nodes[startIdx]))
    throw new Error(`compactRegion: start seq ${start} is not a balanced boundary (would split a step's tool-call/result pair)`);
  if (!toolPairingBalancedAfter(session, nodes[endIdx]))
    throw new Error(`compactRegion: end seq ${end} is not a balanced boundary (would split a step, or the step is still open)`);
  return { start, end, startIdx, endIdx, shadowedSeqs: nodes.slice(startIdx, endIdx + 1) };
}

/** Snapshot pricing + replay input for a validated surface range. */
function prepareCompaction(dependencies, session, selection) {
  const measurement = dependencies.meter.measure(session);
  const selectedNodes = measurement.nodes.slice(selection.startIdx, selection.endIdx + 1);
  if (selectedNodes.length !== selection.shadowedSeqs.length || selectedNodes.some((node, index) => node.seq !== selection.shadowedSeqs[index]))
    throw new SurfaceChangedError("compaction: selected surface changed before summarization began");
  return {
    ...selection,
    measurement,
    selectedNodes,
    shadowedTokenCount: selectedNodes.reduce((total, node) => total + node.heuristicTokens, 0),
    shadowedRouteTokenCount: selectedNodes.reduce((total, node) => total + node.tokens, 0),
    input: buildSummarizationInput(session, selection.shadowedSeqs),
  };
}

/** Run the summarizer and frame its replacement checkpoint. */
async function summarizeCompaction(dependencies, prepared, agent, compactionId, sourceCommandId, assertStable, signal) {
  let summaryResult;
  for (;;) {
    signal?.throwIfAborted();
    try {
      summaryResult = await dependencies.summarize(prepared.input, agent, signal);
      break;
    } catch (error) {
      if (signal?.aborted === true) throw error;
      assertStable(dependencies, agent.session, prepared);
      if (!dependencies.recover(error, agent, prepared.shadowedSeqs, signal)) throw error;
      prepared = prepareCompaction(dependencies, agent.session, validateSurfaceRegion(agent.session, prepared.start, prepared.end));
    }
  }
  const checkpointMessage = makeCheckpointMessage(frameSummary(summaryResult.summary), compactionId, sourceCommandId);
  const framedSummaryTokenCount = dependencies.meter.estimateMessage(checkpointMessage);
  if (framedSummaryTokenCount >= prepared.shadowedRouteTokenCount)
    throw new Error(`summary is not smaller than the shadowed content (${framedSummaryTokenCount} estimated framed tokens >= ${prepared.shadowedRouteTokenCount})`);
  return { ...prepared, ...summaryResult, checkpointMessage };
}

/** Reject a summary prepared against any earlier surface generation. */
function assertWholeSurfaceUnchanged(dependencies, session, prepared) {
  if (!isDeepStrictEqual(dependencies.meter.measure(session).nodes, prepared.measurement.nodes))
    throw new SurfaceChangedError("compaction: session surface changed during summarization");
}

/** Require only that the selected span remain the same present, contiguous, equally priced, balanced target. */
function assertSelectedSpanStable(dependencies, session, prepared) {
  let current;
  try {
    current = validateSurfaceRegion(session, prepared.start, prepared.end);
  } catch (error) {
    throw new SurfaceChangedError("compaction: the selected span is no longer a valid replacement target", { cause: error });
  }
  if (!isDeepStrictEqual([...current.shadowedSeqs], [...prepared.shadowedSeqs]))
    throw new SurfaceChangedError("compaction: the selected span changed during summarization");
  if (!isDeepStrictEqual(dependencies.meter.measure(session).nodes.slice(current.startIdx, current.endIdx + 1), prepared.selectedNodes))
    throw new SurfaceChangedError("compaction: the selected span was rewritten during summarization");
}

/** Append one completed summary record + replacement body without yielding. */
function commitCompactionBody(session, startEvent, summarized) {
  const { start, end, shadowedSeqs, shadowedTokenCount, summary, provider, model, maxTokens, usage, checkpointMessage } = summarized;
  const callRecord =
    summarized.llmStreamCall === true
      ? { rawOutput: summarized.rawOutput, llmStreamCall: true }
      : summarized.rawOutput === undefined
        ? {}
        : { rawOutput: summarized.rawOutput };
  const summaryEvent = session.append("compaction/summary", {
    compactionId: startEvent.data.compactionId,
    ...(startEvent.data.sourceCommandId === undefined ? {} : { sourceCommandId: startEvent.data.sourceCommandId }),
    summary,
    ...callRecord,
    shadowedRange: { start, end },
    shadowedSeqs: [...shadowedSeqs],
    shadowedTokenCount,
    provider,
    model,
    ...(maxTokens === undefined ? {} : { maxTokens }),
    ...(usage === undefined ? {} : { usage }),
  });
  session.append("user/message", checkpointMessage, {
    surfaceOp: { op: "replace", startSeq: start, endSeq: end },
    sourceEventSeqs: [startEvent.seq, summaryEvent.seq, ...shadowedSeqs],
  });
  return {
    compactionId: startEvent.data.compactionId,
    ...(startEvent.data.sourceCommandId === undefined ? {} : { sourceCommandId: startEvent.data.sourceCommandId }),
    startSeq: startEvent.seq,
    summarySeq: summaryEvent.seq,
    summary,
    shadowedRange: { start, end },
    shadowedSeqs: [...shadowedSeqs],
    shadowedTokenCount,
  };
}

function completeCompaction(pending, endEvent) {
  return { ...pending, endSeq: endEvent.seq };
}

/** Reconstruct the last routed request's cacheable prefix for the shadowed region. */
function buildSummarizationInput(session, shadowedSeqs) {
  const header = session.requestHeader();
  const head = systemHead(session, session.surface.nodes[0]);
  const system = head === undefined ? null : session.deriveEventMessage(head);
  const regionMessages = shadowedSeqs.map((seq) => session.deriveEventMessage(session.eventAt(seq))).filter((message) => message !== null);
  return {
    ...(header?.tools === undefined ? {} : { tools: header.tools }),
    messages: system === null ? regionMessages : [system, ...regionMessages],
  };
}

/** Inspect open-turn, unmatched-compaction, and latest seed-boundary state. */
function inspectCompactionEntryState(session) {
  let openTurn = null;
  let openTurnStateKnown = false;
  let unmatchedCompactionStart;
  let compactionEntryStateKnown = false;
  let latestEndSeedSeq;
  for (let seq = session.seq - 1; seq >= 0; seq -= 1) {
    const event = session.eventAt(seq);
    if (latestEndSeedSeq === undefined && event.type === "session/end-seed") latestEndSeedSeq = event.seq;
    if (!compactionEntryStateKnown) {
      if (event.type === "compaction/start") {
        unmatchedCompactionStart = event;
        compactionEntryStateKnown = true;
      } else if (event.type === "compaction/end") compactionEntryStateKnown = true;
    }
    if (!openTurnStateKnown) {
      if (event.type === "turn/start") {
        openTurn = event.data.turn;
        openTurnStateKnown = true;
      } else if (event.type === "turn/end") openTurnStateKnown = true;
    }
    if (openTurnStateKnown && compactionEntryStateKnown && latestEndSeedSeq !== undefined) break;
  }
  return { openTurn, unmatchedCompactionStart, latestEndSeedSeq };
}

function throwManualFailure(failure) {
  if (failure.stage === "commit")
    throw new ManualCompactionError("commit", "manual compaction did not commit cleanly", { cause: failure.error });
  if (failure.error instanceof SurfaceChangedError)
    throw new ManualCompactionError("changed", "the compacted history changed during manual compaction", { cause: failure.error });
  throw new ManualCompactionError("summary", "manual compaction could not produce a smaller summary", { cause: failure.error });
}

/**
 * Synthesize the durable checkpoint replacement user message. basic builds it via
 * `@deepseek-ai/dsh-llm`'s `createUserMessage({ content, source })`; that helper
 * is NOT importable from this shell's scope without pulling dsh-llm into the
 * zero-dep region helper, so we emit the same shape the host's session.append
 * accepts: a user-role message carrying the checkpoint `source` (the seam's
 * `compactCheckpointSource`) so the durable checkpoint framing is byte-identical.
 */
function makeCheckpointMessage(content, compactionId, sourceCommandId) {
  return {
    role: "user",
    content,
    source: compactCheckpointSource(compactionId, sourceCommandId),
    // v4 open-time admission (assertMessageEventShape) requires a non-empty id
    // on every user/message; the host's createUserMessage stamps randomUUID(),
    // so we mirror it (the byte-identity claim holds: host shape includes id).
    id: randomUUID(),
  };
}

/**
 * Run the single compaction transaction over one selected positional span.
 * (basic's compactSurfaceRegion, self-written; fixed strategy — the 0-LLM tier
 * does not change the durable-mutation / lock / shrink validation.)
 */
export async function compactSurfaceRegion(dependencies, session, start, end, agent, options, signal) {
  if (options.owner === null) signal?.throwIfAborted();
  const selection = validateSurfaceRegion(session, start, end);
  const entryState = inspectCompactionEntryState(session);
  assertCompactionInactive(entryState.unmatchedCompactionStart, entryState.latestEndSeedSeq, "compaction");
  let owner;
  if (options.owner === null) {
    if (entryState.openTurn !== null)
      throw new ManualCompactionError("busy", "manual compaction: the session already has an open turn");
    owner = null;
  } else {
    if (entryState.openTurn === null)
      throw new Error("compactRegion: no open turn — automatic compaction events must be enclosed in a turn");
    owner = entryState.openTurn;
  }
  const compactionId = CompactionId(randomUUID());
  const lifecycle = {
    compactionId,
    ...(options.sourceCommandId === undefined ? {} : { sourceCommandId: options.sourceCommandId }),
    turn: owner,
  };
  const startEvent = session.append("compaction/start", lifecycle);
  const assertStable = options.stability === "whole-surface" ? assertWholeSurfaceUnchanged : assertSelectedSpanStable;
  let failure;
  let flushFailure;
  let result;
  let closed = false;
  let closing = false;
  let stage = "summary";
  try {
    const summarized = await summarizeCompaction(
      dependencies,
      prepareCompaction(dependencies, session, selection),
      agent,
      compactionId,
      options.sourceCommandId,
      assertStable,
      signal,
    );
    if (options.owner === null) signal?.throwIfAborted();
    assertStable(dependencies, session, summarized);
    stage = "commit";
    const pending = commitCompactionBody(session, startEvent, summarized);
    closing = true;
    const endEvent = session.append("compaction/end", lifecycle);
    closed = true;
    result = completeCompaction(pending, endEvent);
  } catch (error) {
    failure = { error, stage: closing ? "commit" : stage };
    if (!closing) {
      closing = true;
      try {
        session.append("compaction/end", {
          ...lifecycle,
          error: describeError(error),
        });
        closed = true;
      } catch (closeError) {
        failure = { error: closeError, stage: "commit" };
      }
    }
  }
  if (closed && options.flush !== undefined) {
    try {
      await options.flush();
    } catch (error) {
      flushFailure = error;
    }
  }
  if (options.owner === null) signal?.throwIfAborted();
  if (failure !== undefined) {
    if (options.owner === null) throwManualFailure(failure);
    throw failure.error;
  }
  if (flushFailure !== undefined)
    throw new ManualCompactionError("persistence", "manual compaction durability checkpoint failed", { cause: flushFailure });
  if (result === undefined) throw new Error("compaction committed without a result");
  return result;
}

/**
 * A plain, host-independent error-chain descriptor used in the durable
 * `compaction/end` failure record. basic uses dsh-llm's `errorChain`; we emit
 * the same `{name,message}` shape without importing dsh-llm here.
 */
function describeError(error) {
  const out = [];
  let e = error;
  let depth = 0;
  while (e && depth < 8) {
    out.push({ name: e.name ?? "Error", message: String(e.message ?? e) });
    e = e.cause;
    depth += 1;
  }
  return out;
}
