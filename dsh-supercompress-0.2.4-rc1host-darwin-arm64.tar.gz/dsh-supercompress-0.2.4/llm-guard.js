// llm-guard.js — host-generation-tolerant DI accessors + the variant switch.
//
// WHY: the host's LLM + token-meter faces (`ctx.llm` via dsh-llm, `ctx.tokenMeter`
// via dsh-token-meter) are OPTIONAL per host-generation / per profile. A host
// (or a profile on a host) may not resolve all of them. The 0.2.4 design is
// PER-FACE GRACEFUL:
//   - the static `inject` is the ACTIVATION GATE ONLY (["tools"] / ["sessions"]
//     — always present), so the data-plane / tools face is never taken down by
//     a missing optional token (the all-or-nothing risk of the 0.2.3 full-face
//     inject is gone).
//   - the LLM + meter faces are resolved at the call site via the DI CONTAINER
//     lookup `ctx.get("llm")` / `ctx.get("tokenMeter")` (see safeLlm /
//     safeTokenMeter) — it returns the live service when the host registers it,
//     `undefined` otherwise (the floor). A property read (`ctx.llm`) is kept as
//     a fallback for test fakes + hosts that statically inject the token.
//
// (The earlier "rc.1 has no llm/tokenMeter DI tokens" claim was UNVERIFIED /
// wrong: the rc.1 host ships dsh-llm + dsh-token-meter, so the faces DO
// resolve on rc.1 — they just floor only if a token is genuinely absent.)
//
// ZERO new runtime deps (node stdlib only). Pure functions, safe on both
// generations, safe in the dev / untransformed build (see isLegacyInject).

// Safe read of the host LLM runtime (the `llm` service).
//
// 0.2.4 dual-path (per-face graceful): prefer the DI CONTAINER lookup
// `ctx.get("llm")` — it resolves the host's llm service even when "llm" is NOT
// in the static `inject` (the gate-only variant; the host registers llm via
// dsh-llm, exactly like dsh-token-meter does `ctx.get("llm")`). Fall back to
// the property read `ctx.llm` for test fakes + hosts that still statically
// inject the token. Both legs are miss-safe: the floor is `undefined`.
export function safeLlm(ctx) {
  if (!ctx) return undefined;
  const viaGet = safeGet(ctx, "llm");
  if (viaGet) return viaGet;
  try {
    return ctx.llm;
  } catch {
    return undefined;
  }
}

// Safe read of the host token meter (the `tokenMeter` service). 0.2.4: the
// same dual-path as safeLlm (the container lookup primary, the property
// read fallback).
export function safeTokenMeter(ctx) {
  if (!ctx) return undefined;
  const viaGet = safeGet(ctx, "tokenMeter");
  if (viaGet) return viaGet;
  try {
    return ctx.tokenMeter;
  } catch {
    return undefined;
  }
}

// Safe generic DI lookup (the `ctx.get(name)` method accessor — already
// miss-safe, but guard against a host whose get() throws on unknown tokens).
export function safeGet(ctx, name) {
  if (!ctx || typeof ctx.get !== "function") return undefined;
  try {
    return ctx.get(name);
  } catch {
    return undefined;
  }
}

// ── the host-generation variant switch (the dist packager's esbuild define) ──
// The closed-source dist ships two builds of this shell (KB tutorial pit 13:
// 代际双构建用 define 开关, 不 fork 代码):
//   - the FULL variant     : esbuild --define:__SC_LEGACY=false (rc.5+ host)
//   - the RC1HOST variant  : esbuild --define:__SC_LEGACY=true  (rc.1 host)
// In the dev / untransformed build the identifier is undeclared, so
// `typeof __SC_LEGACY` is "undefined" (typeof is safe on an undeclared
// identifier — no ReferenceError) and isLegacyInject is false = the FULL
// behavior. The packager's esbuild --define replaces every `__SC_LEGACY`
// reference with the literal, flipping the switch per variant.
export const isLegacyInject = (() => {
  try {
    return typeof __SC_LEGACY !== "undefined" && __SC_LEGACY === true;
  } catch {
    return false;
  }
})();
