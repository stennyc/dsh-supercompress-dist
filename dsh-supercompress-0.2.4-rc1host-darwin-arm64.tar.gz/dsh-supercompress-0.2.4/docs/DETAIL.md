# Supercompress

Supercompress turns a long, over-budget DSH conversation into a compact, durable context store, then puts back only what the current turn actually needs. It is a context-engine: it compresses without destroying data, and it recalls without spending token budget on LLM calls you do not need.

## What it does

- **Reversible compression.** Each session turn is distilled into tiered bands (P0 decision → P1 → P2). Low-value turns are evicted from the live window into a durable source-of-truth file. Eviction is *write-before-compress* (fsync + read-back), so the original text is always retrievable. Nothing is destroyed.
- **On-demand recall.** When you need earlier context, Supercompress re-injects the most relevant turns via BM25 (with P0 boost, CJK-aware tokenization, and stale down-weighting) as a single pre-step — no extra LLM round-trips.
- **Zero-LLM resident path.** The data plane is offline and LLM-free: compression, eviction, dedup, and recall all run without model calls. LLM is touched only by the optional gate-fired rerank and the 55%-band digest, and every such call fails open.
- **Crash- and restart-safe.** A Go data-plane daemon (scd) owns the store. Lazy 256 KB batching caps loss to a single batch, and recall reuse persists across restarts through a sidecar.

## How it plugs in

- A thin TypeScript shell mounts on the host Cordis session (entry bundle.js); the Go daemon handles the data plane over IPC.
- Behavior is tunable from the Settings card (compaction, tiering, 55-band, live ledger, host backfill, recall reuse), so you can dial the aggressiveness without touching code.

> Port of the hermes-agent supercompress context engine to the DSH Cordis plugin model: Go data plane + thin TypeScript shell, 168 tests green (87 Go + 81 shell).
