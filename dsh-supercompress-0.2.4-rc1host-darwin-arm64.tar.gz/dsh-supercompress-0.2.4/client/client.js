// @stennyc/dsh-supercompress — the browser half: the bundle's own settings
// page on the Web GUI's Plugins page (the `plugins.bundle.config` slot,
// keyed by the bundle package name). Shipped in the built-client form the
// module loader serves under /plugins (a lazy-CJS factory; `require` answers
// against the platform module table — jsx-runtime + the settings primitives
// are baseline, no per-bundle install).
//
// The page is the OFFICIAL settings-form pattern (dsh-client-ui-settings):
// the host's settings service projects this profile entry's VOLATILE fields
// into a staged form; the host owns persistence (the active profile patch,
// validated, serialized, stale writes refused) and the live commit of
// volatile-only saves — so editing a knob here updates it in place,
// no restart. The engine re-reads the value on every call.
//
// Managed fields (the official primitives render them): the number fields
// (capacityRatio, hostPressureFactor) via settingsNumberField, and the
// boolean knobs (enableCompaction, enable40PreDigest, liveUserTrim,
// persistUserTurns, hostBackfill) via settingsTextField + a parse/format
// (enable55Band left the card at 4-band redesign step 3 — consolidated into
// enable40PreDigest; enableLedger was retired 2026-11-24 as a zero-consumption
// dead knob; the schema still carries both for row-config backward compat).
// The auto-recall face's knobs (k, rerankLowScoreThreshold, dropModelOnGate,
// enableRecall, recallMaxChars, selfContentRecent) left with the face's
// retirement (owner ruling 2026-11-27: clean sweep, no card rows).
// pair (no boolean/switch builder ships, so a bool rides the text field;
// `format` renders it, `parse` writes a real boolean — forge worktree pattern).
window.__ModuleLoader__.load({
  id: "@stennyc/dsh-supercompress",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
    const { jsx, jsxs } = require("react/jsx-runtime");
    const P = require("@deepseek-ai/dsh-client-ui-primitives");

    // The profile entry id of the bundle's row (cordis.patch.yml `id:`) — the
    // settings service addresses forms by entry id.
    const ENTRY = "dsh-supercompress";
    const PKG = "@stennyc/dsh-supercompress";
    const NS = "settings.supercompress";

    const en = {
      title: "Supercompress",
      description: "Context-memory compaction gate for the dsh-supercompress bundle.",
      capacityTokens: "Window capacity (tokens) [deprecated — use Ledger capacity ratio]",
      capacityTokensHint:
        "DEPRECATED: superseded by the 'Ledger capacity ratio' knob (the data-plane ledger capacity as a fraction of the host context window, O(1) live). The absolute override path now lives in the env DASHSC_CAPACITY. This field is hidden from the card; a row that still sets it wins as the highest-priority absolute override in resolveDistillCapacity. Applies live — no restart.",
      capacityRatio: "Ledger capacity ratio (× host window)",
      capacityRatioHint:
        "A2: the data-plane ledger capacity as a fraction of the HOST context window (live, O(1) tokenMeter read): capacity = contextWindow × ratio. Default 0.5 (the ledger carries half the host window). The absolute 'Window capacity' field or the env DASHSC_CAPACITY override this fraction. Applies live — no restart.",
      hostPressureFactor: "Host soft-pressure factor",
      hostPressureFactorHint:
        "When the host's measured used/window reaches this, run an extra data-plane distill pass between host compacts. Applies live — no restart.",
      thresholdRatio: "Compaction trigger ratio",
      thresholdRatioHint:
        "Compact when used/window >= this fraction. Default 0.8 (host default); the web row runs 0.5. 0–1. Applies live — no restart.",
      headroomTokens: "Compaction headroom (tokens)",
      headroomTokensHint:
        "Token headroom reserved for the compaction output + request overflow. Default 65536; the web row runs 32768. Non-negative integer. Applies live — no restart.",
      retainRatio: "Compaction retain ratio",
      retainRatioHint:
        "Fraction of recent context to keep verbatim after each compact (verbatim-tail). Must be < thresholdRatio. Default 0.16 (host default); the web row runs 0.2. 0–1. Applies live — no restart.",
      compactionAuto: "Auto compaction",
      compactionAutoHint:
        "Enable automatic step-boundary pressure + overflow-recovery compaction (the host compaction row's `auto`). (true/false) Default true. Applies live — no restart.",
      enableCompaction: "P0 compaction gate",
      enableCompactionHint:
        "Write-before-compress: persist P0 turns + emit anchors on the data plane before the host shadows a region. (true/false) Applies live — no restart.",
      enable40PreDigest: "40% pre-digest (batched LLM)",
      enable40PreDigestHint:
        "At the 40% waterline (the 'clean the room' band), digest this session's not-yet-digested model turns into rich ledger digests in ONE batched LLM call (warm prefix, ledger bypass, idempotent per session) — so the 50% band's bind reads ready pages instead of head80 stubs. Supersedes the old 55-band + tiering faces. (true/false) Applies live — no restart.",
      persistUserTurns: "Persist user turns",
      persistUserTurnsHint:
        "Ingest user turns into the P0 store. (true/false) Applies live — no restart.",
      hostBackfill: "Host backfill",
      hostBackfillHint:
        "At session open, backfill prior durable user turns from the host's native log. (true/false) Applies live — no restart.",
      userSource: "User-turn source",
      userSourceLive: "live (ingest at splice)",
      userSourceHost: "host (zstd session log)",
      userSourceHint:
        "Where user turns are sourced: live = splice-time ingest; host = the host's native zstd log. Pick live or host from the dropdown. Applies live — no restart.",
      enableLedger: "Live ledger (phase supersede) [retired — no longer consumed]",
      enableLedgerHint:
        "RETIRED: the B-tier bare engine (0 LLM, no host-LLM phase-supersede) has ZERO consumption points in bundle.js for this field — a dead knob from the basic-inheritance era. Hidden from the card; the schema still carries it for row-config backward compatibility, but it does nothing.",
      enableCompactLedger: "Compact ledger (host consumer) [low-frequency / opt-in]",
      enableCompactLedgerHint:
        "When on, each host compact stages this cycle's evicted P1/P2 block into the bounded cumulative <sid>.compact.json ledger (trimmable-fold -> settled -> seal). Opt-in; default off. Applies live — no restart.",
      // ── card refactor 2026-11-26: the four per-band waterline switches +
      // the cache-keeper master + the section titles ──
      enableBand90: "90% band · handoff (0-LLM)",
      enableBand90Hint:
        "Highest waterline: at used/window >= 90% the 0-LLM handoff face runs. OFF = skip this band; the switch falls through to the 70% band. Live, no restart.",
      enableBand70: "70% band · LLM paged compaction",
      enableBand70Hint:
        "The only LLM band: at >= 70% the paged LLM compaction runs. OFF = skip; falls through to the 50% band. Live, no restart.",
      enableBand50: "50% band · ledger bind (0-LLM)",
      enableBand50Hint:
        "At >= 50% the 0-LLM ledger bind runs (the checkpoint composes from the pre-digested rich digests, no host LLM). OFF = skip; falls through to the 40% band. Live, no restart.",
      enableBand40: "40% band · preclean + pre-digest (0-LLM)",
      enableBand40Hint:
        "Earliest waterline: at >= 40% the deterministic preclean (tool-result prune + user long-paste middle-trim) plus the batched LLM pre-digest run. OFF = skip (below 40% stays host-native). Live, no restart.",
      cacheKeeper: "Prefix-cache keepalive (cache-keeper)",
      cacheKeeperHint:
        "Keep this session's gateway prefix cache warm while idle: a maxTokens=1 replay of the session's last main-request prefix every 45s of idle (a session idle > 30min is presumed dead, its record releases, nothing burns). ON = enabled. Live, no restart.",
      secBands: "Compaction waterlines (band switches)",
      secTrim: "Trim-at-production",
      secCache: "Cache keepalive",
      secData: "Data plane",
      secUser: "User turns & recall",
      unavailable: "This plugin is not loaded, so it cannot be configured right now.",
      readOnly: "This deployment stores settings read-only.",
      save: "Save",
      saving: "Saving…",
      saveFailed: "The deployment did not accept these values; they were left for you to correct.",
      invalidNumber: "Enter a number, or leave blank to use the default.",
      invalidValue: "Enter a valid value (true / false, or the option name), or leave blank.",
      overridden: "Overridden",
      reset: "Reset to default",
    };
    const zh = {
      title: "Supercompress",
      description: "dsh-supercompress 的上下文记忆压缩门控。",
      capacityTokens: "窗口容量（token）[已弃用 — 改用 台账容量比例]",
      capacityTokensHint:
        "已弃用：被「台账容量比例」旋钮取代（数据面台账容量 = 宿主 contextWindow × 此比例，O(1) 活读）。绝对值覆盖路径现走 env DASHSC_CAPACITY。此字段已从卡片隐藏；行 config 若仍设它，作为 resolveDistillCapacity 的最高优先绝对值覆盖仍生效。热生效，无需重启。",
      capacityRatio: "台账容量比例（× 宿主窗口）",
      capacityRatioHint:
        "A2：数据面台账容量 = 宿主 contextWindow × 此比例（live O(1) tokenMeter 读口）。默认 0.5（台账带走宿主窗口一半）。绝对值“窗口容量”字段或 env DASHSC_CAPACITY 可覆盖此比例。热生效，无需重启。",
      hostPressureFactor: "宿主软压力系数",
      hostPressureFactorHint:
        "宿主 measured used/window 达到此值时，在两次宿主压缩之间多跑一次数据面降档。热生效，无需重启。",
      thresholdRatio: "压缩触发比例",
      thresholdRatioHint:
        "used/window 达到此比例时触发压缩。默认 0.8（宿主默认）；web 行跑 0.5。0–1。热生效，无需重启。",
      headroomTokens: "压缩 headroom（token）",
      headroomTokensHint:
        "为压缩输出 + 请求溢出预留的 token headroom。默认 65536；web 行跑 32768。非负整数。热生效，无需重启。",
      retainRatio: "压缩保留比例",
      retainRatioHint:
        "每次压缩后逐字保留的近期上下文比例（verbatim-tail）。须 < thresholdRatio。默认 0.16（宿主默认）；web 行跑 0.2。0–1。热生效，无需重启。",
      compactionAuto: "自动压缩",
      compactionAutoHint:
        "开启自动步骤边界压力 + 溢出恢复压缩（宿主压缩行的 `auto`）。（true/false）默认 true。热生效，无需重启。",
      enableCompaction: "P0 压缩闸",
      enableCompactionHint: "写前压：宿主 shadow 前，数据面先落 P0 原文 + 出锚点。（true/false）热生效，无需重启。",
      enable40PreDigest: "40% 预消化（成批 LLM）",
      enable40PreDigestHint: "40% 水位（打扫房间档）时，把本会话尚未消化的模型段一次性成批 LLM 消化成富 ledger digest（骑热前缀、ledger 旁路、per-session 幂等）——让 50% 装订读到现成富 page 而非 head80 存根。取代原 55-band + tiering 两个面。（true/false）热生效，无需重启。",
      persistUserTurns: "持久化用户轮",
      persistUserTurnsHint: "用户轮是否落 P0 store。（true/false）热生效，无需重启。",
      hostBackfill: "宿主回灌",
      hostBackfillHint: "session 开时从宿主原生日志回灌历史用户轮。（true/false）热生效，无需重启。",
      userSource: "用户轮来源",
      userSourceLive: "live（splice 时摄取）",
      userSourceHost: "host（宿主 zstd 日志）",
      userSourceHint: "用户轮来源：live = splice 时摄取；host = 宿主 zstd 日志。从下拉菜单选 live 或 host。热生效，无需重启。",
      enableLedger: "活账本（阶段 supersede）[已退役 — 不再消费]",
      enableLedgerHint: "已退役：B 档裸引擎（0 LLM，无宿主 LLM 阶段 supersede）在 bundle.js 对此字段有 0 个消费点——basic 继承链遗留的死旋钮。已从卡片隐藏；schema 仍保留它作行 config 向后兼容，但实际无效。",
      enableCompactLedger: "紧凑账本（宿主消费面）[低频/可选]",
      enableCompactLedgerHint: "开启后，每次宿主 compact 把本轮逐出的 P1/P2 块暂存进有界累计 <sid>.compact.json 账本（trimmable 折存根 → settled → seal 兜底）。可选项，默认关。热生效，无需重启。",
      // ── 卡片重构 2026-11-26：四档水位开关 + 缓存保活主开关 + 分区标题 ──
      enableBand90: "90% 档 · 交接（0-LLM）",
      enableBand90Hint: "最高水位：used/window ≥90% 时跑 0-LLM 交接面。关 = 跳过本档，落入 70% 档。热生效，无需重启。",
      enableBand70: "70% 档 · LLM 分页压缩",
      enableBand70Hint: "唯一的 LLM 档：≥70% 时跑分页 LLM 压缩。关 = 跳过本档，落入 50% 档。热生效，无需重启。",
      enableBand50: "50% 档 · 台账装订（0-LLM）",
      enableBand50Hint: "≥50% 时跑 0-LLM 台账装订（checkpoint 从预消化富 digest 组卷，不走宿主 LLM）。关 = 跳过本档，落入 40% 档。热生效，无需重启。",
      enableBand40: "40% 档 · 预清 + 预消化（0-LLM）",
      enableBand40Hint: "最早水位：≥40% 时跑确定性预清（工具结果修剪 + user 长粘贴中间剪）+ 成批 LLM 预消化。关 = 跳过本档（<40% 走宿主原生）。热生效，无需重启。",
      cacheKeeper: "前缀缓存保活（cache-keeper）",
      cacheKeeperHint: "session 空闲时以 45s 周期重放该 session 最近主请求前缀（maxTokens=1）刷新网关前缀缓存页，防空闲逐出；空闲 >30min 视为死 session、释放记录、零燃烧。开 = 启用。热生效，无需重启。",
      secBands: "压缩水位（四档开关）",
      secTrim: "随产随裁",
      secCache: "缓存保活",
      secData: "数据面",
      secUser: "用户轮与召回",
      unavailable: "该插件当前未加载，暂时无法配置。",
      readOnly: "本部署的设置为只读。",
      save: "保存",
      saving: "保存中…",
      saveFailed: "本部署没有接受这些值，已保留供你修改。",
      invalidNumber: "请填数字；留空表示使用默认值。",
      invalidValue: "请填有效值（true / false，或选项名）；留空表示使用默认值。",
      overridden: "已覆盖",
      reset: "恢复默认",
    };

    function formLabels(t) {
      return {
        unavailable: t("unavailable"),
        readOnly: t("readOnly"),
        saveFailed: t("saveFailed"),
        save: t("save"),
        saving: t("saving"),
      };
    }

    // Typed parse for a boolean rendered through a text field: the form writes
    // a REAL boolean (schema-safe) — not the string "true"/"false".
    function boolParse(text) {
      const t = String(text == null ? "" : text).trim().toLowerCase();
      if (t === "true" || t === "1") return { kind: "set", value: true };
      if (t === "false" || t === "0") return { kind: "set", value: false };
      if (t === "") return { kind: "clear" };
      return undefined; // invalid
    }
    // The inverse of boolParse — the host field spec's `format` (value -> the
    // text the input shows). Without it a text field has NO way to render a
    // boolean: it displays blank, and the form then treats the field as
    // "empty" on Save -> boolParse("") -> {kind:"clear"} -> the value reverts
    // to empty (the "knobs revert to empty" bug). Number fields never hit this
    // because the host number builder renders numbers natively. Official pattern
    // = the forge worktree form's boolean field (format + parse together).
    function boolFormat(value) {
      if (value === true) return "true";
      if (value === false) return "false";
      return "";
    }
    /** A boolean knob through the text field: real value (schema-safe) + text render. */
    function boolField(name) {
      return { ...P.settingsTextField(name), parse: boolParse, format: boolFormat };
    }

    /** Bridges this entry's volatile form onto the page's staged form. */
    var Controller = class {
      form;
      store;
      constructor(scope) {
        this.form = new P.SettingsFormModel(scope, [
          // `capacityTokens` (absolute) is DEPRECATED from the web card 2026-11-24:
          // it is superseded by `capacityRatio` (the ledger capacity as a fraction
          // of the host context window, O(1) live tokenMeter read) as the primary
          // capacity knob. The absolute-override path now lives in the env
          // DASHSC_CAPACITY (the resolveDistillCapacity chain in bundle.js still
          // reads config.capacityTokens as the highest-priority absolute
          // override — a row that sets it still wins — but the web card no
          // longer renders it, so the visible + tuned knob is the ratio).
          P.settingsNumberField("capacityRatio"),
          P.settingsNumberField("hostPressureFactor"),
          // The compaction-engine knobs (thresholdRatio / headroomTokens /
          // retainRatio / auto) are NOT on the Supercompress main card — they
          // belong to the host compaction row, rendered from engine-bare.js's
          // z.object schema by the host's own settings form for that row.
          // The P0 compaction gate master + the four per-band waterline
          // switches (card refactor 2026-11-26). NO schema defaults on the
          // band toggles: an UNTOUCHED card field stays unset -> the engine's
          // band switch keeps the all-enabled module default; an explicit card
          // write OVERRIDES per band (the liveUserTrim card pattern, published
          // live via the bundle's band-gates getter).
          boolField("enableCompaction"),
          boolField("enableBand90"),
          boolField("enableBand70"),
          boolField("enableBand50"),
          boolField("enableBand40"),
          // The live user-paste trim-at-production face (随产随裁). NO schema
          // default on purpose: an UNTOUCHED field stays unset, and the
          // engine's live pass falls back to the ROW config's liveUserTrim
          // (the card OVERRIDES the row only when the user toggles it).
          boolField("liveUserTrim"),
          // The cache-keeper master switch (the idle prefix-cache heartbeat;
          // the ck* detail knobs stay row-config — the provider scope is the
          // row's ckProviders).
          boolField("cacheKeeper"),
          boolField("persistUserTurns"),
          boolField("hostBackfill"),
          // RETIRED (owner ruling 2026-11-27): the per-step top-k auto-recall
          // face is dead; the `enableRecall` card toggle + its projection leg
          // are gone (the row-config key loads inertly via resolveConfig, no
          // consumer).
          P.settingsTextField("userSource"),
          // ── LOW-FREQUENCY / OPT-IN knobs (grouped last; default-off or
          // rarely tuned) ──
          // `enableLedger` is RETIRED from the web card 2026-11-24: the B-tier
          // bare engine (0 LLM, no host-LLM phase-supersede) has ZERO
          // readNum/readBool/readStr consumption points in bundle.js for it
          // (grep: schema declaration only, never read by engine logic) — a
          // dead knob from the basic-inheritance era. It is removed from the
          // fields array (web no longer renders it); the schema still carries
          // it for row-config backward compatibility, but it does nothing.
          // `rerankLowScoreThreshold` / `dropModelOnGate` (the R4 rerank-gate
          // two-step reorder face, opt-in) and `enableCompactLedger` (the host
          // compact-ledger consumer, default off) are the remaining low-
          // frequency knobs, grouped here so the primary card stays clean.
        // RETIRED from the card 2026-11-26 (row-config only; the schema keeps
        // the keys for back-compat): `enable40PreDigest` (the 40% band's
        // pre-digest sub-face, subsumed by the enableBand40 switch) and the
        // low-frequency trio (`rerankLowScoreThreshold` / `dropModelOnGate` /
        // `enableCompactLedger`). `enableLedger` was already retired 2026-11-24
        // (zero consumption points; the dead basic-inheritance knob).
        ]);
        this.store = this.form.bind(() => this.projection());
      }
      projection() {
        return {
          ...this.form.shell(),
          // `capacityTokens` (absolute) is deprecated from the web card — it is
          // no longer in the `fields` array, so it is not projected here either.
          // It still rides the row config / env DASHSC_CAPACITY (the
          // resolveDistillCapacity chain in bundle.js reads it as the
          // highest-priority absolute override); the web-visible capacity knob
          // is now `capacityRatio` only.
          capacityRatio: this.form.field("capacityRatio"),
          hostPressureFactor: this.form.field("hostPressureFactor"),
          // The compaction-engine knobs (thresholdRatio / headroomTokens /
          // retainRatio / compactionAuto) are NOT projected by the main card —
          // they ride the host compaction row's own settings form (from
          // engine-bare.js's z.object schema), not this Supercompress card.
          enableCompaction: this.form.field("enableCompaction"),
          // The four per-band waterline switches (card refactor 2026-11-26).
          enableBand90: this.form.field("enableBand90"),
          enableBand70: this.form.field("enableBand70"),
          enableBand50: this.form.field("enableBand50"),
          enableBand40: this.form.field("enableBand40"),
          liveUserTrim: this.form.field("liveUserTrim"),
          cacheKeeper: this.form.field("cacheKeeper"),
          persistUserTurns: this.form.field("persistUserTurns"),
          hostBackfill: this.form.field("hostBackfill"),
          // RETIRED (owner ruling 2026-11-27): the `enableRecall` projection
          // leg is gone with its card toggle (no schema field, no consumer).
          userSource: this.form.field("userSource"),
          // `enableLedger` (retired, 0 consumption points in bundle.js) is no
          // longer in the fields array, so it is not projected here either.
        };
      }
      inject() {
        return { hooks: { supercompress: this.store }, ...this.form.actions() };
      }
      dispose() {
        this.form.dispose();
      }
    };

    /**
     * A boolean knob rendered as a toggle chip (P.Switch) instead of a text box:
     * the field label, a real on/off switch, the hint, and an "overridden" tag.
     * The switch shows the field's current draft value and, on toggle, stages a
     * "true"/"false" draft via `onEdit` — the field's `parse` (boolParse) turns
     * that back into a REAL boolean on Save. `fs` is the SettingsFieldState
     * ({ value, overridden, ... }) from the form projection.
     */
    function BoolToggleField(props) {
      const { id, label, hint, fs, disabled, onEdit, overriddenLabel, t } = props;
      // The SettingsFieldState exposes `text` (the draft string; "true"/"false"/
      // "") — NOT a `.value` boolean. Drive the switch from `text`; on toggle,
      // stage a "true"/"false" draft (the field's `parse` writes the real boolean
      // on Save).
      const on = fs.text === "true";
      return jsxs("div", {
        id: id,
        style: { display: "flex", flexDirection: "column", gap: 4 },
        children: [
          jsxs("div", {
            style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 },
            children: [
              jsx("span", { style: { flex: 1, minWidth: 0 }, children: label }),
              jsxs("span", {
                style: { display: "inline-flex", alignItems: "center", gap: 6 },
                children: [
                  fs.overridden ? jsx(P.Tag, { tone: "neutral", children: overriddenLabel }) : null,
                  jsx(P.Switch, {
                    checked: on,
                    label: label,
                    disabled: disabled,
                    onChange: (next) => onEdit(next ? "true" : "false"),
                  }),
                ]
              }),
            ]
          }),
          hint ? jsx("p", { style: { margin: 0, fontSize: "0.85em", opacity: 0.7 }, children: hint }) : null,
        ]
      });
    }

    /**
     * An enum knob rendered as a native dropdown (a <select> — the official
     * field builders ship only number / text / secret, no select builder,
     * so a dropdown rides the TEXT field's channel: the draft value is the
     * raw option string; the schema's z.union([z.const("live"), z.const(
     * "host")]) validates on Save, and the row config's value shows when the
     * field is untouched (the schema default "live" renders when unset)).
     */
    function UserSourceSelectField(props) {
      const { id, label, hint, fs, disabled, onEdit, overriddenLabel, t } = props;
      // The SettingsFieldState exposes `text` (the draft string) — the select
      // mirrors it: an empty draft falls back to the schema default display.
      const value = fs.text === "host" ? "host" : "live";
      return jsxs("div", {
        id: id,
        style: { display: "flex", flexDirection: "column", gap: 4 },
        children: [
          jsxs("div", {
            style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 },
            children: [
              jsx("span", { style: { flex: 1, minWidth: 0 }, children: label }),
              jsxs("span", {
                style: { display: "inline-flex", alignItems: "center", gap: 6 },
                children: [
                  fs.overridden ? jsx(P.Tag, { tone: "neutral", children: overriddenLabel }) : null,
                  jsx("select", {
                    value,
                    disabled,
                    style: {
                      padding: "2px 6px",
                      fontSize: "0.9em",
                      border: "1px solid var(--border-primary, #8884)",
                      borderRadius: 4,
                      background: "transparent",
                      color: "inherit",
                    },
                    onChange: (e) => onEdit(e.target.value),
                    children: [
                      jsx("option", { value: "live", children: t("userSourceLive") }),
                      jsx("option", { value: "host", children: t("userSourceHost") }),
                    ],
                  }),
                ],
              }),
            ],
          }),
          hint ? jsx("p", { style: { margin: 0, fontSize: "0.85em", opacity: 0.7 }, children: hint }) : null,
        ],
      });
    }

    /** The page: the staged form with its number + boolean(toggle) + select + text fields. */
    function SupercompressPage(props) {
      const { t } = props;
      const state = props.useSupercompress((snapshot) => snapshot);
      if (state === undefined || state === null) return t("unavailable");
      const disabled = !state.writable;
      // ── card refactor 2026-11-26 (owner ruling): the card is grouped BY
      // FUNCTION into titled sections. First-class: the four per-band
      // waterline switches (90/70/50/40) + the trim-at-production toggle +
      // the cache-keeper master. RETIRED from the card (row-config only; the
      // schema keeps every key): enable40PreDigest (the 40% band's pre-digest
      // sub-face, subsumed by the enableBand40 switch) + the low-frequency
      // trio (rerankLowScoreThreshold / dropModelOnGate /
      // enableCompactLedger) + capacityTokens (deprecated by capacityRatio)
      // + enableLedger (retired 2026-11-24, zero consumption points).
      const sections = [
        {
          title: t("secBands"),
          fields: [
            { id: "plugin-config-supercompress-enable-compaction", label: t("enableCompaction"), hint: t("enableCompactionHint"), field: "enableCompaction", fs: state.enableCompaction, bool: true },
            { id: "plugin-config-supercompress-band-90", label: t("enableBand90"), hint: t("enableBand90Hint"), field: "enableBand90", fs: state.enableBand90, bool: true },
            { id: "plugin-config-supercompress-band-70", label: t("enableBand70"), hint: t("enableBand70Hint"), field: "enableBand70", fs: state.enableBand70, bool: true },
            { id: "plugin-config-supercompress-band-50", label: t("enableBand50"), hint: t("enableBand50Hint"), field: "enableBand50", fs: state.enableBand50, bool: true },
            { id: "plugin-config-supercompress-band-40", label: t("enableBand40"), hint: t("enableBand40Hint"), field: "enableBand40", fs: state.enableBand40, bool: true },
          ],
        },
        {
          title: t("secTrim"),
          fields: [
            { id: "plugin-config-supercompress-live-user-trim", label: t("liveUserTrim"), hint: t("liveUserTrimHint"), field: "liveUserTrim", fs: state.liveUserTrim, bool: true },
          ],
        },
        {
          title: t("secCache"),
          fields: [
            { id: "plugin-config-supercompress-cache-keeper", label: t("cacheKeeper"), hint: t("cacheKeeperHint"), field: "cacheKeeper", fs: state.cacheKeeper, bool: true },
          ],
        },
        {
          title: t("secData"),
          fields: [
            { id: "plugin-config-supercompress-capacity-ratio", label: t("capacityRatio"), hint: t("capacityRatioHint"), field: "capacityRatio", fs: state.capacityRatio, numeric: true },
            { id: "plugin-config-supercompress-host-pressure", label: t("hostPressureFactor"), hint: t("hostPressureFactorHint"), field: "hostPressureFactor", fs: state.hostPressureFactor, numeric: true },
          ],
        },
        {
          title: t("secUser"),
          fields: [
            { id: "plugin-config-supercompress-persist-user-turns", label: t("persistUserTurns"), hint: t("persistUserTurnsHint"), field: "persistUserTurns", fs: state.persistUserTurns, bool: true },
            { id: "plugin-config-supercompress-host-backfill", label: t("hostBackfill"), hint: t("hostBackfillHint"), field: "hostBackfill", fs: state.hostBackfill, bool: true },
            // RETIRED (owner ruling 2026-11-27): the enableRecall card row is
            // gone with the per-step top-k face (no schema field behind it).
            { id: "plugin-config-supercompress-user-source", label: t("userSource"), hint: t("userSourceHint"), field: "userSource", fs: state.userSource, select: true },
          ],
        },
      ];
      const els = sections.flatMap((sec) => [
        jsx("h4", {
          style: { margin: "14px 0 6px", fontSize: "0.9em", fontWeight: 600, opacity: 0.85 },
          children: sec.title,
        }),
        ...sec.fields.map((f) =>
          f.bool
            ? jsx(BoolToggleField, {
                id: f.id,
                label: f.label,
                hint: f.hint,
                fs: f.fs,
                disabled,
                onEdit: (text) => {
                  props.edit(f.field, text);
                },
                overriddenLabel: t("overridden"),
                t,
              })
            : f.select
              ? jsx(UserSourceSelectField, {
                  id: f.id,
                  label: f.label,
                  hint: f.hint,
                  fs: f.fs,
                  disabled,
                  onEdit: (text) => {
                    props.edit(f.field, text);
                  },
                  overriddenLabel: t("overridden"),
                  t,
                })
              : jsx(P.SettingsValueField, {
                id: f.id,
                label: f.label,
                hint: f.hint,
                overriddenLabel: t("overridden"),
                resetLabel: t("reset"),
                invalidLabel: f.numeric ? t("invalidNumber") : t("invalidValue"),
                numeric: !!f.numeric,
                disabled,
                ...f.fs,
                onEdit: (text) => {
                  props.edit(f.field, text);
                },
                onReset: () => {
                  props.resetField(f.field);
                },
              })
        ),
      ]);
      return jsxs(P.SettingsForm, {
        labels: formLabels(t),
        state,
        onSave: props.save,
        onDiscard: props.discard,
        children: els,
      });
    }

    /** Required services (cordis client fiber inject). */
    const inject = ["slots", "locale", "configForms"];

    /** @param {import('@deepseek-ai/cordis').Context} ctx */
    function apply(ctx) {
      const t = ctx.locale.bind(NS);
      ctx.effect(() => ctx.locale.register(NS, { en, zh }), "dsh-supercompress: dictionaries");
      const controller = new Controller(ctx.configForms.get(ENTRY));
      ctx.effect(() => () => controller.dispose(), "dsh-supercompress: form subscription");
      ctx.effect(
        () =>
          ctx.configForms.whileServed([ENTRY], (served) =>
            ctx.slots.inject("plugins.bundle.config", () =>
              ctx.slots.register(
                {
                  name: "plugins.bundle.config",
                  key: PKG,
                  locale: NS,
                  inject: () => controller.inject(),
                },
                SupercompressPage
              )
            )
          ),
        "dsh-supercompress: page"
      );
    }

    exports.apply = apply;
    exports.inject = inject;
    exports.NS = NS;
    return module.exports;
  },
});
