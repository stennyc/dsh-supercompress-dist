// llm-one-shot.js — the shell's one-shot aux LLM face (digest + tiering + rerank).
//
// DSH has NO separate "aux" provider — the reference's "aux ≡ main-model-endpoint"
// maps 1:1 to the host's single ctx.llm runtime. A one-shot generation (a short
// text/JSON reply, not a conversation) uses the host's NATIVE one-shot face —
// the exact pattern compaction-basic's summarizeWithLlm uses:
//
//   const options = { provider, model, messages, maxTokens, purpose, signal };
//   for await (const chunk of ctx.llm.stream(options)) { /* text-delta */ }
//
// (NOT ctx.llm.prepareCall: that binds a resolved call config and a later
// maxTokens override trips the host's callConfigEquals assert ->
// INVALID_PREPARED_CALL. The host's own aux one-shots go through stream().)
// `route` is { provider, model } from the session's last *routed* request
// (the same source compaction-basic's conversationTarget()/routedTarget() use).
//
// Zero deps: a mini text-assembler replaces @deepseek-ai/dsh-llm's BlockAssembler
// (we only read text-delta chunks — digest/tiering are single short text blocks,
// no tool-call assembly needed). The host's StreamChunk union for text is
// { type:"text-delta", index, text } / { type:"reasoning-delta", ... }.

// Accumulate the streamed text of a one-shot call. Returns "" on abort/error
// (callers treat that as a transient fail-safe, the reference's transient regime).
export async function oneShotText(ctx, { route, messages, system, purpose, maxTokens, signal, sessionId }) {
  // safeLlm: on the rc.1 host generation the ctx.llm accessor THROWS on an
  // undeclared `llm` token (it does not return undefined); the guard yields
  // undefined -> the deterministic floor instead of a raw reflect crash.
  const llm = safeLlm(ctx);
  if (!llm || typeof llm.stream !== "function") {
    throw new Error("ctx.llm.stream unavailable (plugin must declare inject: [\"llm\"])");
  }
  if (!route?.provider || !route?.model) {
    throw new Error("oneShotText: a resolvable route (provider+model) is required");
  }
  // The host-native one-shot options (compaction-basic summarizeWithLlm shape):
  // provider/model ride the options (not a bound prepareCall), so a maxTokens
  // here is the call's own value, never a post-resolution override.
  const options = {
    provider: route.provider,
    model: route.model,
    messages,
    ...(system ? { system } : {}),
    ...(maxTokens ? { maxTokens } : {}),
    ...(purpose ? { purpose } : {}),
    ...(sessionId ? { sessionId } : {}),
    ...(signal ? { signal } : {}),
  };
  let text = "";
  for await (const chunk of llm.stream(options)) {
    if (chunk?.type === "text-delta") text += chunk.text ?? "";
    else if (chunk?.type === "reasoning-delta") text += chunk.text ?? "";
  }
  return text.trim();
}

// Resolve { provider, model } from the last routed request header, falling
// back to the agent's options. `source` may be an Agent (reads
// agent.session.requestHeader() + agent.options — dsh-agent runtime APIs)
// OR a Session directly (reads session.requestHeader() — the compaction gate
// only has the session). Returns null when no route is resolvable (a fresh
// session with no request yet) — callers stay on the deterministic floor.
//
// DSH HOST CONTRACT (verified against dsh 0.2.2-rc.5): Session.requestHeader()
// -> EpochHeader { config: LlmCallConfig { provider, model, … } } is the
// same source the host's own compaction-basic conversationTarget() uses.
// `ctx.agent` does not exist on the DSH context; the caller must pass the
// real agent/session object from the event payload.
export function routeFromAgent(source) {
  try {
    const session = source?.session ?? source; // Agent or Session
    const cfg = session?.requestHeader?.()?.config;
    if (cfg?.provider && cfg?.model) return { provider: cfg.provider, model: cfg.model };
    if (source?.options?.provider && source?.options?.model) {
      return { provider: source.options.provider, model: source.options.model };
    }
  } catch {
    /* requestHeader not yet available -> no route */
  }
  return null;
}

// A user-role content block in the host's shape (equivalent to createUserMessage
// for one-shot aux calls; source.kind marks the producer so replay is faithful).
// `id` is required: the v4 open-time admission (assertMessageEventShape)
// rejects a user/message lacking a non-empty id — the host's createUserMessage
// stamps randomUUID() (createMessage), so we mirror it here.
import { randomUUID } from "node:crypto";
import { safeLlm } from "./llm-guard.js";

export function textUserMessage(text, sourceKind = "dsh-supercompress") {
  return {
    role: "user",
    content: [{ type: "text", text }],
    source: { kind: sourceKind },
    id: randomUUID(),
  };
}
