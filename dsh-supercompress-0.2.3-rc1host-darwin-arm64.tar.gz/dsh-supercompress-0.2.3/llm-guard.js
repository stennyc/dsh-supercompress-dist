// llm-guard.js — host-generation-tolerant DI accessors + the variant switch.
//
// WHY: the rc.1 host generation (the dsh-Go phone host) resolves a DIFFERENT
// inject-token vocabulary than rc.5+. Specifically rc.1 has NO `llm` and NO
// `tokenMeter` DI tokens (evidence: the rc.1 host bootstrap packages never
// register either; KB 4e5a93ef "rc1host has no llm inject token"). Worse, on
// rc.1 the ctx is a reflect accessor that THROWS on a direct property read of
// an undeclared token (`ctx.llm` / `ctx.tokenMeter` throw; they do NOT return
// undefined as they do on rc.5+). So any direct `ctx.llm` / `ctx.tokenMeter`
// property access in a build that does NOT declare those tokens will crash on
// rc.1.
//
// These helpers wrap the property read in try/catch so every caller gets the
// deterministic floor (`undefined`) on rc.1 and the live service on rc.5+:
//   - rc.5+ (tokens declared + resolvable): `ctx.llm` / `ctx.tokenMeter`
//     return the live service; the try/catch is a no-op.
//   - rc.1 (tokens absent): the read throws; we catch and return undefined ->
//     the LLM / meter face takes its coded deterministic floor.
//
// ZERO new runtime deps (node stdlib only). Pure functions, safe on both
// generations, safe in the dev / untransformed build (see isLegacyInject).

// Safe read of the host LLM runtime (the `llm` inject token).
export function safeLlm(ctx) {
  if (!ctx) return undefined;
  try {
    return ctx.llm;
  } catch {
    return undefined;
  }
}

// Safe read of the host token meter (the `tokenMeter` inject token).
export function safeTokenMeter(ctx) {
  if (!ctx) return undefined;
  try {
    return ctx.tokenMeter;
  } catch {
    return undefined;
  }
}

// Safe generic DI lookup (the `ctx.get(name)` method accessor — already
// miss-safe, but guard against a host whose get() throws on unknown tokens).
export function safeGet(ctx, name) {
  if (!ctx || typeof ctx.get !== "function") return undefined;
  try {
    return ctx.get(name);
  } catch {
    return undefined;
  }
}

// ── the host-generation variant switch (the dist packager's esbuild define) ──
// The closed-source dist ships two builds of this shell (KB tutorial pit 13:
// 代际双构建用 define 开关, 不 fork 代码):
//   - the FULL variant     : esbuild --define:__SC_LEGACY=false (rc.5+ host)
//   - the RC1HOST variant  : esbuild --define:__SC_LEGACY=true  (rc.1 host)
// In the dev / untransformed build the identifier is undeclared, so
// `typeof __SC_LEGACY` is "undefined" (typeof is safe on an undeclared
// identifier — no ReferenceError) and isLegacyInject is false = the FULL
// behavior. The packager's esbuild --define replaces every `__SC_LEGACY`
// reference with the literal, flipping the switch per variant.
export const isLegacyInject = (() => {
  try {
    return false; // RC1HOST 0.2.3: the FULL inject face (rc.1 has the llm/tokenMeter DI faces -- dsh-llm + dsh-token-meter; isLegacyInject=false; the LLM face floors only if ctx.llm is absent)
  } catch {
    return false;
  }
})();
